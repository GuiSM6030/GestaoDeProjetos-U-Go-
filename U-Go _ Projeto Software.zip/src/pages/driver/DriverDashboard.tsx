import { useEffect, useState } from "react"
import { supabase } from "../../lib/supabase"
import { driverRouteService } from "../../services/driverRouteService"
import { ContractsPanel, contractService } from "../../features/contracts"
import RouteMapModal from "../../components/RouteMapModal"
import PickupPointEditor from "../../components/PickupPointEditor"
import type { Route, Contract, PickupPoint } from "../../types"

interface Props {
  profile: any
  onLogout: () => void
}
type Tab = "overview" | "routes" | "contracts"
const WEEK_DAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]

function Sidebar({
  tab,
  setTab,
  name,
  onLogout,
}: {
  tab: Tab
  setTab: (t: Tab) => void
  name: string
  onLogout: () => void
}) {
  const items: {
    id: Tab
    label: string
    icon: string
  }[] = [
    { id: "overview", label: "Visão geral", icon: "📊" },
    { id: "routes", label: "Minhas rotas", icon: "🗺️" },
    { id: "contracts", label: "Contratos", icon: "📄" },
  ]
  return (
    <aside
      className="w-60 shrink-0 flex flex-col border-r border-purple-500/10 py-6 px-4"
      style={{ background: "rgba(255,255,255,0.02)" }}
    >
      <div className="flex items-center gap-3 px-3 mb-8">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
        >
          <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
            <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
          </svg>
        </div>
        <span
          className="text-lg font-bold text-white"
          style={{ fontFamily: "Outfit, sans-serif" }}
        >
          U-Go
        </span>
      </div>
      <nav className="flex-1 space-y-1">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setTab(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
              tab === item.id
                ? "text-white"
                : "text-purple-300/50 hover:text-purple-200 hover:bg-white/5"
            }`}
            style={
              tab === item.id
                ? {
                    background: "rgba(147,51,234,0.2)",
                    borderLeft: "2px solid #9333ea",
                  }
                : {}
            }
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <div className="px-3 py-2 mb-3">
        <p className="text-xs text-purple-300/40 truncate">{name}</p>
        <p className="text-xs text-purple-300/25">Motorista</p>
      </div>
      <button
        onClick={onLogout}
        className="flex items-center gap-2 px-3 py-2 text-sm text-purple-300/50 hover:text-red-400 transition-colors"
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          className="w-4 h-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"
          />
        </svg>
        Sair
      </button>
    </aside>
  )
}

function Modal({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: React.ReactNode
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
    >
      <div
        className="max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-purple-500/20 p-6"
        style={{ background: "#1a0840" }}
      >
        <div className="flex items-center justify-between mb-5">
          <h3
            className="text-lg font-semibold text-white"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            {title}
          </h3>
          <button
            onClick={onClose}
            className="text-purple-300/50 hover:text-white"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
  min,
  step,
  disabled = false,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  type?: string
  required?: boolean
  min?: number
  step?: number
  disabled?: boolean
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-purple-200/70 mb-1">
        {label}
        {required && <span className="ml-1 text-red-300">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        min={min}
        step={step}
        disabled={disabled}
        className="w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border border-purple-500/25 focus:border-purple-500 transition-colors disabled:cursor-not-allowed disabled:opacity-50"
        style={{ background: "rgba(255,255,255,0.05)", outline: "none" }}
      />
    </div>
  )
}

export default function DriverDashboard({ profile, onLogout }: Props) {
  const [tab, setTab] = useState<Tab>("overview")
  const [routes, setRoutes] = useState<Route[]>([])
  const [contracts, setContracts] = useState<Contract[]>([])
  const [routeModal, setRouteModal] = useState<
    "add" | "edit" | "duplicate" | null
  >(null)
  const [editingRoute, setEditingRoute] = useState<Route | null>(null)
  const [mapRoute, setMapRoute] = useState<Route | null>(null)
  const [routeForm, setRouteForm] = useState({
    name: "",
    origin: "",
    destination: "",
    departureTime: "",
    returnTime: "",
    seats: "",
    price: "",
  })
  const [routeDays, setRouteDays] = useState<string[]>([])
  const [pickupPoints, setPickupPoints] = useState<PickupPoint[]>([])
  const [routeError, setRouteError] = useState("")
  const [routesLoading, setRoutesLoading] = useState(true)
  const [routeSaving, setRouteSaving] = useState(false)

  const name =
    profile?.full_name || profile?.email?.split("@")[0] || "Motorista"
  const firstName = name.split(" ")[0]

  const handleLogout = async () => {
    await supabase.auth.signOut()
    onLogout()
  }

  useEffect(() => {
    let active = true
    setRoutesLoading(true)
    driverRouteService
      .listMyRoutes()
      .then((items) => {
        if (active) setRoutes(items)
      })
      .catch((error) => {
        if (active)
          setRouteError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar suas rotas.",
          )
      })
      .finally(() => {
        if (active) setRoutesLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  useEffect(() => {
    contractService.listarContratosDoPrestador().then((result) => {
      if (result.success && result.data) setContracts(result.data)
    })
  }, [])

  const openAddRoute = () => {
    setRouteForm({
      name: "",
      origin: "",
      destination: "",
      departureTime: "",
      returnTime: "",
      seats: String(profile?.seats || ""),
      price: "",
    })
    setRouteDays([])
    setPickupPoints([])
    setRouteError("")
    setEditingRoute(null)
    setRouteModal("add")
  }
  const openEditRoute = (r: Route) => {
    setEditingRoute(r)
    setRouteForm({
      name: r.name,
      origin: r.origin,
      destination: r.destination,
      departureTime: r.departureTime,
      returnTime: r.returnTime,
      seats: String(r.seats),
      price: String(r.price),
    })
    setRouteDays(r.days)
    setPickupPoints(r.pickupPoints ?? [])
    setRouteError("")
    setRouteModal("edit")
  }
  const openDuplicateRoute = (route: Route) => {
    setEditingRoute(route)
    setRouteForm({
      name: route.name,
      origin: route.origin,
      destination: route.destination,
      departureTime: route.departureTime,
      returnTime: route.returnTime,
      seats: String(route.seats),
      price: String(route.price),
    })
    setRouteDays(route.days)
    setPickupPoints(route.pickupPoints ?? [])
    setRouteError("")
    setRouteModal("duplicate")
  }
  const saveRoute = async () => {
    const missingFields = [
      !routeForm.name.trim() && "nome da rota",
      !routeForm.origin.trim() && "origem",
      !routeForm.destination.trim() && "destino",
      !routeForm.departureTime && "horário de saída",
      !routeForm.returnTime && "horário de retorno",
      !routeForm.seats && "vagas",
      !routeForm.price && "preço mensal",
    ].filter(Boolean)
    if (missingFields.length > 0) {
      setRouteError(
        `Preencha todos os campos obrigatórios: ${missingFields.join(", ")}.`,
      )
      return
    }
    const seats = Number(routeForm.seats)
    const price = Number(routeForm.price)
    if (!Number.isInteger(seats) || seats < 1) {
      setRouteError("Informe uma quantidade de vagas inteira e maior que zero.")
      return
    }
    if (!Number.isFinite(price) || price <= 0) {
      setRouteError("Informe um preço mensal maior que zero.")
      return
    }
    if (routeDays.length === 0) {
      setRouteError("Selecione ao menos um dia de funcionamento.")
      return
    }
    if (pickupPoints.length === 0) {
      setRouteError("Adicione ao menos um ponto de embarque no mapa.")
      return
    }
    if (pickupPoints.some((point) => !point.name.trim())) {
      setRouteError("Todos os pontos de embarque precisam de um nome.")
      return
    }
    const routeData = {
      ...routeForm,
      seats,
      occupiedSeats:
        routeModal === "edit" ? (editingRoute?.occupiedSeats ?? 0) : 0,
      price,
      days: routeDays,
      vehicle:
        routeModal === "duplicate"
          ? (editingRoute?.vehicle ?? "")
          : profile?.vehicle || editingRoute?.vehicle || "",
      pickupPoints,
    }
    setRouteSaving(true)
    try {
      if (routeModal === "add" || routeModal === "duplicate") {
        const created = await driverRouteService.createMyRoute(routeData)
        setRoutes((items) => [created, ...items])
      } else if (editingRoute) {
        const updated = await driverRouteService.updateMyRoute(
          editingRoute.id,
          routeData,
        )
        setRoutes((items) =>
          items.map((route) => (route.id === updated.id ? updated : route)),
        )
      }
      setRouteModal(null)
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível salvar a rota.",
      )
    } finally {
      setRouteSaving(false)
    }
  }
  const deleteRoute = async (id: string) => {
    try {
      await driverRouteService.deleteMyRoute(id)
      setRoutes((items) => items.filter((route) => route.id !== id))
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível excluir a rota.",
      )
    }
  }
  const rf = (f: keyof typeof routeForm) => (v: string) => {
    setRouteError("")
    setRouteForm((x) => ({ ...x, [f]: v }))
  }

  const totalPassengers = routes.reduce((s, r) => s + r.occupiedSeats, 0)
  const totalSeats = routes.reduce((s, r) => s + r.seats, 0)
  const monthlyRevenue = contracts
    .filter((c) => c.status === "active")
    .reduce((s, c) => s + c.value, 0)

  return (
    <div
      className="min-h-screen flex"
      style={{
        background: "linear-gradient(135deg, #0d0520 0%, #1a0840 100%)",
      }}
    >
      <Sidebar tab={tab} setTab={setTab} name={name} onLogout={handleLogout} />

      <main className="flex-1 overflow-y-auto p-8">
        {tab === "overview" && (
          <div>
            <p className="text-purple-300/50 text-sm mb-1">
              Painel do Motorista 🚌
            </p>
            <h1
              className="text-3xl font-bold text-white mb-1"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              Olá, {firstName}!
            </h1>
            {profile?.vehicle && (
              <p className="text-purple-300/40 text-sm mb-6">
                {profile.vehicle} · {profile.plate}
              </p>
            )}

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                { label: "Rotas ativas", value: routes.length, icon: "🗺️" },
                { label: "Passageiros", value: totalPassengers, icon: "👥" },
                {
                  label: "Vagas livres",
                  value: totalSeats - totalPassengers,
                  icon: "💺",
                },
                {
                  label: "Receita mensal",
                  value: `R$ ${monthlyRevenue.toLocaleString("pt-BR")}`,
                  icon: "💰",
                },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl border border-purple-500/15 p-5"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  <div className="text-2xl mb-3">{s.icon}</div>
                  <div
                    className="text-2xl font-bold text-white mb-1"
                    style={{ fontFamily: "Outfit, sans-serif" }}
                  >
                    {s.value}
                  </div>
                  <div className="text-xs text-purple-300/50">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div
                className="rounded-2xl border border-purple-500/15 p-5"
                style={{ background: "rgba(255,255,255,0.03)" }}
              >
                <h2
                  className="font-semibold text-white mb-4"
                  style={{ fontFamily: "Outfit, sans-serif" }}
                >
                  Ocupação das rotas
                </h2>
                {routes.map((r) => (
                  <div key={r.id} className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-200/70">{r.name}</span>
                      <span className="text-purple-300/50">
                        {r.occupiedSeats}/{r.seats}
                      </span>
                    </div>
                    <div
                      className="h-2 rounded-full"
                      style={{ background: "rgba(147,51,234,0.1)" }}
                    >
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${Math.min((r.occupiedSeats / r.seats) * 100, 100)}%`,
                          background:
                            "linear-gradient(to right,#9333ea,#c084fc)",
                        }}
                      />
                    </div>
                  </div>
                ))}
                {routes.length === 0 && (
                  <p className="py-8 text-center text-sm text-purple-300/40">
                    Nenhuma rota cadastrada.
                  </p>
                )}
              </div>
              <div
                className="rounded-2xl border border-purple-500/15 p-5"
                style={{ background: "rgba(255,255,255,0.03)" }}
              >
                <h2
                  className="font-semibold text-white mb-4"
                  style={{ fontFamily: "Outfit, sans-serif" }}
                >
                  Contratos recentes
                </h2>
                {contracts.slice(0, 3).map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between mb-3"
                  >
                    <div>
                      <p className="text-sm text-white">{c.party}</p>
                      <p className="text-xs text-purple-300/40">{c.route}</p>
                    </div>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-full ${
                        c.status === "active"
                          ? "text-green-300"
                          : "text-purple-300/40"
                      }`}
                      style={{
                        background:
                          c.status === "active"
                            ? "rgba(34,197,94,0.1)"
                            : "rgba(255,255,255,0.05)",
                      }}
                    >
                      {c.status === "active" ? "Ativo" : "Expirado"}
                    </span>
                  </div>
                ))}
                {contracts.length === 0 && (
                  <p className="py-8 text-center text-sm text-purple-300/40">
                    Nenhum contrato disponível.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {tab === "routes" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h1
                className="text-2xl font-bold text-white"
                style={{ fontFamily: "Outfit, sans-serif" }}
              >
                Minhas rotas
              </h1>
              <button
                onClick={openAddRoute}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
                style={{
                  background: "linear-gradient(135deg, #9333ea, #7e22ce)",
                }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  className="w-4 h-4"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 4.5v15m7.5-7.5h-15"
                  />
                </svg>
                Nova rota
              </button>
            </div>
            {routeError && !routeModal && (
              <p className="mb-4 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                {routeError}
              </p>
            )}
            <div className="space-y-4">
              {routesLoading && (
                <div className="py-16 text-center text-purple-300/40">
                  Carregando suas rotas...
                </div>
              )}
              {!routesLoading &&
                routes.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-2xl border border-purple-500/15 p-5"
                    style={{ background: "rgba(255,255,255,0.03)" }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3
                          className="font-semibold text-white mb-1"
                          style={{ fontFamily: "Outfit, sans-serif" }}
                        >
                          {r.name}
                        </h3>
                        <p className="text-xs text-purple-300/50 mb-3">
                          {r.origin} → {r.destination}
                        </p>
                        <div className="flex flex-wrap gap-4 text-xs text-purple-300/60">
                          <span>
                            🕐 Saída {r.departureTime} · Retorno {r.returnTime}
                          </span>
                          <span>
                            💺 {r.occupiedSeats}/{r.seats} passageiros
                          </span>
                          <span>💰 R$ {r.price}/mês por passageiro</span>
                        </div>
                        <div className="mt-3">
                          <div className="flex gap-1">
                            {r.days.map((d) => (
                              <span
                                key={d}
                                className="text-xs px-2 py-0.5 rounded-full text-purple-300/60"
                                style={{ background: "rgba(147,51,234,0.1)" }}
                              >
                                {d}
                              </span>
                            ))}
                          </div>
                        </div>
                        {r.pickupPoints && r.pickupPoints.length > 0 && (
                          <div className="mt-4 border-t border-purple-500/10 pt-3">
                            <p className="mb-2 text-xs font-medium text-purple-200/70">
                              Pontos de embarque
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {r.pickupPoints.map((point, index) => (
                                <span
                                  key={point.id}
                                  className="inline-flex items-center gap-1.5 rounded-lg bg-purple-500/10 px-2.5 py-1 text-xs text-purple-200/70"
                                >
                                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-purple-600 text-[10px] font-bold text-white">
                                    {index + 1}
                                  </span>
                                  {point.name}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 ml-4">
                        <button
                          onClick={() => setMapRoute(r)}
                          className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                          title="Ver no mapa"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M9 6.75V15m6-6v8.25m.503 3.498 4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 0 0-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0Z"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => openDuplicateRoute(r)}
                          className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                          title="Duplicar rota"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75A1.125 1.125 0 0 1 3.75 20.625v-9.75c0-.621.504-1.125 1.125-1.125H8.25m7.5 7.5h3.375c.621 0 1.125-.504 1.125-1.125v-9.75c0-.621-.504-1.125-1.125-1.125h-9.75c-.621 0-1.125.504-1.125 1.125V9.75m7.5 7.5h-6.375A1.125 1.125 0 0 1 8.25 16.125V9.75"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => openEditRoute(r)}
                          className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                          title="Editar rota"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => deleteRoute(r.id)}
                          className="p-2 rounded-lg text-red-400/50 hover:text-red-400 hover:bg-red-500/10 transition-all"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                            />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              {!routesLoading && routes.length === 0 && (
                <div className="text-center py-16 text-purple-300/40">
                  <p className="text-lg mb-2">Nenhuma rota cadastrada</p>
                  <p className="text-sm">Clique em "Nova rota" para começar</p>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "contracts" && (
          <ContractsPanel
            contracts={contracts}
            viewerRole="driver"
            onContractChange={(updated) =>
              setContracts((items) =>
                items.map((item) => (item.id === updated.id ? updated : item)),
              )
            }
          />
        )}
      </main>

      {mapRoute && (
        <RouteMapModal route={mapRoute} onClose={() => setMapRoute(null)} />
      )}

      {routeModal && (
        <Modal
          title={
            routeModal === "add"
              ? "Nova rota"
              : routeModal === "duplicate"
                ? "Duplicar rota"
                : "Editar rota"
          }
          onClose={() => setRouteModal(null)}
        >
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault()
              saveRoute()
            }}
          >
            {routeModal === "duplicate" ? (
              <p className="rounded-xl border border-purple-500/20 bg-purple-500/10 px-3 py-2 text-sm text-purple-200/80">
                Os dados da rota original foram copiados. Altere apenas os
                horários para cadastrar a nova rota.
              </p>
            ) : (
              <p className="text-xs text-purple-300/50">
                <span className="text-red-300">*</span> Todos os campos são
                obrigatórios.
              </p>
            )}
            <Field
              label="Nome da rota"
              value={routeForm.name}
              onChange={rf("name")}
              placeholder="Origem → Destino"
              required
              disabled={routeModal === "duplicate"}
            />
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Origem"
                value={routeForm.origin}
                onChange={rf("origin")}
                placeholder="Endereço de saída"
                required
                disabled={routeModal === "duplicate"}
              />
              <Field
                label="Destino"
                value={routeForm.destination}
                onChange={rf("destination")}
                placeholder="Endereço de chegada"
                required
                disabled={routeModal === "duplicate"}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Horário de saída"
                value={routeForm.departureTime}
                onChange={rf("departureTime")}
                type="time"
                required
              />
              <Field
                label="Horário de retorno"
                value={routeForm.returnTime}
                onChange={rf("returnTime")}
                type="time"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Vagas"
                value={routeForm.seats}
                onChange={rf("seats")}
                type="number"
                placeholder={String(profile?.seats || 10)}
                required
                min={1}
                step={1}
                disabled={routeModal === "duplicate"}
              />
              <Field
                label="Preço mensal (R$)"
                value={routeForm.price}
                onChange={rf("price")}
                type="number"
                placeholder="350"
                required
                min={0.01}
                step={0.01}
                disabled={routeModal === "duplicate"}
              />
            </div>
            <div>
              <p className="mb-2 text-xs font-medium text-purple-200/70">
                Dias de funcionamento
                <span className="ml-1 text-red-300">*</span>
              </p>
              <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
                {WEEK_DAYS.map((day) => {
                  const selected = routeDays.includes(day)
                  return (
                    <button
                      key={day}
                      type="button"
                      aria-pressed={selected}
                      disabled={routeModal === "duplicate"}
                      onClick={() => {
                        setRouteError("")
                        setRouteDays((current) =>
                          selected
                            ? current.filter((item) => item !== day)
                            : [...current, day],
                        )
                      }}
                      className={`rounded-xl border px-2 py-2 text-xs font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-60 ${
                        selected
                          ? "border-purple-400 bg-purple-600 text-white"
                          : "border-purple-500/20 bg-white/5 text-purple-300/60 hover:border-purple-400/50 hover:text-purple-200"
                      }`}
                    >
                      {day}
                    </button>
                  )
                })}
              </div>
            </div>
            <PickupPointEditor
              points={pickupPoints}
              onChange={(points) => {
                setPickupPoints(points)
                setRouteError("")
              }}
              readOnly={routeModal === "duplicate"}
            />
            {routeError && (
              <p className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                {routeError}
              </p>
            )}
            <button
              type="submit"
              disabled={routeSaving}
              className="w-full py-2.5 rounded-xl text-sm font-semibold text-white mt-2 disabled:opacity-50"
              style={{
                background: "linear-gradient(135deg, #9333ea, #7e22ce)",
              }}
            >
              {routeSaving
                ? "Salvando..."
                : routeModal === "add"
                  ? "Cadastrar rota"
                  : routeModal === "duplicate"
                    ? "Duplicar rota"
                    : "Salvar alterações"}
            </button>
          </form>
        </Modal>
      )}
    </div>
  )
}
