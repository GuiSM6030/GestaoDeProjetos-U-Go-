import { getEmailRedirectUrl } from "../../../lib/auth"
import { EDGE_FUNCTION_URL, supabase } from "../../../lib/supabase"
import type { Collaborator, Contract, Route } from "../../../types"

export interface CollaboratorInput {
  name: string
  email: string
  cpf: string
  phone: string
  address: string
  department: string
}

export type CompanyRouteInput = Omit<Route, "id" | "contractId" | "occupiedSeats"> & {
  occupiedSeats?: number
}

interface CompanyRouteRow {
  id: string
  company_id: string
  name: string
  origin: string
  destination: string
  departure_time: string
  return_time: string
  seats: number
  occupied_seats: number
  price: number | string
  days: string[]
  freight_company: string
}

interface CompanyContractRow {
  id: string
  company_id: string
  route_id: string
  party: string
  provider: string
  start_date: string
  end_date: string
  value: number | string
  status: Contract["status"]
  vehicles: Contract["vehicles"]
  created_at: string
}

interface CollaboratorRow {
  id: string
  name: string
  email: string
  cpf: string
  phone: string
  address: string
  department: string
  status: Collaborator["status"]
  needs_password: boolean
}

const toContract = (row: CompanyContractRow, routeName: string): Contract => ({
  id: row.id,
  party: row.party,
  type: "company",
  userId: row.company_id,
  userRole: "company",
  routeId: row.route_id,
  route: routeName,
  provider: row.provider,
  createdAt: row.created_at,
  startDate: row.start_date,
  endDate: row.end_date,
  value: Number(row.value),
  status: row.status,
  vehicles: row.vehicles ?? [],
})

const toCollaborator = (row: CollaboratorRow): Collaborator => ({
  id: row.id,
  name: row.name,
  email: row.email,
  cpf: row.cpf,
  phone: row.phone,
  address: row.address,
  department: row.department,
  status: row.status,
  needsPassword: row.needs_password,
})

const routeRow = (companyId: string, route: CompanyRouteInput) => ({
  company_id: companyId,
  name: route.name,
  origin: route.origin,
  destination: route.destination,
  departure_time: route.departureTime,
  return_time: route.returnTime,
  seats: route.seats,
  occupied_seats: route.occupiedSeats ?? 0,
  price: route.price,
  days: route.days,
  freight_company: route.freightCompany ?? "",
  updated_at: new Date().toISOString(),
})

const toRoute = (row: CompanyRouteRow, contractId?: string): Route => ({
  id: row.id,
  name: row.name,
  origin: row.origin,
  destination: row.destination,
  departureTime: row.departure_time.slice(0, 5),
  returnTime: row.return_time.slice(0, 5),
  seats: row.seats,
  occupiedSeats: row.occupied_seats,
  price: Number(row.price),
  days: row.days,
  freightCompany: row.freight_company,
  contractId,
})

async function currentCompanyId() {
  const { data, error } = await supabase.auth.getUser()
  if (error || !data.user) throw new Error("Empresa não autenticada.")
  return data.user.id
}

async function accessToken() {
  const { data, error } = await supabase.auth.getSession()
  if (error || !data.session) throw new Error("Sessão da empresa expirada.")
  return data.session.access_token
}

export const companyDataService = {
  async listDashboardData() {
    const companyId = await currentCompanyId()
    const [routesResult, contractsResult, collaboratorsResult] =
      await Promise.all([
        supabase
          .from("company_routes")
          .select("*")
          .eq("company_id", companyId)
          .order("created_at", { ascending: false }),
        supabase
          .from("company_contracts")
          .select("*")
          .eq("company_id", companyId)
          .order("created_at", { ascending: false }),
        supabase
          .from("company_collaborators")
          .select("*")
          .eq("company_id", companyId)
          .order("created_at", { ascending: false }),
      ])

    const error =
      routesResult.error ?? contractsResult.error ?? collaboratorsResult.error
    if (error) throw new Error(error.message)

    const contractRows = contractsResult.data as CompanyContractRow[]
    const routeRows = routesResult.data as CompanyRouteRow[]
    const routeNames = new Map(routeRows.map((route) => [route.id, route.name]))
    const contracts = contractRows.map((contract) =>
      toContract(contract, routeNames.get(contract.route_id) ?? "Rota"),
    )
    const contractIds = new Map(
      contractRows.map((contract) => [contract.route_id, contract.id]),
    )

    return {
      routes: routeRows.map((route) =>
        toRoute(route, contractIds.get(route.id)),
      ),
      contracts,
      collaborators: (collaboratorsResult.data as CollaboratorRow[]).map(
        toCollaborator,
      ),
    }
  },

  async createRoute(route: CompanyRouteInput) {
    const companyId = await currentCompanyId()
    const { data: createdRoute, error: routeError } = await supabase
      .from("company_routes")
      .insert(routeRow(companyId, route))
      .select("*")
      .single()
    if (routeError) throw new Error(routeError.message)

    const start = new Date()
    const end = new Date(start)
    end.setFullYear(end.getFullYear() + 1)
    const { data: createdContract, error: contractError } = await supabase
      .from("company_contracts")
      .insert({
        company_id: companyId,
        route_id: createdRoute.id,
        party: route.freightCompany,
        provider: route.freightCompany,
        start_date: start.toISOString().slice(0, 10),
        end_date: end.toISOString().slice(0, 10),
        value: route.price,
      })
      .select("*")
      .single()

    if (contractError) {
      await supabase.from("company_routes").delete().eq("id", createdRoute.id)
      throw new Error(contractError.message)
    }

    return {
      route: toRoute(createdRoute as CompanyRouteRow, createdContract.id),
      contract: toContract(createdContract as CompanyContractRow, route.name),
    }
  },

  async updateRoute(id: string, route: CompanyRouteInput) {
    const companyId = await currentCompanyId()
    const { data: updatedRoute, error: routeError } = await supabase
      .from("company_routes")
      .update(routeRow(companyId, route))
      .eq("id", id)
      .eq("company_id", companyId)
      .select("*")
      .single()
    if (routeError) throw new Error(routeError.message)

    const { data: updatedContract, error: contractError } = await supabase
      .from("company_contracts")
      .update({
        party: route.freightCompany,
        provider: route.freightCompany,
        value: route.price,
        updated_at: new Date().toISOString(),
      })
      .eq("route_id", id)
      .eq("company_id", companyId)
      .select("*")
      .single()
    if (contractError) throw new Error(contractError.message)

    return {
      route: toRoute(updatedRoute as CompanyRouteRow, updatedContract.id),
      contract: toContract(updatedContract as CompanyContractRow, route.name),
    }
  },

  async deleteRoute(id: string) {
    const companyId = await currentCompanyId()
    const { error } = await supabase
      .from("company_routes")
      .delete()
      .eq("id", id)
      .eq("company_id", companyId)
    if (error) throw new Error(error.message)
  },

  async createCollaborators(inputs: CollaboratorInput[]) {
    const response = await fetch(`${EDGE_FUNCTION_URL}/collaborators`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${await accessToken()}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        collaborators: inputs,
        redirectTo: getEmailRedirectUrl(),
      }),
    })
    const body = await response.json()
    if (!response.ok && response.status !== 207) {
      throw new Error(body.error ?? "Não foi possível criar colaboradores.")
    }
    return {
      created: (body.created as CollaboratorRow[]).map(toCollaborator),
      failures: body.failures as {
        email: string
        error: string
      }[],
    }
  },

  async deleteCollaborator(id: string) {
    const response = await fetch(`${EDGE_FUNCTION_URL}/collaborators/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${await accessToken()}` },
    })
    const body = await response.json()
    if (!response.ok) {
      throw new Error(body.error ?? "Não foi possível excluir o colaborador.")
    }
  },
}
