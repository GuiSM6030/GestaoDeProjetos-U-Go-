import { supabase } from "../lib/supabase"
import type { Route } from "../types"

type RouteInput = Omit<Route, "id">

interface DriverRouteRow {
  id: string
  driver_id: string
  driver_name: string
  name: string
  origin: string
  destination: string
  departure_time: string
  return_time: string
  seats: number
  occupied_seats: number
  price: number | string
  days: string[]
  vehicle: string
  pickup_points: Route["pickupPoints"]
}

interface DatabaseError {
  code?: string
  message: string
}

function databaseError(error: DatabaseError) {
  if (error.code === "PGRST205") {
    return new Error(
      "A estrutura de rotas ainda não foi criada no Supabase. Execute a migration de driver_routes no SQL Editor e atualize esta página.",
    )
  }
  return new Error(error.message)
}

function toRoute(row: DriverRouteRow): Route {
  return {
    id: row.id,
    driverId: row.driver_id,
    driverName: row.driver_name || "Motorista",
    name: row.name,
    origin: row.origin,
    destination: row.destination,
    departureTime: row.departure_time.slice(0, 5),
    returnTime: row.return_time.slice(0, 5),
    seats: row.seats,
    occupiedSeats: row.occupied_seats,
    price: Number(row.price),
    days: row.days,
    vehicle: row.vehicle,
    pickupPoints: row.pickup_points ?? [],
  }
}

function toRow(route: RouteInput) {
  return {
    name: route.name,
    origin: route.origin,
    destination: route.destination,
    departure_time: route.departureTime,
    return_time: route.returnTime,
    seats: route.seats,
    occupied_seats: route.occupiedSeats,
    price: route.price,
    days: route.days,
    vehicle: route.vehicle ?? "",
    pickup_points: route.pickupPoints ?? [],
    updated_at: new Date().toISOString(),
  }
}

async function getDriver() {
  const { data, error } = await supabase.auth.getUser()
  if (error || !data.user) {
    throw new Error("Sessão do motorista não encontrada.")
  }
  return {
    id: data.user.id,
    name:
      data.user.user_metadata?.full_name ??
      data.user.email?.split("@")[0] ??
      "Motorista",
  }
}

export const driverRouteService = {
  async listMyRoutes() {
    const driver = await getDriver()
    const { data, error } = await supabase
      .from("driver_routes")
      .select("*")
      .eq("driver_id", driver.id)
      .order("created_at", { ascending: false })

    if (error) throw databaseError(error)
    return (data as DriverRouteRow[]).map(toRoute)
  },

  async listAvailableRoutes() {
    const { data, error } = await supabase
      .from("driver_routes")
      .select("*")
      .order("created_at", { ascending: false })

    if (error) throw databaseError(error)
    return (data as DriverRouteRow[]).map(toRoute)
  },

  async createMyRoute(route: RouteInput) {
    const driver = await getDriver()
    const { data, error } = await supabase
      .from("driver_routes")
      .insert({
        ...toRow(route),
        driver_id: driver.id,
        driver_name: driver.name,
      })
      .select("*")
      .single()

    if (error) throw databaseError(error)
    return toRoute(data as DriverRouteRow)
  },

  async updateMyRoute(id: string, route: RouteInput) {
    const driver = await getDriver()
    const { data, error } = await supabase
      .from("driver_routes")
      .update(toRow(route))
      .eq("id", id)
      .eq("driver_id", driver.id)
      .select("*")
      .single()

    if (error) throw databaseError(error)
    return toRoute(data as DriverRouteRow)
  },

  async deleteMyRoute(id: string) {
    const driver = await getDriver()
    const { error } = await supabase
      .from("driver_routes")
      .delete()
      .eq("id", id)
      .eq("driver_id", driver.id)

    if (error) throw databaseError(error)
  },
}
