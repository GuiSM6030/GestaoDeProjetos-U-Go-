import { UserRole } from '../types'

interface Props {
  onSelectRole: (role: UserRole) => void
  onLogin: () => void
}

const roles = [
  {
    id: 'student' as UserRole,
    label: 'Universitário',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-10 h-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.438 60.438 0 0 0-.491 6.347A48.62 48.62 0 0 1 12 20.904a48.62 48.62 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.636 50.636 0 0 0-2.658-.813A59.906 59.906 0 0 1 12 3.493a59.903 59.903 0 0 1 10.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.717 50.717 0 0 1 12 13.489a50.702 50.702 0 0 1 3.741-3.342M6.75 15a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm0 0v-3.675A55.378 55.378 0 0 1 12 8.443m-7.007 11.55A5.981 5.981 0 0 0 6.75 15.75v-1.5" />
      </svg>
    ),
    description: 'Busque e adira a rotas universitárias',
    color: 'from-violet-600 to-purple-700',
    border: 'border-violet-500/40',
    hover: 'hover:border-violet-400',
  },
  {
    id: 'driver' as UserRole,
    label: 'Motorista',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-10 h-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
      </svg>
    ),
    description: 'Cadastre e gerencie rotas e contratos',
    color: 'from-fuchsia-600 to-purple-700',
    border: 'border-fuchsia-500/40',
    hover: 'hover:border-fuchsia-400',
  },
  {
    id: 'company' as UserRole,
    label: 'Empresa',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-10 h-10">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />
      </svg>
    ),
    description: 'Importe colaboradores e administre contratos',
    color: 'from-purple-600 to-indigo-700',
    border: 'border-purple-500/40',
    hover: 'hover:border-purple-400',
  },
]

export default function LandingPage({ onSelectRole, onLogin }: Props) {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg, #0d0520 0%, #1a0840 50%, #0d0520 100%)' }}>
      <header className="flex items-center justify-between px-8 py-6">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #9333ea, #7e22ce)' }}>
            <svg viewBox="0 0 24 24" fill="white" className="w-5 h-5">
              <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
            </svg>
          </div>
          <span className="text-xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>U-Go</span>
        </div>
        <button onClick={onLogin} className="px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 border border-purple-500/50 text-purple-300 hover:bg-purple-500/10 hover:border-purple-400">
          Entrar
        </button>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="text-center mb-14 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-6 border border-purple-500/30 text-purple-300" style={{ background: 'rgba(147, 51, 234, 0.1)' }}>
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
            Transporte fretado inteligente
          </div>
          <h1 className="text-5xl font-extrabold text-white mb-4 leading-tight" style={{ fontFamily: 'Outfit, sans-serif' }}>
            Conectando você ao{' '}
            <span style={{ background: 'linear-gradient(135deg, #c084fc, #9333ea)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              destino certo
            </span>
          </h1>
          <p className="text-lg text-purple-200/70">
            Plataforma completa de transporte fretado para universitários, colaboradores, motoristas e empresas.
          </p>
        </div>

        <div className="w-full max-w-5xl">
          <p className="text-center text-sm text-purple-300/60 mb-6 font-medium uppercase tracking-widest">
            Selecione seu perfil para se cadastrar
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-3xl mx-auto">
            {roles.map((role) => (
              <button
                key={role.id}
                onClick={() => onSelectRole(role.id)}
                className={`group relative flex flex-col items-center text-center p-6 rounded-2xl border transition-all duration-300 cursor-pointer ${role.border} ${role.hover}`}
                style={{ background: 'rgba(255,255,255,0.03)', backdropFilter: 'blur(12px)' }}
              >
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 bg-gradient-to-br ${role.color} text-white shadow-lg group-hover:scale-105 transition-transform duration-200`}>
                  {role.icon}
                </div>
                <h3 className="text-base font-bold text-white mb-1.5" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  {role.label}
                </h3>
                <p className="text-xs text-purple-200/55 leading-relaxed">
                  {role.description}
                </p>
                <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4 text-purple-400">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                  </svg>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center gap-3">
          <p className="text-sm text-purple-300/50">
            Já tem uma conta?{' '}
            <button onClick={onLogin} className="text-purple-400 hover:text-purple-300 font-medium underline underline-offset-2">
              Fazer login
            </button>
          </p>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full border border-purple-500/20 text-xs text-purple-300/40" style={{ background: 'rgba(147,51,234,0.05)' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-3.5 h-3.5 shrink-0">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
            </svg>
            Colaborador? Seu acesso é criado pela empresa — use o login com as credenciais recebidas.
          </div>
        </div>
      </main>
    </div>
  )
}
