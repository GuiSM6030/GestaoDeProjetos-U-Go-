import type {
  Contract,
  ContractStatus,
  Route,
  UserProfile,
  UserRole,
} from "../types"

export interface RegisterUserInput {
  email: string
  password: string
  role: UserRole
  metadata: Record<string, unknown>
}

export interface AuthenticateUserInput {
  email: string
  password: string
}

export interface AccessSession {
  accessToken: string
  expiresAt: number | null
  user: UserProfile
}

export interface OperationResult<T> {
  success: boolean
  data?: T
  error?: string
}

export interface IUsuario {
  cadastrarUsuario(
    input: RegisterUserInput,
  ): Promise<OperationResult<UserProfile>>
  autenticarUsuario(
    input: AuthenticateUserInput,
  ): Promise<OperationResult<AccessSession>>
  gerarSessaoAcesso(): Promise<OperationResult<AccessSession>>
  obterUsuarioAtual(): Promise<OperationResult<UserProfile>>
}

export interface GenerateContractInput {
  route: Route
  userRole: UserRole
  userName: string
  provider?: string
  startDate?: string
  durationMonths?: number
}

export interface IContratos {
  associarUsuarioRota(
    input: GenerateContractInput,
  ): Promise<OperationResult<Contract>>
  gerarContratoAdesao(
    input: GenerateContractInput,
  ): Promise<OperationResult<Contract>>
  listarContratos(userId?: string): Promise<OperationResult<Contract[]>>
  atualizarStatusContrato(
    id: string,
    status: ContractStatus,
  ): Promise<OperationResult<Contract>>
  verificarValidadeContrato(id: string): Promise<OperationResult<boolean>>
  gerarPdfContrato(contract: Contract): Promise<OperationResult<void>>
}
