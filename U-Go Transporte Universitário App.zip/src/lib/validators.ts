import { cpf, cnpj } from 'cpf-cnpj-validator'

export const validateCPF = (value: string): boolean => cpf.isValid(value)
export const validateCNPJ = (value: string): boolean => cnpj.isValid(value)

export const formatCPF = (value: string): string => {
  const digits = value.replace(/\D/g, '').slice(0, 11)
  return digits
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
}

export const formatCNPJ = (value: string): string => {
  const digits = value.replace(/\D/g, '').slice(0, 14)
  return digits
    .replace(/(\d{2})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1/$2')
    .replace(/(\d{4})(\d{1,2})$/, '$1-$2')
}

export const formatPhone = (value: string): string => {
  const digits = value.replace(/\D/g, '').slice(0, 11)
  if (digits.length <= 10) {
    return digits.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3')
  }
  return digits.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3')
}

export const formatCNH = (value: string): string => {
  return value.replace(/\D/g, '').slice(0, 11)
}

// Mercosul: ABC1D23 — 3 letras, 1 número, 1 letra, 2 números
export const formatPlate = (value: string): string => {
  const raw = value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 7)
  if (raw.length <= 3) return raw
  if (raw.length <= 4) return `${raw.slice(0, 3)}-${raw.slice(3)}`
  return `${raw.slice(0, 3)}-${raw.slice(3)}`
}

export const validatePlate = (value: string): boolean => {
  const raw = value.replace(/[^A-Z0-9]/gi, '').toUpperCase()
  // Mercosul: ABC1D23
  return /^[A-Z]{3}[0-9][A-Z][0-9]{2}$/.test(raw) ||
    // Antigo: ABC1234
    /^[A-Z]{3}[0-9]{4}$/.test(raw)
}

// CNH digit verification using DETRAN algorithm
export const validateCNH = (cnh: string): boolean => {
  const digits = cnh.replace(/\D/g, '')
  if (digits.length !== 11) return false
  if (/^(\d)\1{10}$/.test(digits)) return false

  let firstSum = 0
  let secondSum = 0

  for (let i = 0; i < 9; i++) {
    firstSum += parseInt(digits[i]) * (9 - i)
    secondSum += parseInt(digits[i]) * (1 + i)
  }

  let dst = 0
  let firstRemainder = firstSum % 11
  if (firstRemainder >= 10) {
    firstRemainder = 0
    dst = 1
  }

  let secondRemainder = secondSum % 11
  let secondDigit: number
  if (dst === 0) {
    secondDigit = secondRemainder >= 10 ? 0 : secondRemainder
  } else {
    secondDigit = secondRemainder >= 10 ? 1 : 11 - secondRemainder
    if (secondDigit >= 10) secondDigit = 0
  }

  return parseInt(digits[9]) === firstRemainder && parseInt(digits[10]) === secondDigit
}
