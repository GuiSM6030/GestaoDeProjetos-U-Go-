export interface MapCoordinate {
  lat: number
  lng: number
}

export interface GeocodingResult extends MapCoordinate {
  displayName: string
}

let nominatimQueue: Promise<void> = Promise.resolve()
let lastNominatimRequest = 0

function enqueueNominatim<T>(request: () => Promise<T>): Promise<T> {
  const run = nominatimQueue.then(async () => {
    const wait = Math.max(0, 1100 - (Date.now() - lastNominatimRequest))
    if (wait > 0) {
      await new Promise((resolve) => window.setTimeout(resolve, wait))
    }
    lastNominatimRequest = Date.now()
    return request()
  })

  nominatimQueue = run.then(
    () => undefined,
    () => undefined,
  )
  return run
}

async function fetchNominatim(url: string) {
  const response = await fetch(url, {
    headers: { "Accept-Language": "pt-BR" },
  })

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error(
        "O limite temporário de localização foi atingido. Tente novamente em instantes.",
      )
    }
    throw new Error("Não foi possível consultar a localização agora.")
  }

  return response.json()
}

export function searchAddress(address: string): Promise<GeocodingResult> {
  return enqueueNominatim(async () => {
    const url =
      "https://nominatim.openstreetmap.org/search?" +
      new URLSearchParams({
        q: address,
        format: "json",
        limit: "1",
        countrycodes: "br",
      })
    const data = await fetchNominatim(url)
    if (!data.length) throw new Error(`Endereço não encontrado: ${address}`)

    return {
      lat: Number.parseFloat(data[0].lat),
      lng: Number.parseFloat(data[0].lon),
      displayName: data[0].display_name,
    }
  })
}

export function reverseGeocode(
  coordinate: MapCoordinate,
): Promise<GeocodingResult> {
  return enqueueNominatim(async () => {
    const url =
      "https://nominatim.openstreetmap.org/reverse?" +
      new URLSearchParams({
        lat: String(coordinate.lat),
        lon: String(coordinate.lng),
        format: "json",
        zoom: "18",
      })
    const data = await fetchNominatim(url)
    if (!data.display_name) {
      throw new Error("Não foi possível identificar este ponto.")
    }

    return {
      ...coordinate,
      displayName: data.display_name,
    }
  })
}

export async function getDrivingRoute(
  coordinates: MapCoordinate[],
): Promise<[number, number][]> {
  const locations = coordinates.map(({ lat, lng }) => `${lng},${lat}`).join(";")
  const url = `https://router.project-osrm.org/route/v1/driving/${locations}?overview=full&geometries=geojson`
  const response = await fetch(url)

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error(
        "O limite temporário do serviço de rotas foi atingido. Tente novamente em instantes.",
      )
    }
    throw new Error("Não foi possível calcular a rota agora.")
  }

  const data = await response.json()
  if (data.code !== "Ok" || !data.routes.length) {
    throw new Error("Rota não encontrada")
  }

  return (data.routes[0].geometry.coordinates as [number, number][]).map(
    ([lng, lat]) => [lat, lng],
  )
}
