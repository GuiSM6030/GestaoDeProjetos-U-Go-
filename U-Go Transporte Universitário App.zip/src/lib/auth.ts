export function getEmailRedirectUrl() {
  return `${window.location.origin}${window.location.pathname}`
}
