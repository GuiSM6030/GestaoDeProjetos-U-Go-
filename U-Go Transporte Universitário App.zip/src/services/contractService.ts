import type {
  GenerateContractInput,
  IContratos,
  OperationResult,
} from "../contracts/interfaces"
import type { Contract, ContractStatus } from "../types"
import { userService } from "./userService"

const STORAGE_KEY = "ugo.contracts.v1"
const readContracts = (): Contract[] => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]")
  } catch {
    return []
  }
}
const writeContracts = (contracts: Contract[]) =>
  localStorage.setItem(STORAGE_KEY, JSON.stringify(contracts))
const formatDate = (date: Date) => date.toISOString().slice(0, 10)
const addMonths = (date: Date, months: number) => {
  const result = new Date(date)
  result.setMonth(result.getMonth() + months)
  return result
}

export const isContractCurrentlyValid = (contract: Contract) => {
  const today = formatDate(new Date())
  return (
    contract.status === "active" &&
    contract.startDate <= today &&
    contract.endDate >= today
  )
}

async function generate(
  input: GenerateContractInput,
): Promise<OperationResult<Contract>> {
  const user = await userService.obterUsuarioAtual()
  if (!user.success || !user.data)
    return { success: false, error: "Usuário autenticado não encontrado." }
  const duplicate = readContracts().find(
    (item) =>
      item.userId === user.data?.id &&
      item.routeId === input.route.id &&
      item.status !== "cancelled",
  )
  if (duplicate)
    return { success: false, error: "Já existe um contrato para esta rota." }
  const start = input.startDate
    ? new Date(`${input.startDate}T12:00:00`)
    : new Date()
  const contract: Contract = {
    id: crypto.randomUUID(),
    party: input.userName,
    type: input.userRole === "company" ? "company" : "student",
    userId: user.data.id,
    userRole: input.userRole,
    routeId: input.route.id,
    route: input.route.name,
    provider: input.provider ?? input.route.driverName ?? "U-Go",
    createdAt: new Date().toISOString(),
    startDate: formatDate(start),
    endDate: formatDate(addMonths(start, input.durationMonths ?? 12)),
    value: input.route.price,
    status: "active",
  }
  writeContracts([...readContracts(), contract])
  return { success: true, data: contract }
}

export const contractService: IContratos = {
  associarUsuarioRota: generate,
  gerarContratoAdesao: generate,
  async listarContratos(userId?: string) {
    const items = readContracts()
    if (userId)
      return {
        success: true,
        data: items.filter((item) => item.userId === userId),
      }
    const user = await userService.obterUsuarioAtual()
    if (!user.success || !user.data)
      return { success: false, error: "Usuário não autenticado." }
    return {
      success: true,
      data: items.filter((item) => item.userId === user.data?.id),
    }
  },
  async atualizarStatusContrato(id: string, status: ContractStatus) {
    const items = readContracts()
    const index = items.findIndex((item) => item.id === id)
    if (index < 0) return { success: false, error: "Contrato não encontrado." }
    items[index] = { ...items[index], status }
    writeContracts(items)
    return { success: true, data: items[index] }
  },
  async verificarValidadeContrato(id: string) {
    const contract = readContracts().find((item) => item.id === id)
    return contract
      ? { success: true, data: isContractCurrentlyValid(contract) }
      : { success: false, error: "Contrato não encontrado." }
  },
  async gerarPdfContrato(contract: Contract) {
    try {
      const { jsPDF } = await import("jspdf")
      const pdf = new jsPDF()
      pdf.setFontSize(18)
      pdf.text("U-Go | Contrato de adesao", 20, 24)
      pdf.setFontSize(11)
      const vehicleLines =
        contract.vehicles?.flatMap((vehicle) => [
          "",
          `${vehicle.name} | Placa ${vehicle.plate} | ${vehicle.passengers.length}/${vehicle.capacity} passageiros`,
          ...vehicle.passengers.map(
            (passenger) => `  - ${passenger.name} (${passenger.email})`,
          ),
        ]) ?? []
      pdf.text(
        [
          `Contrato: ${contract.id}`,
          `${
            contract.userRole === "company" || contract.type === "company"
              ? "Empresa de fretamento"
              : "Contratante"
          }: ${contract.party}`,
          `Rota: ${contract.route}`,
          `Prestador: ${contract.provider ?? "U-Go"}`,
          `Vigencia: ${contract.startDate} a ${contract.endDate}`,
          `Valor mensal: R$ ${contract.value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
          `Status: ${contract.status}`,
          "",
          "O contratante adere ao servico de transporte descrito acima.",
          ...vehicleLines,
        ],
        20,
        42,
      )
      pdf.save(`contrato-ugo-${contract.id.slice(0, 8)}.pdf`)
      return { success: true }
    } catch {
      return { success: false, error: "Não foi possível gerar o PDF." }
    }
  },
}
