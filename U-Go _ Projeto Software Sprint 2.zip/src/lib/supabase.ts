import { createClient, type SupabaseClient } from "@supabase/supabase-js"
import { projectId, publicAnonKey } from "../../utils/supabase/info.tsx"
import { capturePasswordRecoveryIntent } from "./authRecovery"

export const SUPABASE_URL = `https://${projectId}.supabase.co`
export const SUPABASE_PUBLIC_KEY = publicAnonKey
const key = `__ugo_supabase_client__`

// Supabase removes auth callback parameters while initializing. Persist the
// recovery intent first so App can still select the password reset screen.
capturePasswordRecoveryIntent()

declare global {
  interface Window {
    [key: string]: SupabaseClient | undefined
  }
}

function getClient(): SupabaseClient {
  if (typeof window !== "undefined" && window[key]) {
    return window[key]!
  }
  const client = createClient(SUPABASE_URL, publicAnonKey, {
    auth: {
      storageKey: "ugo-auth",
      autoRefreshToken: true,
      persistSession: true,
    },
  })
  if (typeof window !== "undefined") {
    window[key] = client
  }
  return client
}

export const supabase = getClient()
export const EDGE_FUNCTION_URL = `https://${projectId}.supabase.co/functions/v1/make-server-0563e832`
