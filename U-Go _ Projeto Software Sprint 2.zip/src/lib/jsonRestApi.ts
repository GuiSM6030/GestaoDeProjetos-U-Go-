import { supabase, SUPABASE_PUBLIC_KEY, SUPABASE_URL } from "./supabase"

export interface JsonApiError {
  code?: string
  message: string
  details?: string
  hint?: string
}

export interface JsonApiResult<T = any> {
  data: T | null
  error: JsonApiError | null
}

type QueryMode = "many" | "single" | "maybeSingle"

const jsonHeaders = async (prefer?: string) => {
  const { data } = await supabase.auth.getSession()
  return {
    apikey: SUPABASE_PUBLIC_KEY,
    Authorization: `Bearer ${data.session?.access_token ?? SUPABASE_PUBLIC_KEY}`,
    "Content-Type": "application/json",
    Accept: "application/json",
    ...(prefer ? { Prefer: prefer } : {}),
  }
}

const parseResponse = async (response: Response) => {
  const body = await response.text()
  const payload = body ? JSON.parse(body) : null
  if (!response.ok) {
    return {
      data: null,
      error: {
        code: payload?.code,
        message: payload?.message ?? "A API REST não concluiu a solicitação.",
        details: payload?.details,
        hint: payload?.hint,
      },
    }
  }
  return { data: payload, error: null }
}

class RestQueryBuilder implements PromiseLike<JsonApiResult<any>> {
  private method = "GET"
  private body: unknown
  private params = new URLSearchParams()
  private mode: QueryMode = "many"
  private returnRepresentation = false

  constructor(private readonly table: string) {}

  select(columns = "*") {
    this.params.set("select", columns)
    if (this.method !== "GET") this.returnRepresentation = true
    return this
  }

  eq(column: string, value: unknown) {
    this.params.set(column, `eq.${String(value)}`)
    return this
  }

  is(column: string, value: unknown) {
    this.params.set(column, `is.${String(value)}`)
    return this
  }

  in(column: string, values: unknown[]) {
    this.params.set(
      column,
      `in.(${values.map((value) => JSON.stringify(value)).join(",")})`,
    )
    return this
  }

  order(column: string, options?: { ascending?: boolean }) {
    this.params.set(
      "order",
      `${column}.${options?.ascending === false ? "desc" : "asc"}`,
    )
    return this
  }

  limit(value: number) {
    this.params.set("limit", String(value))
    return this
  }

  insert(value: unknown) {
    this.method = "POST"
    this.body = value
    return this
  }

  update(value: unknown) {
    this.method = "PATCH"
    this.body = value
    return this
  }

  delete() {
    this.method = "DELETE"
    return this
  }

  single() {
    this.mode = "single"
    return this.execute()
  }

  maybeSingle() {
    this.mode = "maybeSingle"
    return this.execute()
  }

  then<TResult1 = JsonApiResult<any>,
  TResult2 = never,>(
    onfulfilled?: ((
      value: JsonApiResult<any>,
    ) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null,
  ): PromiseLike<TResult1 | TResult2> {
    return this.execute().then(onfulfilled, onrejected)
  }

  private async execute(): Promise<JsonApiResult<any>> {
    try {
      const prefer = this.returnRepresentation
        ? "return=representation"
        : this.method === "POST"
          ? "return=minimal"
          : undefined
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/${encodeURIComponent(this.table)}?${this.params}`,
        {
          method: this.method,
          headers: await jsonHeaders(prefer),
          body: this.body === undefined ? undefined : JSON.stringify(this.body),
        },
      )
      const result = await parseResponse(response)
      if (result.error || this.mode === "many") return result
      const rows = Array.isArray(result.data) ? result.data : [result.data]
      if (!rows.length || rows[0] == null) {
        return this.mode === "maybeSingle"
          ? { data: null, error: null }
          : {
              data: null,
              error: {
                message: "A API REST não retornou o registro esperado.",
              },
            }
      }
      if (this.mode === "single" && rows.length > 1) {
        return {
          data: null,
          error: { message: "A API REST retornou mais de um registro." },
        }
      }
      return { data: rows[0], error: null }
    } catch (error) {
      return {
        data: null,
        error: {
          message:
            error instanceof Error
              ? error.message
              : "Falha de comunicação com a API REST.",
        },
      }
    }
  }
}

export const jsonApi = {
  from(table: string) {
    return new RestQueryBuilder(table)
  },

  async rpc<T = any,>(
    functionName: string,
    parameters: Record<string, unknown> = {},
  ): Promise<JsonApiResult<T>> {
    try {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/rpc/${encodeURIComponent(functionName)}`,
        {
          method: "POST",
          headers: await jsonHeaders(),
          body: JSON.stringify(parameters),
        },
      )
      return (await parseResponse(response)) as JsonApiResult<T>
    } catch (error) {
      return {
        data: null,
        error: {
          message:
            error instanceof Error
              ? error.message
              : "Falha de comunicação com a API REST.",
        },
      }
    }
  },
}
