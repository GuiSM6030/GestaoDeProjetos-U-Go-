export interface MapCoordinate {
  lat: number
  lng: number
}

export interface GeocodingResult extends MapCoordinate {
  displayName: string
}

let geocodingQueue: Promise<void> = Promise.resolve()
let lastGeocodingRequest = 0

function enqueueGeocoding<T>(request: () => Promise<T>): Promise<T> {
  const run = geocodingQueue.then(async () => {
    const wait = Math.max(0, 1100 - (Date.now() - lastGeocodingRequest))
    if (wait > 0) {
      await new Promise((resolve) => window.setTimeout(resolve, wait))
    }
    lastGeocodingRequest = Date.now()
    return request()
  })

  geocodingQueue = run.then(
    () => undefined,
    () => undefined,
  )
  return run
}

async function fetchPhoton(url: string) {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), 10000)
  let response: Response
  try {
    response = await fetch(url, { signal: controller.signal })
  } catch {
    throw new Error(
      "A busca de endereço não respondeu. Você ainda pode aproximar o mapa e clicar para adicionar o ponto.",
    )
  } finally {
    window.clearTimeout(timeout)
  }

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error(
        "O limite temporário de localização foi atingido. Tente novamente em instantes.",
      )
    }
    throw new Error("Não foi possível consultar a localização agora.")
  }

  return response.json()
}

interface PhotonFeature {
  geometry: { coordinates: [number, number] }
  properties: {
    name?: string
    street?: string
    district?: string
    city?: string
    state?: string
    country?: string
    countrycode?: string
  }
}

function normalizeLocation(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\bsp\b/g, "sao paulo")
    .replace(/\brj\b/g, "rio de janeiro")
    .replace(/\bmg\b/g, "minas gerais")
    .replace(/\bpr\b/g, "parana")
    .replace(/\brs\b/g, "rio grande do sul")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
}

function selectBrazilianFeature(
  features: PhotonFeature[] | undefined,
  address: string,
) {
  const terms = normalizeLocation(address)
    .split(" ")
    .filter((term) => term.length > 1)

  return features
    ?.filter((feature) => {
      const [lng, lat] = feature.geometry.coordinates
      return (
        feature.properties.countrycode === "BR" &&
        lat >= -33.75 &&
        lat <= 5.27 &&
        lng >= -73.99 &&
        lng <= -34.79
      )
    })
    .map((feature) => {
      const candidate = normalizeLocation(
        [
          feature.properties.name,
          feature.properties.street,
          feature.properties.district,
          feature.properties.city,
          feature.properties.state,
        ]
          .filter(Boolean)
          .join(" "),
      )
      return {
        feature,
        score: terms.filter((term) => candidate.includes(term)).length,
      }
    })
    .sort((a, b) => b.score - a.score)[0]?.feature
}

function photonResult(feature: PhotonFeature): GeocodingResult {
  const [lng, lat] = feature.geometry.coordinates
  const displayName = [
    feature.properties.name,
    feature.properties.street,
    feature.properties.district,
    feature.properties.city,
    feature.properties.state,
    feature.properties.country,
  ]
    .filter(
      (part, index, all): part is string =>
        Boolean(part) && all.indexOf(part) === index,
    )
    .join(", ")

  return { lat, lng, displayName }
}

export function searchAddress(address: string): Promise<GeocodingResult> {
  return enqueueGeocoding(async () => {
    const url =
      "https://photon.komoot.io/api/?" +
      new URLSearchParams({
        q: `${address}, Brasil`,
        limit: "10",
        bbox: "-73.99,-33.75,-34.79,5.27",
      })
    const data = await fetchPhoton(url)
    const feature = selectBrazilianFeature(
      data.features as PhotonFeature[] | undefined,
      address,
    )
    if (!feature) throw new Error(`Endereço não encontrado: ${address}`)

    return photonResult(feature)
  })
}

export function reverseGeocode(
  coordinate: MapCoordinate,
): Promise<GeocodingResult> {
  return enqueueGeocoding(async () => {
    const url =
      "https://photon.komoot.io/reverse?" +
      new URLSearchParams({
        lat: String(coordinate.lat),
        lon: String(coordinate.lng),
      })
    const data = await fetchPhoton(url)
    const feature = data.features?.[0] as PhotonFeature | undefined
    if (!feature) {
      throw new Error("Não foi possível identificar este ponto.")
    }

    return photonResult(feature)
  })
}

export async function getDrivingRoute(
  coordinates: MapCoordinate[],
): Promise<[number, number][]> {
  const locations = coordinates.map(({ lat, lng }) => `${lng},${lat}`).join(";")
  const url = `https://router.project-osrm.org/route/v1/driving/${locations}?overview=full&geometries=geojson`
  const response = await fetch(url)

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error(
        "O limite temporário do serviço de rotas foi atingido. Tente novamente em instantes.",
      )
    }
    throw new Error("Não foi possível calcular a rota agora.")
  }

  const data = await response.json()
  if (data.code !== "Ok" || !data.routes.length) {
    throw new Error("Rota não encontrada")
  }

  return (data.routes[0].geometry.coordinates as [number, number][]).map(
    ([lng, lat]) => [lat, lng],
  )
}
