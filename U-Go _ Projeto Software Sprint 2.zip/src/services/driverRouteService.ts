import { supabase } from "../lib/supabase"
import { jsonApi } from "../lib/jsonRestApi"
import type { Route } from "../types"

type RouteInput = Omit<Route, "id">

interface DriverRouteRow {
  id: string
  driver_id: string
  driver_name: string
  name: string
  origin: string
  destination: string
  university: string
  origin_neighborhood: string
  departure_time: string
  arrival_time: string
  return_time: string
  seats: number
  occupied_seats: number
  price: number | string
  due_day: number | null
  contract_template_ready: boolean
  contract_template_archived_at: string | null
  minimum_term_months: number
  early_termination_fee_percent: number | string
  archived_at: string | null
  days: string[]
  vehicle: string
  pickup_points: Route["pickupPoints"]
}

interface DatabaseError {
  code?: string
  message: string
}

function databaseError(error: DatabaseError) {
  if (error.code === "PGRST205") {
    return new Error(
      "A estrutura de rotas ainda não foi criada no Supabase. Execute a migration de driver_routes no SQL Editor e atualize esta página.",
    )
  }
  return new Error(error.message)
}

function toRoute(row: DriverRouteRow): Route {
  return {
    id: row.id,
    driverId: row.driver_id,
    driverName: row.driver_name || "Motorista",
    name: row.name,
    origin: row.origin,
    destination: row.destination,
    university: row.university || row.destination,
    originNeighborhood: row.origin_neighborhood || row.origin,
    departureTime: row.departure_time.slice(0, 5),
    arrivalTime: row.arrival_time?.slice(0, 5) ?? row.return_time.slice(0, 5),
    returnTime: row.return_time.slice(0, 5),
    seats: row.seats,
    occupiedSeats: row.occupied_seats,
    price: Number(row.price),
    dueDay: row.due_day ?? undefined,
    contractTemplateReady: row.contract_template_ready,
    contractTemplateArchivedAt: row.contract_template_archived_at ?? undefined,
    minimumTermMonths: Number(row.minimum_term_months ?? 3),
    earlyTerminationFeePercent: Number(row.early_termination_fee_percent ?? 20),
    days: row.days,
    vehicle: row.vehicle,
    pickupPoints: row.pickup_points ?? [],
  }
}

function toRow(route: RouteInput) {
  return {
    name: route.name,
    origin: route.origin,
    destination: route.destination,
    university: route.university ?? route.destination,
    origin_neighborhood: route.originNeighborhood ?? route.origin,
    departure_time: route.departureTime,
    arrival_time: route.arrivalTime ?? route.returnTime,
    return_time: route.returnTime,
    seats: route.seats,
    occupied_seats: route.occupiedSeats,
    price: route.price,
    days: route.days,
    vehicle: route.vehicle ?? "",
    pickup_points: route.pickupPoints ?? [],
    updated_at: new Date().toISOString(),
  }
}

async function getDriver() {
  const { data, error } = await supabase.auth.getUser()
  if (error || !data.user) {
    throw new Error("Sessão do motorista não encontrada.")
  }
  return {
    id: data.user.id,
    name:
      data.user.user_metadata?.full_name ??
      data.user.email?.split("@")[0] ??
      "Motorista",
  }
}

export const driverRouteService = {
  async listMyRoutes() {
    const driver = await getDriver()
    const { data, error } = await jsonApi
      .from("driver_routes")
      .select("*")
      .eq("driver_id", driver.id)
      .is("archived_at", null)
      .order("created_at", { ascending: false })

    if (error) throw databaseError(error)
    const { data: drafts } = await jsonApi
      .from("driver_route_drafts")
      .select("route_id")
      .eq("driver_id", driver.id)
      .eq("status", "draft")
    const draftIds = new Set(
      (drafts ?? []).map((draft: { route_id: string }) => draft.route_id),
    )
    return (data as DriverRouteRow[]).map((row) => ({
      ...toRoute(row),
      hasPendingUpdate: draftIds.has(row.id),
    }))
  },

  async listAvailableRoutes() {
    const { data, error } = await jsonApi
      .from("driver_routes")
      .select("*")
      .eq("contract_template_ready", true)
      .is("archived_at", null)
      .order("created_at", { ascending: false })

    if (error) throw databaseError(error)
    return (data as DriverRouteRow[]).map(toRoute)
  },

  async createMyRoute(route: RouteInput) {
    const driver = await getDriver()
    const { data, error } = await jsonApi
      .from("driver_routes")
      .insert({
        ...toRow(route),
        driver_id: driver.id,
        driver_name: driver.name,
      })
      .select("*")
      .single()

    if (error) throw databaseError(error)
    return toRoute(data as DriverRouteRow)
  },

  async updateMyRoute(id: string, route: RouteInput) {
    const driver = await getDriver()
    const { data, error } = await jsonApi
      .from("driver_routes")
      .update(toRow(route))
      .eq("id", id)
      .eq("driver_id", driver.id)
      .select("*")
      .single()

    if (error) throw databaseError(error)
    return toRoute(data as DriverRouteRow)
  },

  async saveContractTemplate(
    id: string,
    monthlyPrice: number,
    dueDay: number,
    minimumTermMonths: number,
    terminationFeePercent: number,
  ) {
    if (!Number.isFinite(monthlyPrice) || monthlyPrice <= 0) {
      throw new Error("Informe um valor válido para a mensalidade")
    }
    if (!Number.isInteger(dueDay) || dueDay < 1 || dueDay > 28) {
      throw new Error("Informe um dia de vencimento entre 1 e 28.")
    }

    const { data, error } = await jsonApi.rpc(
      "update_driver_contract_template",
      {
        p_route_id: id,
        p_monthly_price: monthlyPrice,
        p_due_day: dueDay,
        p_minimum_term_months: minimumTermMonths,
        p_termination_fee_percent: terminationFeePercent,
      },
    )
    if (error) throw databaseError(error)
    return {
      route: toRoute(data.route as DriverRouteRow),
      amendmentCreated: Boolean(data.amendmentCreated),
      affectedStudents: Number(data.affectedStudents ?? 0),
    }
  },

  async removeContractTemplate(id: string) {
    const { data, error } = await jsonApi.rpc(
      "remove_driver_contract_template",
      { p_route_id: id },
    )
    if (error) {
      const isInUse = error.message
        .toLowerCase()
        .includes("contrato em uso por passageiros ativos")
      throw new Error(
        isInUse ? "Contrato em uso por passageiros ativos" : error.message,
      )
    }
    const row = (Array.isArray(data) ? data[0] : data) as DriverRouteRow
    return toRoute(row)
  },

  async deleteMyRoute(id: string) {
    const { data, error } = await jsonApi.rpc("delete_driver_route", {
      p_route_id: id,
    })
    if (error) throw databaseError(error)
    return data as "deleted" | "archived"
  },

  async saveRouteDraft(id: string, route: RouteInput) {
    const { error } = await jsonApi.rpc("save_driver_route_draft", {
      p_route_id: id,
      p_payload: {
        name: route.name,
        origin: route.origin,
        destination: route.destination,
        university: route.university ?? route.destination,
        originNeighborhood: route.originNeighborhood ?? route.origin,
        departureTime: route.departureTime,
        arrivalTime: route.arrivalTime ?? route.returnTime,
        returnTime: route.returnTime,
        seats: route.seats,
        days: route.days,
        vehicle: route.vehicle ?? "",
        pickupPoints: route.pickupPoints ?? [],
      },
    })
    if (error) throw databaseError(error)
  },

  async publishRouteDraft(id: string) {
    const { data, error } = await jsonApi.rpc("publish_driver_route_draft", {
      p_route_id: id,
    })
    if (error) throw databaseError(error)
    return { ...toRoute(data as DriverRouteRow), hasPendingUpdate: false }
  },
}
