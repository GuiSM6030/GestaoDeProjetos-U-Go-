import { useEffect, useMemo, useState } from "react"
import { supabase } from "../../lib/supabase"
import {
  adminService,
  type DriverApplication,
} from "../../features/admin/services/adminService"

interface Props {
  onLogout: () => void
}

const statusLabels = {
  pending: "Em análise",
  approved: "Aprovado",
  rejected: "Reprovado",
}

export default function AdminDashboard({ onLogout }: Props) {
  const [applications, setApplications] = useState<DriverApplication[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [reviewingId, setReviewingId] = useState("")
  const [rejectingId, setRejectingId] = useState("")
  const [rejectionReason, setRejectionReason] = useState("")

  const pending = useMemo(
    () => applications.filter((application) => application.status === "pending"),
    [applications],
  )
  const reviewed = useMemo(
    () => applications.filter((application) => application.status !== "pending"),
    [applications],
  )

  const loadApplications = async () => {
    setLoading(true)
    setError("")
    try {
      setApplications(await adminService.listDriverApplications())
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : "Não foi possível carregar as solicitações.",
      )
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadApplications()
  }, [])

  const review = async (
    application: DriverApplication,
    status: "approved" | "rejected",
  ) => {
    if (status === "rejected" && !rejectionReason.trim()) {
      setError("Informe o motivo da reprovação.")
      return
    }
    setReviewingId(application.userId)
    setError("")
    try {
      const updated = await adminService.reviewDriverApplication(
        application.userId,
        status,
        rejectionReason.trim(),
      )
      setApplications((current) =>
        current.map((item) =>
          item.userId === updated.userId ? updated : item,
        ),
      )
      setRejectingId("")
      setRejectionReason("")
    } catch (reviewError) {
      setError(
        reviewError instanceof Error
          ? reviewError.message
          : "Não foi possível atualizar a solicitação.",
      )
    } finally {
      setReviewingId("")
    }
  }

  const logout = async () => {
    await supabase.auth.signOut()
    onLogout()
  }

  return (
    <div
      className="min-h-screen"
      style={{
        background: "linear-gradient(135deg, #0d0520 0%, #1a0840 100%)",
      }}
    >
      <header className="border-b border-purple-500/15 bg-white/[0.02]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-600">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.5}
                className="h-5 w-5 text-white"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.75c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.751A11.959 11.959 0 0 1 12 2.714Z"
                />
              </svg>
            </div>
            <div>
              <p className="font-display text-lg font-bold text-white">
                Administração U-Go
              </p>
              <p className="text-xs text-purple-300/45">
                Análise cadastral de motoristas
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={logout}
            className="rounded-xl border border-purple-500/20 px-4 py-2 text-sm font-medium text-purple-200 transition-colors hover:bg-purple-500/10"
          >
            Sair
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="mb-1 text-sm font-medium text-purple-400">
              Central de aprovações
            </p>
            <h1 className="font-display text-3xl font-bold text-white">
              Solicitações de motoristas
            </h1>
            <p className="mt-2 text-sm text-purple-200/50">
              Confira os documentos e dados do veículo antes de liberar o
              acesso.
            </p>
          </div>
          <button
            type="button"
            onClick={loadApplications}
            disabled={loading}
            className="rounded-xl bg-purple-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-purple-500 disabled:opacity-50"
          >
            {loading ? "Atualizando..." : "Atualizar lista"}
          </button>
        </div>

        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          {[
            { label: "Pendentes", value: pending.length, tone: "text-amber-300" },
            {
              label: "Aprovados",
              value: applications.filter((item) => item.status === "approved")
                .length,
              tone: "text-green-300",
            },
            {
              label: "Reprovados",
              value: applications.filter((item) => item.status === "rejected")
                .length,
              tone: "text-red-300",
            },
          ].map((item) => (
            <div
              key={item.label}
              className="rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5"
            >
              <p className={`font-display text-3xl font-bold ${item.tone}`}>
                {item.value}
              </p>
              <p className="mt-1 text-sm text-purple-200/50">{item.label}</p>
            </div>
          ))}
        </div>

        {error && (
          <p
            className="mb-6 rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm text-red-200"
            aria-live="polite"
          >
            {error}
          </p>
        )}

        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-xl font-semibold text-white">
              Aguardando análise
            </h2>
            <span className="rounded-full bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-200">
              {pending.length} {pending.length === 1 ? "pendência" : "pendências"}
            </span>
          </div>

          {loading ? (
            <div className="rounded-2xl border border-purple-500/15 bg-white/[0.03] py-16 text-center text-sm text-purple-300/45">
              Carregando solicitações...
            </div>
          ) : pending.length === 0 ? (
            <div className="rounded-2xl border border-purple-500/15 bg-white/[0.03] py-16 text-center">
              <p className="font-medium text-purple-100">
                Nenhuma solicitação pendente
              </p>
              <p className="mt-1 text-sm text-purple-300/40">
                Novos cadastros aparecerão aqui automaticamente.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {pending.map((application) => (
                <article
                  key={application.userId}
                  className="rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5"
                >
                  <div className="flex flex-col justify-between gap-5 lg:flex-row">
                    <div className="min-w-0 flex-1">
                      <div className="mb-4 flex flex-wrap items-center gap-3">
                        <h3 className="font-display text-lg font-semibold text-white">
                          {application.fullName || "Motorista sem nome"}
                        </h3>
                        <span className="rounded-full bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-200">
                          Em análise
                        </span>
                      </div>
                      <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2 xl:grid-cols-3">
                        {[
                          ["E-mail", application.email],
                          ["CPF", application.cpf || "Não informado"],
                          ["CNH", application.cnh || "Não informada"],
                          ["Placa", application.plate || "Não informada"],
                          ["Veículo", application.vehicle || "Não informado"],
                          ["Vagas", String(application.seats)],
                        ].map(([label, value]) => (
                          <div key={label}>
                            <dt className="text-xs text-purple-300/40">
                              {label}
                            </dt>
                            <dd className="mt-0.5 break-words text-purple-100/85">
                              {value}
                            </dd>
                          </div>
                        ))}
                      </dl>
                      <p className="mt-4 text-xs text-purple-300/35">
                        Recebido em{" "}
                        {new Date(application.createdAt).toLocaleString(
                          "pt-BR",
                        )}
                      </p>
                    </div>

                    <div className="flex shrink-0 flex-col gap-2 lg:w-44">
                      <button
                        type="button"
                        onClick={() => review(application, "approved")}
                        disabled={reviewingId === application.userId}
                        className="rounded-xl bg-green-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-green-500 disabled:opacity-50"
                      >
                        {reviewingId === application.userId
                          ? "Salvando..."
                          : "Aprovar"}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setRejectingId(application.userId)
                          setRejectionReason("")
                          setError("")
                        }}
                        disabled={reviewingId === application.userId}
                        className="rounded-xl border border-red-500/30 px-4 py-2.5 text-sm font-semibold text-red-300 transition-colors hover:bg-red-500/10 disabled:opacity-50"
                      >
                        Reprovar
                      </button>
                    </div>
                  </div>

                  {rejectingId === application.userId && (
                    <div className="mt-5 rounded-xl border border-red-500/20 bg-red-500/[0.06] p-4">
                      <label className="mb-2 block text-sm font-medium text-red-100">
                        Motivo da reprovação
                      </label>
                      <textarea
                        value={rejectionReason}
                        onChange={(event) =>
                          setRejectionReason(event.target.value)
                        }
                        rows={3}
                        placeholder="Explique o que precisa ser corrigido no cadastro"
                        className="w-full resize-none rounded-xl border border-red-500/20 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-red-400"
                      />
                      <div className="mt-3 flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setRejectingId("")
                            setRejectionReason("")
                          }}
                          className="rounded-xl px-4 py-2 text-sm font-medium text-purple-200/70 hover:bg-white/5"
                        >
                          Cancelar
                        </button>
                        <button
                          type="button"
                          onClick={() => review(application, "rejected")}
                          disabled={
                            reviewingId === application.userId ||
                            !rejectionReason.trim()
                          }
                          className="rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-500 disabled:opacity-40"
                        >
                          Confirmar reprovação
                        </button>
                      </div>
                    </div>
                  )}
                </article>
              ))}
            </div>
          )}
        </section>

        {reviewed.length > 0 && (
          <section className="mt-10">
            <h2 className="mb-4 font-display text-xl font-semibold text-white">
              Histórico recente
            </h2>
            <div className="overflow-hidden rounded-2xl border border-purple-500/15 bg-white/[0.03]">
              {reviewed.slice(0, 10).map((application, index) => (
                <div
                  key={application.userId}
                  className={`flex flex-col justify-between gap-3 px-5 py-4 sm:flex-row sm:items-center ${
                    index > 0 ? "border-t border-purple-500/10" : ""
                  }`}
                >
                  <div>
                    <p className="font-medium text-purple-100">
                      {application.fullName}
                    </p>
                    <p className="mt-0.5 text-xs text-purple-300/40">
                      {application.email} · {application.plate}
                    </p>
                  </div>
                  <span
                    className={`w-fit rounded-full px-2.5 py-1 text-xs font-medium ${
                      application.status === "approved"
                        ? "bg-green-500/10 text-green-300"
                        : "bg-red-500/10 text-red-300"
                    }`}
                  >
                    {statusLabels[application.status]}
                  </span>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  )
}
