import { useState } from "react"
import { publicAnonKey } from "../../utils/supabase/info"
import { EDGE_FUNCTION_URL, supabase } from "../lib/supabase"
import { getEmailRedirectUrl, getFriendlySignUpError } from "../lib/auth"
import {
  validateCPF,
  validateCNH,
  validateCNPJ,
  validatePlate,
  formatCPF,
  formatCNPJ,
  formatPhone,
  formatCNH,
  formatPlate,
} from "../lib/validators"
import type {
  UserRole,
  StudentForm,
  DriverForm,
  CompanyForm,
  CollaboratorForm,
} from "../types"

interface Props {
  role: UserRole
  onBack: () => void
  onSuccess: (email: string) => void
}

const roleLabels: Record<UserRole, string> = {
  student: "Universitário",
  driver: "Motorista",
  company: "Empresa",
  collaborator: "Colaborador",
}

function InputField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  required = false,
  error,
  hint,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
  placeholder?: string
  required?: boolean
  error?: string
  hint?: string
}) {
  const [focused, setFocused] = useState(false)
  return (
    <div>
      <label className="block text-sm font-medium text-purple-200/80 mb-1.5">
        {label}
        {required && <span className="text-purple-400 ml-1">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-3 rounded-xl text-white placeholder-purple-300/30 border transition-all duration-200 text-sm"
        style={{
          background: "rgba(255,255,255,0.05)",
          borderColor: error
            ? "rgba(239,68,68,0.6)"
            : focused
              ? "#9333ea"
              : "rgba(147,51,234,0.25)",
        }}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
      />
      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
      {hint && !error && (
        <p className="text-xs text-purple-300/40 mt-1">{hint}</p>
      )}
    </div>
  )
}

function PasswordField({
  label,
  value,
  onChange,
  required = false,
  error,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  required?: boolean
  error?: string
}) {
  const [show, setShow] = useState(false)
  const [focused, setFocused] = useState(false)
  return (
    <div>
      <label className="block text-sm font-medium text-purple-200/80 mb-1.5">
        {label}
        {required && <span className="text-purple-400 ml-1">*</span>}
      </label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="••••••••"
          className="w-full px-4 py-3 pr-12 rounded-xl text-white placeholder-purple-300/30 border transition-all duration-200 text-sm"
          style={{
            background: "rgba(255,255,255,0.05)",
            borderColor: error
              ? "rgba(239,68,68,0.6)"
              : focused
                ? "#9333ea"
                : "rgba(147,51,234,0.25)",
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-300/40 hover:text-purple-300"
        >
          {show ? (
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.5}
              className="w-4 h-4"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88"
              />
            </svg>
          ) : (
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.5}
              className="w-4 h-4"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
              />
            </svg>
          )}
        </button>
      </div>
      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
    </div>
  )
}

function cpfError(v: string) {
  if (!v) return ""
  const digits = v.replace(/\D/g, "")
  if (digits.length < 11) return ""
  return validateCPF(v) ? "" : "CPF inválido"
}

function cnhError(v: string) {
  if (!v) return ""
  if (v.length < 11) return ""
  return validateCNH(v) ? "" : "CNH inválida"
}

function cnpjError(v: string) {
  if (!v) return ""
  const digits = v.replace(/\D/g, "")
  if (digits.length < 14) return ""
  return validateCNPJ(v) ? "" : "CNPJ inválido"
}

function plateError(v: string) {
  if (!v) return ""
  const raw = v.replace(/[^A-Z0-9]/gi, "")
  if (raw.length < 7) return ""
  return validatePlate(v) ? "" : "Placa inválida (use formato Mercosul ABC1D23)"
}

function StudentFormComponent({
  onSubmit,
  loading,
  globalError,
}: {
  onSubmit: (data: StudentForm) => void
  loading: boolean
  globalError: string
}) {
  const [form, setForm] = useState<StudentForm>({
    fullName: "",
    phone: "",
    cpf: "",
    email: "",
    password: "",
    university: "",
  })
  const [errors, setErrors] = useState<Partial<StudentForm>>({})

  const set = (field: keyof StudentForm) => (v: string) => {
    setForm((f) => ({ ...f, [field]: v }))
    if (field === "cpf") setErrors((e) => ({ ...e, cpf: cpfError(v) }))
  }

  const validate = () => {
    const e: Partial<StudentForm> = {}
    if (!form.fullName.trim()) e.fullName = "Nome obrigatório"
    if (!form.cpf) e.cpf = "CPF obrigatório"
    else if (!validateCPF(form.cpf)) e.cpf = "CPF inválido"
    if (!form.email) e.email = "E-mail obrigatório"
    if (!form.password || form.password.length < 6)
      e.password = "Senha deve ter ao menos 6 caracteres"
    return e
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    setErrors(errs)
    if (Object.keys(errs).length === 0) onSubmit(form)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <InputField
        label="Nome completo"
        value={form.fullName}
        onChange={set("fullName")}
        placeholder="Digite seu nome completo"
        required
        error={errors.fullName}
      />
      <div className="grid grid-cols-2 gap-4">
        <InputField
          label="Telefone"
          value={form.phone}
          onChange={(v) => set("phone")(formatPhone(v))}
          placeholder="(11) 99999-9999"
        />
        <InputField
          label="CPF"
          value={form.cpf}
          onChange={(v) => set("cpf")(formatCPF(v))}
          placeholder="000.000.000-00"
          required
          error={errors.cpf}
        />
      </div>
      <InputField
        label="E-mail"
        value={form.email}
        onChange={set("email")}
        type="email"
        placeholder="seu@email.com"
        required
        error={errors.email}
      />
      <PasswordField
        label="Senha"
        value={form.password}
        onChange={set("password")}
        required
        error={errors.password}
      />
      <InputField
        label="Universidade"
        value={form.university}
        onChange={set("university")}
        placeholder="Nome da universidade"
      />

      {globalError && <ErrorBanner message={globalError} />}

      <SubmitButton loading={loading} label="Criar conta de Universitário" />
    </form>
  )
}

function DriverFormComponent({
  onSubmit,
  loading,
  globalError,
}: {
  onSubmit: (data: DriverForm) => void
  loading: boolean
  globalError: string
}) {
  const [form, setForm] = useState<DriverForm>({
    fullName: "",
    phone: "",
    cpf: "",
    email: "",
    password: "",
    vehicle: "",
    plate: "",
    cnh: "",
    seats: "",
  })
  const [errors, setErrors] = useState<Partial<DriverForm>>({})

  const set = (field: keyof DriverForm) => (v: string) => {
    setForm((f) => ({ ...f, [field]: v }))
    if (field === "cpf") setErrors((e) => ({ ...e, cpf: cpfError(v) }))
    if (field === "cnh") setErrors((e) => ({ ...e, cnh: cnhError(v) }))
    if (field === "plate") setErrors((e) => ({ ...e, plate: plateError(v) }))
  }

  const validate = () => {
    const e: Partial<DriverForm> = {}
    if (!form.fullName.trim()) e.fullName = "Nome obrigatório"
    if (!form.cpf) e.cpf = "CPF obrigatório"
    else if (!validateCPF(form.cpf)) e.cpf = "CPF inválido"
    if (!form.cnh) e.cnh = "CNH obrigatória"
    else if (!validateCNH(form.cnh)) e.cnh = "CNH inválida"
    if (!form.email) e.email = "E-mail obrigatório"
    if (!form.password || form.password.length < 6)
      e.password = "Senha deve ter ao menos 6 caracteres"
    if (!form.vehicle.trim()) e.vehicle = "Veículo obrigatório"
    if (form.plate && !validatePlate(form.plate))
      e.plate = "Placa inválida (use Mercosul ABC1D23)"
    return e
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    setErrors(errs)
    if (Object.keys(errs).length === 0) onSubmit(form)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <InputField
        label="Nome completo"
        value={form.fullName}
        onChange={set("fullName")}
        placeholder="Digite seu nome completo"
        required
        error={errors.fullName}
      />
      <div className="grid grid-cols-2 gap-4">
        <InputField
          label="Telefone"
          value={form.phone}
          onChange={(v) => set("phone")(formatPhone(v))}
          placeholder="(11) 99999-9999"
        />
        <InputField
          label="CPF"
          value={form.cpf}
          onChange={(v) => set("cpf")(formatCPF(v))}
          placeholder="000.000.000-00"
          required
          error={errors.cpf}
        />
      </div>
      <InputField
        label="E-mail"
        value={form.email}
        onChange={set("email")}
        type="email"
        placeholder="seu@email.com"
        required
        error={errors.email}
      />
      <PasswordField
        label="Senha"
        value={form.password}
        onChange={set("password")}
        required
        error={errors.password}
      />
      <div className="grid grid-cols-2 gap-4">
        <InputField
          label="Veículo"
          value={form.vehicle}
          onChange={set("vehicle")}
          placeholder="Toyota Hiace"
          required
          error={errors.vehicle}
        />
        <InputField
          label="Placa (Mercosul)"
          value={form.plate}
          onChange={(v) => set("plate")(formatPlate(v))}
          placeholder="ABC-1D23"
          error={errors.plate}
          hint="Formato Mercosul"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <InputField
          label="CNH"
          value={form.cnh}
          onChange={(v) => set("cnh")(formatCNH(v))}
          placeholder="00000000000"
          required
          error={errors.cnh}
          hint="11 dígitos"
        />
        <InputField
          label="Vagas no veículo"
          value={form.seats}
          onChange={set("seats")}
          type="number"
          placeholder="10"
        />
      </div>

      {globalError && <ErrorBanner message={globalError} />}
      <SubmitButton loading={loading} label="Criar conta de Motorista" />
    </form>
  )
}

function CompanyFormComponent({
  onSubmit,
  loading,
  globalError,
}: {
  onSubmit: (data: CompanyForm) => void
  loading: boolean
  globalError: string
}) {
  const [form, setForm] = useState<CompanyForm>({
    razaoSocial: "",
    nomeFantasia: "",
    cnpj: "",
    email: "",
    password: "",
  })
  const [errors, setErrors] = useState<Partial<CompanyForm>>({})

  const set = (field: keyof CompanyForm) => (v: string) => {
    setForm((f) => ({ ...f, [field]: v }))
    if (field === "cnpj") setErrors((e) => ({ ...e, cnpj: cnpjError(v) }))
  }

  const validate = () => {
    const e: Partial<CompanyForm> = {}
    if (!form.razaoSocial.trim()) e.razaoSocial = "Razão social obrigatória"
    if (!form.nomeFantasia.trim()) e.nomeFantasia = "Nome fantasia obrigatório"
    if (!form.cnpj) e.cnpj = "CNPJ obrigatório"
    else if (!validateCNPJ(form.cnpj)) e.cnpj = "CNPJ inválido"
    if (!form.email) e.email = "E-mail obrigatório"
    if (!form.password || form.password.length < 6)
      e.password = "Senha deve ter ao menos 6 caracteres"
    return e
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    setErrors(errs)
    if (Object.keys(errs).length === 0) onSubmit(form)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <InputField
        label="Razão Social"
        value={form.razaoSocial}
        onChange={set("razaoSocial")}
        placeholder="Razão social da empresa"
        required
        error={errors.razaoSocial}
      />
      <InputField
        label="Nome Fantasia"
        value={form.nomeFantasia}
        onChange={set("nomeFantasia")}
        placeholder="Nome fantasia da empresa"
        required
        error={errors.nomeFantasia}
      />
      <InputField
        label="CNPJ"
        value={form.cnpj}
        onChange={(v) => set("cnpj")(formatCNPJ(v))}
        placeholder="00.000.000/0000-00"
        required
        error={errors.cnpj}
      />
      <InputField
        label="E-mail"
        value={form.email}
        onChange={set("email")}
        type="email"
        placeholder="contato@empresa.com.br"
        required
        error={errors.email}
      />
      <PasswordField
        label="Senha"
        value={form.password}
        onChange={set("password")}
        required
        error={errors.password}
      />

      {globalError && <ErrorBanner message={globalError} />}
      <SubmitButton loading={loading} label="Criar conta Empresarial" />
    </form>
  )
}

function CollaboratorFormComponent({
  onSubmit,
  loading,
  globalError,
}: {
  onSubmit: (data: CollaboratorForm) => void
  loading: boolean
  globalError: string
}) {
  const [form, setForm] = useState<CollaboratorForm>({
    fullName: "",
    phone: "",
    cpf: "",
    email: "",
    password: "",
    company: "",
  })
  const [errors, setErrors] = useState<Partial<CollaboratorForm>>({})

  const set = (field: keyof CollaboratorForm) => (v: string) => {
    setForm((f) => ({ ...f, [field]: v }))
    if (field === "cpf") setErrors((e) => ({ ...e, cpf: cpfError(v) }))
  }

  const validate = () => {
    const e: Partial<CollaboratorForm> = {}
    if (!form.fullName.trim()) e.fullName = "Nome obrigatório"
    if (!form.cpf) e.cpf = "CPF obrigatório"
    else if (!validateCPF(form.cpf)) e.cpf = "CPF inválido"
    if (!form.email) e.email = "E-mail obrigatório"
    if (!form.password || form.password.length < 6)
      e.password = "Senha deve ter ao menos 6 caracteres"
    return e
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    setErrors(errs)
    if (Object.keys(errs).length === 0) onSubmit(form)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <InputField
        label="Nome completo"
        value={form.fullName}
        onChange={set("fullName")}
        placeholder="Digite seu nome completo"
        required
        error={errors.fullName}
      />
      <div className="grid grid-cols-2 gap-4">
        <InputField
          label="Telefone"
          value={form.phone}
          onChange={(v) => set("phone")(formatPhone(v))}
          placeholder="(11) 99999-9999"
        />
        <InputField
          label="CPF"
          value={form.cpf}
          onChange={(v) => set("cpf")(formatCPF(v))}
          placeholder="000.000.000-00"
          required
          error={errors.cpf}
        />
      </div>
      <InputField
        label="E-mail"
        value={form.email}
        onChange={set("email")}
        type="email"
        placeholder="seu@email.com"
        required
        error={errors.email}
      />
      <PasswordField
        label="Senha"
        value={form.password}
        onChange={set("password")}
        required
        error={errors.password}
      />
      <InputField
        label="Empresa"
        value={form.company}
        onChange={set("company")}
        placeholder="Nome da sua empresa"
      />

      {globalError && <ErrorBanner message={globalError} />}
      <SubmitButton loading={loading} label="Criar conta de Colaborador" />
    </form>
  )
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div
      className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-500/30 text-red-300 text-sm"
      style={{ background: "rgba(239,68,68,0.1)" }}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.5}
        className="w-4 h-4 shrink-0"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
        />
      </svg>
      {message}
    </div>
  )
}

function SubmitButton({
  loading,
  label,
}: {
  loading: boolean
  label: string
}) {
  return (
    <button
      type="submit"
      disabled={loading}
      className="w-full py-3 rounded-xl font-semibold text-white transition-all duration-200 disabled:opacity-50 mt-2"
      style={{
        background: loading
          ? "rgba(147,51,234,0.5)"
          : "linear-gradient(135deg, #9333ea, #7e22ce)",
      }}
    >
      {loading ? (
        <span className="flex items-center justify-center gap-2">
          <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
            />
          </svg>
          Criando conta...
        </span>
      ) : (
        label
      )}
    </button>
  )
}

async function doSignUp(
  email: string,
  password: string,
  metadata: Record<string, any>,
): Promise<void> {
  const availabilityResponse = await fetch(
    `${EDGE_FUNCTION_URL}/registration/check`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${publicAnonKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, cpf: metadata.cpf }),
    },
  )
  const availability = await availabilityResponse.json()
  if (!availabilityResponse.ok) {
    throw new Error(
      availability.error ?? "Não foi possível validar os dados do cadastro.",
    )
  }
  if (availability.emailExists) throw new Error("email_already_exists")
  if (availability.cpfExists) throw new Error("cpf_already_exists")

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: metadata,
      emailRedirectTo: getEmailRedirectUrl(),
    },
  })
  if (error) throw error
  if (data.user && data.user.identities?.length === 0) {
    throw new Error("email_already_exists")
  }
  // If session is null, email confirmation is required — treat as success (email sent)
  // If session exists, email confirmation is disabled — user is ready
  // Either way, we proceed; onSuccess handles the UI state
}

export default function RegisterPage({ role, onBack, onSuccess }: Props) {
  const [loading, setLoading] = useState(false)
  const [globalError, setGlobalError] = useState("")

  const handleStudentSubmit = async (data: StudentForm) => {
    setLoading(true)
    setGlobalError("")
    try {
      await doSignUp(data.email, data.password, {
        role: "student",
        full_name: data.fullName,
        phone: data.phone,
        cpf: data.cpf,
        university: data.university,
      })
      onSuccess(data.email)
    } catch (err: any) {
      setGlobalError(getFriendlySignUpError(err))
    } finally {
      setLoading(false)
    }
  }

  const handleDriverSubmit = async (data: DriverForm) => {
    setLoading(true)
    setGlobalError("")
    try {
      await doSignUp(data.email, data.password, {
        role: "driver",
        full_name: data.fullName,
        phone: data.phone,
        cpf: data.cpf,
        vehicle: data.vehicle,
        plate: data.plate,
        cnh: data.cnh,
        seats: parseInt(data.seats) || 0,
      })
      onSuccess(data.email)
    } catch (err: any) {
      setGlobalError(getFriendlySignUpError(err))
    } finally {
      setLoading(false)
    }
  }

  const handleCompanySubmit = async (data: CompanyForm) => {
    setLoading(true)
    setGlobalError("")
    try {
      await doSignUp(data.email, data.password, {
        role: "company",
        razao_social: data.razaoSocial,
        nome_fantasia: data.nomeFantasia,
        cnpj: data.cnpj,
      })
      onSuccess(data.email)
    } catch (err: any) {
      setGlobalError(getFriendlySignUpError(err))
    } finally {
      setLoading(false)
    }
  }

  const handleCollaboratorSubmit = async (data: CollaboratorForm) => {
    setLoading(true)
    setGlobalError("")
    try {
      await doSignUp(data.email, data.password, {
        role: "collaborator",
        full_name: data.fullName,
        phone: data.phone,
        cpf: data.cpf,
        company: data.company,
      })
      onSuccess(data.email)
    } catch (err: any) {
      setGlobalError(getFriendlySignUpError(err))
    } finally {
      setLoading(false)
    }
  }

  const roleIcons: Record<string, string> = {
    student: "🎓",
    driver: "🚌",
    company: "🏢",
    collaborator: "👤",
  }
  const roleIcon = roleIcons[role] ?? "👤"

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background:
          "linear-gradient(135deg, #0d0520 0%, #1a0840 50%, #0d0520 100%)",
      }}
    >
      <div className="flex items-center justify-between px-8 py-5 border-b border-purple-500/10">
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
          >
            <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
              <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
            </svg>
          </div>
          <span
            className="text-lg font-bold text-white"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            U-Go
          </span>
        </div>
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-purple-300/60 hover:text-purple-200 text-sm transition-colors"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            className="w-4 h-4"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18"
            />
          </svg>
          Voltar
        </button>
      </div>

      <div className="flex-1 flex items-start justify-center px-6 py-10 overflow-y-auto">
        <div className="w-full max-w-lg">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">{roleIcon}</span>
            <span className="text-xs font-medium uppercase tracking-widest text-purple-400">
              Cadastro de {roleLabels[role]}
            </span>
          </div>
          <h1
            className="text-3xl font-bold text-white mb-2"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            Crie sua conta
          </h1>
          <p className="text-sm text-purple-200/50 mb-8">
            Após o cadastro, você receberá um e-mail de confirmação.
          </p>

          <div
            className="rounded-2xl border border-purple-500/15 p-6"
            style={{ background: "rgba(255,255,255,0.03)" }}
          >
            {role === "student" && (
              <StudentFormComponent
                onSubmit={handleStudentSubmit}
                loading={loading}
                globalError={globalError}
              />
            )}
            {role === "driver" && (
              <DriverFormComponent
                onSubmit={handleDriverSubmit}
                loading={loading}
                globalError={globalError}
              />
            )}
            {role === "company" && (
              <CompanyFormComponent
                onSubmit={handleCompanySubmit}
                loading={loading}
                globalError={globalError}
              />
            )}
            {role === "collaborator" && (
              <CollaboratorFormComponent
                onSubmit={handleCollaboratorSubmit}
                loading={loading}
                globalError={globalError}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
