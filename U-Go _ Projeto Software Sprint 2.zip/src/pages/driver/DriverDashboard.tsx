import { useEffect, useState } from "react"
import { supabase } from "../../lib/supabase"
import { driverRouteService } from "../../services/driverRouteService"
import { ContractsPanel, contractService } from "../../features/contracts"
import RouteMapModal from "../../components/RouteMapModal"
import PickupPointEditor from "../../components/PickupPointEditor"
import type { Route, Contract, PickupPoint } from "../../types"
import { NotificationsButton } from "../../features/notifications"
import { BankAccountPanel } from "../../features/banking"
import { DriverQrScanner } from "../../features/attendance"

interface Props {
  profile: any
  onLogout: () => void
}
type Tab = "overview" | "routes" | "attendance" | "contracts" | "banking"
const WEEK_DAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]

function Sidebar({
  tab,
  setTab,
  name,
  onLogout,
}: {
  tab: Tab
  setTab: (t: Tab) => void
  name: string
  onLogout: () => void
}) {
  const items: {
    id: Tab
    label: string
    icon: string
  }[] = [
    { id: "overview", label: "Visão geral", icon: "📊" },
    { id: "routes", label: "Minhas rotas", icon: "🗺️" },
    { id: "attendance", label: "Validar QR", icon: "QR" },
    { id: "contracts", label: "Contratos", icon: "📄" },
    { id: "banking", label: "Dados bancários", icon: "R$" },
  ]
  return (
    <aside
      className="w-60 shrink-0 flex flex-col border-r border-purple-500/10 py-6 px-4"
      style={{ background: "rgba(255,255,255,0.02)" }}
    >
      <div className="flex items-center gap-3 px-3 mb-8">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
        >
          <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
            <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
          </svg>
        </div>
        <span
          className="text-lg font-bold text-white"
          style={{ fontFamily: "Outfit, sans-serif" }}
        >
          U-Go
        </span>
      </div>
      <nav className="flex-1 space-y-1">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setTab(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
              tab === item.id
                ? "text-white"
                : "text-purple-300/50 hover:text-purple-200 hover:bg-white/5"
            }`}
            style={
              tab === item.id
                ? {
                    background: "rgba(147,51,234,0.2)",
                    borderLeft: "2px solid #9333ea",
                  }
                : {}
            }
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <NotificationsButton />
      <div className="px-3 py-2 mb-3">
        <p className="text-xs text-purple-300/40 truncate">{name}</p>
        <p className="text-xs text-purple-300/25">Motorista</p>
      </div>
      <button
        onClick={onLogout}
        className="flex items-center gap-2 px-3 py-2 text-sm text-purple-300/50 hover:text-red-400 transition-colors"
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          className="w-4 h-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"
          />
        </svg>
        Sair
      </button>
    </aside>
  )
}

function Modal({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: React.ReactNode
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
    >
      <div
        className="max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-purple-500/20 p-6"
        style={{ background: "#1a0840" }}
      >
        <div className="flex items-center justify-between mb-5">
          <h3
            className="text-lg font-semibold text-white"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            {title}
          </h3>
          <button
            onClick={onClose}
            className="text-purple-300/50 hover:text-white"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
  min,
  step,
  disabled = false,
  error = false,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  type?: string
  required?: boolean
  min?: number
  step?: number
  disabled?: boolean
  error?: boolean
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-purple-200/70 mb-1">
        {label}
        {required && <span className="ml-1 text-red-300">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        min={min}
        step={step}
        disabled={disabled}
        aria-invalid={error}
        className={`w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border focus:border-purple-500 transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
          error ? "border-red-500/70" : "border-purple-500/25"
        }`}
        style={{ background: "rgba(255,255,255,0.05)", outline: "none" }}
      />
    </div>
  )
}

export default function DriverDashboard({ profile, onLogout }: Props) {
  const [tab, setTab] = useState<Tab>("overview")
  const [routes, setRoutes] = useState<Route[]>([])
  const [contracts, setContracts] = useState<Contract[]>([])
  const [routeModal, setRouteModal] =
    useState<"add" | "edit" | "duplicate" | null>(null)
  const [editingRoute, setEditingRoute] = useState<Route | null>(null)
  const [mapRoute, setMapRoute] = useState<Route | null>(null)
  const [routeForm, setRouteForm] = useState({
    name: "",
    origin: "",
    destination: "",
    university: "",
    originNeighborhood: "",
    departureTime: "",
    arrivalTime: "",
    returnTime: "",
    seats: "",
    price: "",
  })
  const [routeDays, setRouteDays] = useState<string[]>([])
  const [pickupPoints, setPickupPoints] = useState<PickupPoint[]>([])
  const [routeError, setRouteError] = useState("")
  const [routesLoading, setRoutesLoading] = useState(true)
  const [routeSaving, setRouteSaving] = useState(false)
  const [contractTemplateRoute, setContractTemplateRoute] =
    useState<Route | null>(null)
  const [contractTemplateStep, setContractTemplateStep] =
    useState<"form" | "review">("form")
  const [contractTemplateForm, setContractTemplateForm] = useState({
    monthlyPrice: "",
    dueDay: "",
    minimumTermMonths: "3",
    terminationFeePercent: "20",
  })
  const [contractTemplateMissing, setContractTemplateMissing] =
    useState<string[]>([])
  const [contractTemplateError, setContractTemplateError] = useState("")
  const [contractTemplateSaving, setContractTemplateSaving] = useState(false)
  const [contractTemplateMessage, setContractTemplateMessage] = useState("")
  const [deleteContractTemplateRoute, setDeleteContractTemplateRoute] =
    useState<Route | null>(null)
  const [deleteContractTemplateError, setDeleteContractTemplateError] =
    useState("")
  const [deleteContractTemplateSaving, setDeleteContractTemplateSaving] =
    useState(false)
  const [deleteRouteConfirm, setDeleteRouteConfirm] = useState<Route | null>(
    null,
  )
  const [deleteRouteError, setDeleteRouteError] = useState("")
  const [deleteRouteSaving, setDeleteRouteSaving] = useState(false)
  const [draftRouteConfirm, setDraftRouteConfirm] = useState<Route | null>(null)
  const [draftPublishing, setDraftPublishing] = useState(false)
  const [routeMessage, setRouteMessage] = useState("")

  const name =
    profile?.full_name || profile?.email?.split("@")[0] || "Motorista"
  const firstName = name.split(" ")[0]

  const handleLogout = async () => {
    await supabase.auth.signOut()
    onLogout()
  }

  useEffect(() => {
    let active = true
    setRoutesLoading(true)
    driverRouteService
      .listMyRoutes()
      .then((items) => {
        if (active) setRoutes(items)
      })
      .catch((error) => {
        if (active)
          setRouteError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar suas rotas.",
          )
      })
      .finally(() => {
        if (active) setRoutesLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  useEffect(() => {
    contractService.listarContratosDoPrestador().then((result) => {
      if (result.success && result.data) setContracts(result.data)
    })
  }, [])

  const openAddRoute = () => {
    setRouteForm({
      name: "",
      origin: "",
      destination: "",
      university: "",
      originNeighborhood: "",
      departureTime: "",
      arrivalTime: "",
      returnTime: "",
      seats: String(profile?.seats || ""),
      price: "",
    })
    setRouteDays([])
    setPickupPoints([])
    setRouteError("")
    setEditingRoute(null)
    setRouteModal("add")
  }
  const openEditRoute = (r: Route) => {
    setEditingRoute(r)
    setRouteForm({
      name: r.name,
      origin: r.origin,
      destination: r.destination,
      university: r.university ?? r.destination,
      originNeighborhood: r.originNeighborhood ?? r.origin,
      departureTime: r.departureTime,
      arrivalTime: r.arrivalTime ?? r.returnTime,
      returnTime: r.returnTime,
      seats: String(r.seats),
      price: String(r.price),
    })
    setRouteDays(r.days)
    setPickupPoints(r.pickupPoints ?? [])
    setRouteError("")
    setRouteModal("edit")
  }
  const openDuplicateRoute = (route: Route) => {
    setEditingRoute(route)
    setRouteForm({
      name: route.name,
      origin: route.origin,
      destination: route.destination,
      university: route.university ?? route.destination,
      originNeighborhood: route.originNeighborhood ?? route.origin,
      departureTime: route.departureTime,
      arrivalTime: route.arrivalTime ?? route.returnTime,
      returnTime: route.returnTime,
      seats: String(route.seats),
      price: String(route.price),
    })
    setRouteDays(route.days)
    setPickupPoints(route.pickupPoints ?? [])
    setRouteError("")
    setRouteModal("duplicate")
  }
  const openContractTemplate = (route: Route) => {
    setContractTemplateRoute(route)
    setContractTemplateForm({
      monthlyPrice: String(route.price || ""),
      dueDay: String(route.dueDay ?? ""),
      minimumTermMonths: String(route.minimumTermMonths ?? 3),
      terminationFeePercent: String(route.earlyTerminationFeePercent ?? 20),
    })
    setContractTemplateStep("form")
    setContractTemplateError("")
    setContractTemplateMissing([])
    setContractTemplateMessage("")
  }
  const advanceContractTemplate = () => {
    const missing = Object.entries(contractTemplateForm)
      .filter(([, value]) => !value.trim())
      .map(([key]) => key)
    if (missing.length > 0) {
      setContractTemplateMissing(missing)
      setContractTemplateError("Preencha todos os campos obrigatórios.")
      return
    }
    const monthlyPrice = Number(contractTemplateForm.monthlyPrice)
    if (!Number.isFinite(monthlyPrice) || monthlyPrice <= 0) {
      setContractTemplateError("Informe um valor válido para a mensalidade")
      return
    }
    const dueDay = Number(contractTemplateForm.dueDay)
    if (!Number.isInteger(dueDay) || dueDay < 1 || dueDay > 28) {
      setContractTemplateError("Informe um dia de vencimento entre 1 e 28.")
      return
    }
    const minimumTermMonths = Number(contractTemplateForm.minimumTermMonths)
    const terminationFeePercent = Number(
      contractTemplateForm.terminationFeePercent,
    )
    if (
      !Number.isInteger(minimumTermMonths) ||
      minimumTermMonths < 0 ||
      terminationFeePercent < 0 ||
      terminationFeePercent > 100
    ) {
      setContractTemplateError("Informe condições contratuais válidas.")
      return
    }
    setContractTemplateMissing([])
    setContractTemplateError("")
    setContractTemplateStep("review")
  }
  const saveContractTemplate = async () => {
    if (!contractTemplateRoute) return
    setContractTemplateSaving(true)
    setContractTemplateError("")
    try {
      const updated = await driverRouteService.saveContractTemplate(
        contractTemplateRoute.id,
        Number(contractTemplateForm.monthlyPrice),
        Number(contractTemplateForm.dueDay),
        Number(contractTemplateForm.minimumTermMonths),
        Number(contractTemplateForm.terminationFeePercent),
      )
      setRoutes((items) =>
        items.map((route) =>
          route.id === updated.route.id ? updated.route : route,
        ),
      )
      setContractTemplateRoute(null)
      setContractTemplateMessage(
        updated.amendmentCreated
          ? `Contrato atualizado para novas adesões. Um aditivo foi enviado a ${updated.affectedStudents} estudante(s).`
          : `Modelo de contrato da rota ${updated.route.name} salvo e pronto para envio.`,
      )
    } catch (error) {
      setContractTemplateError(
        error instanceof Error
          ? error.message
          : "Não foi possível salvar o modelo de contrato.",
      )
    } finally {
      setContractTemplateSaving(false)
    }
  }
  const openDeleteContractTemplate = (route: Route) => {
    setDeleteContractTemplateRoute(route)
    setDeleteContractTemplateError("")
    setContractTemplateMessage("")
  }
  const removeContractTemplate = async () => {
    if (!deleteContractTemplateRoute) return
    setDeleteContractTemplateSaving(true)
    setDeleteContractTemplateError("")
    try {
      const updated = await driverRouteService.removeContractTemplate(
        deleteContractTemplateRoute.id,
      )
      setRoutes((items) =>
        items.map((route) => (route.id === updated.id ? updated : route)),
      )
      setDeleteContractTemplateRoute(null)
      setContractTemplateMessage(
        updated.contractTemplateArchivedAt
          ? `Modelo de contrato da rota ${updated.name} arquivado. O histórico financeiro foi preservado.`
          : `Modelo de contrato da rota ${updated.name} excluído.`,
      )
    } catch (error) {
      setDeleteContractTemplateError(
        error instanceof Error
          ? error.message
          : "Não foi possível excluir o contrato.",
      )
    } finally {
      setDeleteContractTemplateSaving(false)
    }
  }
  const saveRoute = async () => {
    const missingFields = [
      !routeForm.name.trim() && "nome da rota",
      !routeForm.origin.trim() && "origem",
      !routeForm.destination.trim() && "destino",
      !routeForm.university.trim() && "faculdade",
      !routeForm.originNeighborhood.trim() && "bairro de origem",
      !routeForm.departureTime && "horário de saída",
      !routeForm.arrivalTime && "horário de chegada",
      !routeForm.returnTime && "horário de retorno",
      !routeForm.seats && "vagas",
      !routeForm.price && "preço mensal",
    ].filter(Boolean)
    if (missingFields.length > 0) {
      setRouteError(
        `Preencha todos os campos obrigatórios: ${missingFields.join(", ")}.`,
      )
      return
    }
    const seats = Number(routeForm.seats)
    const price = Number(routeForm.price)
    if (!Number.isInteger(seats) || seats < 1) {
      setRouteError("Informe uma quantidade de vagas inteira e maior que zero.")
      return
    }
    if (!Number.isFinite(price) || price <= 0) {
      setRouteError("Informe um preço mensal maior que zero.")
      return
    }
    if (routeDays.length === 0) {
      setRouteError("Selecione ao menos um dia de funcionamento.")
      return
    }
    if (pickupPoints.length === 0) {
      setRouteError("Adicione ao menos um ponto de embarque no mapa.")
      return
    }
    if (pickupPoints.some((point) => !point.name.trim())) {
      setRouteError("Todos os pontos de embarque precisam de um nome.")
      return
    }
    if (
      pickupPoints.some((point) => !point.arrivalTime || !point.departureTime)
    ) {
      setRouteError(
        "Informe os horários previstos de chegada e partida em todos os pontos.",
      )
      return
    }
    const routeData = {
      ...routeForm,
      seats,
      occupiedSeats:
        routeModal === "edit" ? (editingRoute?.occupiedSeats ?? 0) : 0,
      price,
      days: routeDays,
      vehicle:
        routeModal === "duplicate"
          ? (editingRoute?.vehicle ?? "")
          : profile?.vehicle || editingRoute?.vehicle || "",
      pickupPoints,
    }
    setRouteSaving(true)
    try {
      if (routeModal === "add" || routeModal === "duplicate") {
        const created = await driverRouteService.createMyRoute(routeData)
        setRoutes((items) => [created, ...items])
      } else if (editingRoute) {
        await driverRouteService.saveRouteDraft(editingRoute.id, routeData)
        const updated = {
          ...editingRoute,
          ...routeData,
          id: editingRoute.id,
          hasPendingUpdate: true,
        }
        setRoutes((items) =>
          items.map((route) => (route.id === updated.id ? updated : route)),
        )
        setDraftRouteConfirm(updated)
      }
      setRouteModal(null)
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível salvar a rota.",
      )
    } finally {
      setRouteSaving(false)
    }
  }
  const deleteRoute = async () => {
    if (!deleteRouteConfirm) return
    setDeleteRouteSaving(true)
    setDeleteRouteError("")
    try {
      await driverRouteService.deleteMyRoute(deleteRouteConfirm.id)
      setRoutes((items) =>
        items.filter((route) => route.id !== deleteRouteConfirm.id),
      )
      setDeleteRouteConfirm(null)
      setRouteMessage("Rota excluída do catálogo de buscas.")
    } catch (error) {
      setDeleteRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível excluir a rota.",
      )
    } finally {
      setDeleteRouteSaving(false)
    }
  }
  const publishRouteDraft = async () => {
    if (!draftRouteConfirm) return
    setDraftPublishing(true)
    setRouteError("")
    try {
      const updated = await driverRouteService.publishRouteDraft(
        draftRouteConfirm.id,
      )
      setRoutes((items) =>
        items.map((route) => (route.id === updated.id ? updated : route)),
      )
      setDraftRouteConfirm(null)
      setRouteMessage(
        "Atualização publicada e passageiros vinculados notificados.",
      )
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível publicar a atualização.",
      )
    } finally {
      setDraftPublishing(false)
    }
  }
  const rf = (f: keyof typeof routeForm) => (v: string) => {
    setRouteError("")
    setRouteForm((x) => ({ ...x, [f]: v }))
  }

  const totalPassengers = routes.reduce((s, r) => s + r.occupiedSeats, 0)
  const totalSeats = routes.reduce((s, r) => s + r.seats, 0)
  const monthlyRevenue = contracts
    .filter((c) => c.status === "active")
    .reduce((s, c) => s + c.value, 0)

  return (
    <div
      className="min-h-screen flex"
      style={{
        background: "linear-gradient(135deg, #0d0520 0%, #1a0840 100%)",
      }}
    >
      <Sidebar tab={tab} setTab={setTab} name={name} onLogout={handleLogout} />

      <main className="flex-1 overflow-y-auto p-8">
        {tab === "overview" && (
          <div>
            <p className="text-purple-300/50 text-sm mb-1">
              Painel do Motorista 🚌
            </p>
            <h1
              className="text-3xl font-bold text-white mb-1"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              Olá, {firstName}!
            </h1>
            {profile?.vehicle && (
              <p className="text-purple-300/40 text-sm mb-6">
                {profile.vehicle} · {profile.plate}
              </p>
            )}

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                { label: "Rotas ativas", value: routes.length, icon: "🗺️" },
                { label: "Passageiros", value: totalPassengers, icon: "👥" },
                {
                  label: "Vagas livres",
                  value: totalSeats - totalPassengers,
                  icon: "💺",
                },
                {
                  label: "Receita mensal",
                  value: `R$ ${monthlyRevenue.toLocaleString("pt-BR")}`,
                  icon: "💰",
                },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl border border-purple-500/15 p-5"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  <div className="text-2xl mb-3">{s.icon}</div>
                  <div
                    className="text-2xl font-bold text-white mb-1"
                    style={{ fontFamily: "Outfit, sans-serif" }}
                  >
                    {s.value}
                  </div>
                  <div className="text-xs text-purple-300/50">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div
                className="rounded-2xl border border-purple-500/15 p-5"
                style={{ background: "rgba(255,255,255,0.03)" }}
              >
                <h2
                  className="font-semibold text-white mb-4"
                  style={{ fontFamily: "Outfit, sans-serif" }}
                >
                  Ocupação das rotas
                </h2>
                {routes.map((r) => (
                  <div key={r.id} className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-200/70">{r.name}</span>
                      <span className="text-purple-300/50">
                        {r.occupiedSeats}/{r.seats}
                      </span>
                    </div>
                    <div
                      className="h-2 rounded-full"
                      style={{ background: "rgba(147,51,234,0.1)" }}
                    >
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${Math.min((r.occupiedSeats / r.seats) * 100, 100)}%`,
                          background:
                            "linear-gradient(to right,#9333ea,#c084fc)",
                        }}
                      />
                    </div>
                  </div>
                ))}
                {routes.length === 0 && (
                  <p className="py-8 text-center text-sm text-purple-300/40">
                    Nenhuma rota cadastrada.
                  </p>
                )}
              </div>
              <div
                className="rounded-2xl border border-purple-500/15 p-5"
                style={{ background: "rgba(255,255,255,0.03)" }}
              >
                <h2
                  className="font-semibold text-white mb-4"
                  style={{ fontFamily: "Outfit, sans-serif" }}
                >
                  Contratos recentes
                </h2>
                {contracts.slice(0, 3).map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between mb-3"
                  >
                    <div>
                      <p className="text-sm text-white">{c.party}</p>
                      <p className="text-xs text-purple-300/40">{c.route}</p>
                    </div>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-full ${
                        c.status === "active"
                          ? "text-green-300"
                          : "text-purple-300/40"
                      }`}
                      style={{
                        background:
                          c.status === "active"
                            ? "rgba(34,197,94,0.1)"
                            : "rgba(255,255,255,0.05)",
                      }}
                    >
                      {c.status === "active"
                        ? "Ativo"
                        : c.status === "pending"
                          ? "Aguardando Pagamento"
                          : c.status === "cancelled"
                            ? "Cancelado"
                            : "Expirado"}
                    </span>
                  </div>
                ))}
                {contracts.length === 0 && (
                  <p className="py-8 text-center text-sm text-purple-300/40">
                    Nenhum contrato disponível.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {tab === "routes" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h1
                className="text-2xl font-bold text-white"
                style={{ fontFamily: "Outfit, sans-serif" }}
              >
                Minhas rotas
              </h1>
              <button
                onClick={openAddRoute}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
                style={{
                  background: "linear-gradient(135deg, #9333ea, #7e22ce)",
                }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  className="w-4 h-4"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 4.5v15m7.5-7.5h-15"
                  />
                </svg>
                Nova rota
              </button>
            </div>
            {routeError && !routeModal && (
              <p className="mb-4 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                {routeError}
              </p>
            )}
            {routeMessage && (
              <p
                className="mb-4 rounded-xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-200"
                role="status"
              >
                {routeMessage}
              </p>
            )}
            {contractTemplateMessage && (
              <p
                className="mb-4 rounded-xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-200"
                role="status"
              >
                {contractTemplateMessage}
              </p>
            )}
            <div className="space-y-4">
              {routesLoading && (
                <div className="py-16 text-center text-purple-300/40">
                  Carregando suas rotas...
                </div>
              )}
              {!routesLoading &&
                routes.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-2xl border border-purple-500/15 p-5"
                    style={{ background: "rgba(255,255,255,0.03)" }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="mb-1 flex flex-wrap items-center gap-2">
                          <h3
                            className="font-semibold text-white"
                            style={{ fontFamily: "Outfit, sans-serif" }}
                          >
                            {r.name}
                          </h3>
                          <span
                            className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                              r.contractTemplateReady
                                ? "bg-green-500/10 text-green-300"
                                : r.contractTemplateArchivedAt
                                  ? "bg-purple-500/10 text-purple-300"
                                  : "bg-amber-500/10 text-amber-300"
                            }`}
                          >
                            {r.contractTemplateReady
                              ? "Modelo pronto"
                              : r.contractTemplateArchivedAt
                                ? "Modelo arquivado"
                                : "Modelo pendente"}
                          </span>
                          {r.hasPendingUpdate && (
                            <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-[11px] font-medium text-amber-300">
                              Atualização em rascunho
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-purple-300/50 mb-3">
                          {r.origin} → {r.destination}
                        </p>
                        <div className="flex flex-wrap gap-4 text-xs text-purple-300/60">
                          <span>
                            Bairro: {r.originNeighborhood ?? r.origin}
                          </span>
                          <span>
                            Faculdade: {r.university ?? r.destination}
                          </span>
                          <span>
                            🕐 Saída {r.departureTime} · Chegada{" "}
                            {r.arrivalTime ?? r.returnTime} · Retorno{" "}
                            {r.returnTime}
                          </span>
                          <span>
                            💺 {r.occupiedSeats}/{r.seats} passageiros
                          </span>
                          <span>💰 R$ {r.price}/mês por passageiro</span>
                          {r.dueDay && <span>Vencimento: dia {r.dueDay}</span>}
                        </div>
                        <div className="mt-3">
                          <div className="flex gap-1">
                            {r.days.map((d) => (
                              <span
                                key={d}
                                className="text-xs px-2 py-0.5 rounded-full text-purple-300/60"
                                style={{ background: "rgba(147,51,234,0.1)" }}
                              >
                                {d}
                              </span>
                            ))}
                          </div>
                        </div>
                        {r.pickupPoints && r.pickupPoints.length > 0 && (
                          <div className="mt-4 border-t border-purple-500/10 pt-3">
                            <p className="mb-2 text-xs font-medium text-purple-200/70">
                              Pontos de embarque
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {r.pickupPoints.map((point, index) => (
                                <span
                                  key={point.id}
                                  className="inline-flex items-center gap-1.5 rounded-lg bg-purple-500/10 px-2.5 py-1 text-xs text-purple-200/70"
                                >
                                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-purple-600 text-[10px] font-bold text-white">
                                    {index + 1}
                                  </span>
                                  {point.name}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 ml-4">
                        {r.hasPendingUpdate && (
                          <button
                            type="button"
                            onClick={() => setDraftRouteConfirm(r)}
                            className="rounded-lg border border-amber-500/25 px-3 py-2 text-xs font-medium text-amber-300 hover:bg-amber-500/10"
                          >
                            Revisar e enviar
                          </button>
                        )}
                        <button
                          onClick={() => openContractTemplate(r)}
                          className="rounded-lg border border-purple-500/25 px-3 py-2 text-xs font-medium text-purple-200 transition-all hover:bg-purple-500/10"
                        >
                          {r.contractTemplateReady
                            ? "Editar contrato"
                            : "Cadastrar contrato"}
                        </button>
                        {r.contractTemplateReady && (
                          <button
                            type="button"
                            onClick={() => openDeleteContractTemplate(r)}
                            className="rounded-lg border border-red-500/25 px-3 py-2 text-xs font-medium text-red-300/80 transition-all hover:bg-red-500/10 hover:text-red-200"
                          >
                            Excluir Contrato
                          </button>
                        )}
                        <button
                          onClick={() => setMapRoute(r)}
                          className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                          title="Ver no mapa"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M9 6.75V15m6-6v8.25m.503 3.498 4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 0 0-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0Z"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => openDuplicateRoute(r)}
                          className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                          title="Duplicar rota"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75A1.125 1.125 0 0 1 3.75 20.625v-9.75c0-.621.504-1.125 1.125-1.125H8.25m7.5 7.5h3.375c.621 0 1.125-.504 1.125-1.125v-9.75c0-.621-.504-1.125-1.125-1.125h-9.75c-.621 0-1.125.504-1.125 1.125V9.75m7.5 7.5h-6.375A1.125 1.125 0 0 1 8.25 16.125V9.75"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => openEditRoute(r)}
                          className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                          title="Editar rota"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={() => {
                            setDeleteRouteError("")
                            setDeleteRouteConfirm(r)
                          }}
                          className="p-2 rounded-lg text-red-400/50 hover:text-red-400 hover:bg-red-500/10 transition-all"
                          title="Excluir Rota"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                            />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              {!routesLoading && routes.length === 0 && (
                <div className="text-center py-16 text-purple-300/40">
                  <p className="text-lg mb-2">Nenhuma rota cadastrada</p>
                  <p className="text-sm">Clique em "Nova rota" para começar</p>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "attendance" && <DriverQrScanner />}

        {tab === "contracts" && (
          <ContractsPanel
            contracts={contracts}
            viewerRole="driver"
            onContractChange={(updated) =>
              setContracts((items) =>
                items.map((item) => (item.id === updated.id ? updated : item)),
              )
            }
          />
        )}

        {tab === "banking" && <BankAccountPanel profile={profile} />}
      </main>

      {mapRoute && (
        <RouteMapModal route={mapRoute} onClose={() => setMapRoute(null)} />
      )}

      {routeModal && (
        <Modal
          title={
            routeModal === "add"
              ? "Nova rota"
              : routeModal === "duplicate"
                ? "Duplicar rota"
                : "Editar rota"
          }
          onClose={() => setRouteModal(null)}
        >
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault()
              saveRoute()
            }}
          >
            {routeModal === "duplicate" ? (
              <p className="rounded-xl border border-purple-500/20 bg-purple-500/10 px-3 py-2 text-sm text-purple-200/80">
                Os dados da rota original foram copiados. Altere apenas os
                horários para cadastrar a nova rota.
              </p>
            ) : (
              <p className="text-xs text-purple-300/50">
                <span className="text-red-300">*</span> Todos os campos são
                obrigatórios.
              </p>
            )}
            <Field
              label="Nome da rota"
              value={routeForm.name}
              onChange={rf("name")}
              placeholder="Origem → Destino"
              required
              disabled={routeModal === "duplicate"}
            />
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Origem"
                value={routeForm.origin}
                onChange={rf("origin")}
                placeholder="Endereço de saída"
                required
                disabled={routeModal === "duplicate"}
              />
              <Field
                label="Destino"
                value={routeForm.destination}
                onChange={rf("destination")}
                placeholder="Endereço de chegada"
                required
                disabled={routeModal === "duplicate"}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Bairro de origem"
                value={routeForm.originNeighborhood}
                onChange={rf("originNeighborhood")}
                placeholder="Ex.: Centro"
                required
                disabled={routeModal === "duplicate"}
              />
              <Field
                label="Faculdade atendida"
                value={routeForm.university}
                onChange={rf("university")}
                placeholder="Ex.: Universidade Federal"
                required
                disabled={routeModal === "duplicate"}
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field
                label="Horário de saída"
                value={routeForm.departureTime}
                onChange={rf("departureTime")}
                type="time"
                required
              />
              <Field
                label="Chegada ao destino"
                value={routeForm.arrivalTime}
                onChange={rf("arrivalTime")}
                type="time"
                required
              />
              <Field
                label="Saída para retorno"
                value={routeForm.returnTime}
                onChange={rf("returnTime")}
                type="time"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Vagas"
                value={routeForm.seats}
                onChange={rf("seats")}
                type="number"
                placeholder={String(profile?.seats || 10)}
                required
                min={1}
                step={1}
                disabled={routeModal === "duplicate"}
              />
              <Field
                label="Preço mensal (R$)"
                value={routeForm.price}
                onChange={rf("price")}
                type="number"
                placeholder="350"
                required
                min={0.01}
                step={0.01}
                disabled={routeModal === "duplicate"}
              />
            </div>
            <div>
              <p className="mb-2 text-xs font-medium text-purple-200/70">
                Dias de funcionamento
                <span className="ml-1 text-red-300">*</span>
              </p>
              <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
                {WEEK_DAYS.map((day) => {
                  const selected = routeDays.includes(day)
                  return (
                    <button
                      key={day}
                      type="button"
                      aria-pressed={selected}
                      disabled={routeModal === "duplicate"}
                      onClick={() => {
                        setRouteError("")
                        setRouteDays((current) =>
                          selected
                            ? current.filter((item) => item !== day)
                            : [...current, day],
                        )
                      }}
                      className={`rounded-xl border px-2 py-2 text-xs font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-60 ${
                        selected
                          ? "border-purple-400 bg-purple-600 text-white"
                          : "border-purple-500/20 bg-white/5 text-purple-300/60 hover:border-purple-400/50 hover:text-purple-200"
                      }`}
                    >
                      {day}
                    </button>
                  )
                })}
              </div>
            </div>
            <PickupPointEditor
              points={pickupPoints}
              onChange={(points) => {
                setPickupPoints(points)
                setRouteError("")
              }}
              readOnly={routeModal === "duplicate"}
            />
            {routeError && (
              <p className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                {routeError}
              </p>
            )}
            <button
              type="submit"
              disabled={routeSaving}
              className="w-full py-2.5 rounded-xl text-sm font-semibold text-white mt-2 disabled:opacity-50"
              style={{
                background: "linear-gradient(135deg, #9333ea, #7e22ce)",
              }}
            >
              {routeSaving
                ? "Salvando..."
                : routeModal === "add"
                  ? "Cadastrar rota"
                  : routeModal === "duplicate"
                    ? "Duplicar rota"
                    : "Salvar alterações"}
            </button>
          </form>
        </Modal>
      )}

      {deleteRouteConfirm && (
        <Modal
          title="Excluir Rota"
          onClose={() => {
            if (!deleteRouteSaving) setDeleteRouteConfirm(null)
          }}
        >
          <div className="space-y-5">
            <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-4">
              <h4 className="font-semibold text-white">
                Excluir {deleteRouteConfirm.name}?
              </h4>
              <p className="mt-2 text-sm leading-relaxed text-purple-100/65">
                A rota será removida do catálogo de buscas. Esta ação será
                bloqueada se existirem passageiros ou contratos ativos.
              </p>
            </div>
            {deleteRouteError && (
              <p
                className="rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-200"
                role="alert"
              >
                {deleteRouteError}
              </p>
            )}
            <div className="flex justify-end gap-3 border-t border-purple-500/15 pt-4">
              <button
                type="button"
                onClick={() => setDeleteRouteConfirm(null)}
                disabled={deleteRouteSaving}
                className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={deleteRoute}
                disabled={deleteRouteSaving}
                className="rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-500 disabled:opacity-50"
              >
                {deleteRouteSaving ? "Excluindo..." : "Confirmar exclusão"}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {draftRouteConfirm && (
        <Modal
          title="Enviar atualização da rota"
          onClose={() => {
            if (!draftPublishing) setDraftRouteConfirm(null)
          }}
        >
          <div className="space-y-5">
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-4">
              <p className="text-sm font-semibold text-amber-200">
                Alterações salvas como rascunho
              </p>
              <p className="mt-2 text-sm leading-relaxed text-purple-100/65">
                Confirme o envio para publicar horários, trajeto, vagas e pontos
                de parada. Os passageiros vinculados serão notificados.
              </p>
            </div>
            {routeError && (
              <p
                className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200"
                role="alert"
              >
                {routeError}
              </p>
            )}
            <div className="flex flex-col-reverse gap-3 border-t border-purple-500/15 pt-4 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setDraftRouteConfirm(null)}
                disabled={draftPublishing}
                className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10"
              >
                Manter como rascunho
              </button>
              <button
                type="button"
                onClick={publishRouteDraft}
                disabled={draftPublishing}
                className="rounded-xl bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-purple-500 disabled:opacity-50"
              >
                {draftPublishing
                  ? "Publicando..."
                  : "Confirmar e enviar aos alunos"}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {contractTemplateRoute && (
        <Modal
          title="Modelo de contrato"
          onClose={() => setContractTemplateRoute(null)}
        >
          {contractTemplateStep === "form" ? (
            <div className="space-y-5">
              <div className="rounded-xl border border-purple-500/15 bg-white/[0.03] p-4">
                <p className="text-xs font-medium uppercase tracking-wider text-purple-400">
                  Rota selecionada
                </p>
                <p className="mt-1 font-semibold text-white">
                  {contractTemplateRoute.name}
                </p>
                <p className="mt-1 text-sm text-purple-200/55">
                  {contractTemplateRoute.origin} →{" "}
                  {contractTemplateRoute.destination}
                </p>
              </div>

              <div>
                <h4 className="text-base font-semibold text-white">
                  Condições de pagamento
                </h4>
                <p className="mt-1 text-sm text-purple-200/55">
                  Estas informações serão incluídas no contrato enviado aos
                  estudantes interessados.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Valor mensal (R$)"
                  value={contractTemplateForm.monthlyPrice}
                  onChange={(value) => {
                    setContractTemplateForm((current) => ({
                      ...current,
                      monthlyPrice: value,
                    }))
                    setContractTemplateError("")
                    setContractTemplateMissing((items) =>
                      items.filter((item) => item !== "monthlyPrice"),
                    )
                  }}
                  type="number"
                  placeholder="350,00"
                  step={0.01}
                  required
                  error={contractTemplateMissing.includes("monthlyPrice")}
                />
                <Field
                  label="Dia de vencimento"
                  value={contractTemplateForm.dueDay}
                  onChange={(value) => {
                    setContractTemplateForm((current) => ({
                      ...current,
                      dueDay: value,
                    }))
                    setContractTemplateError("")
                    setContractTemplateMissing((items) =>
                      items.filter((item) => item !== "dueDay"),
                    )
                  }}
                  type="number"
                  placeholder="10"
                  min={1}
                  step={1}
                  required
                  error={contractTemplateMissing.includes("dueDay")}
                />
                <Field
                  label="Prazo mínimo (meses)"
                  value={contractTemplateForm.minimumTermMonths}
                  onChange={(value) => {
                    setContractTemplateForm((current) => ({
                      ...current,
                      minimumTermMonths: value,
                    }))
                    setContractTemplateError("")
                    setContractTemplateMissing((items) =>
                      items.filter((item) => item !== "minimumTermMonths"),
                    )
                  }}
                  type="number"
                  min={0}
                  step={1}
                  required
                  error={contractTemplateMissing.includes("minimumTermMonths")}
                />
                <Field
                  label="Multa por rescisão antecipada (%)"
                  value={contractTemplateForm.terminationFeePercent}
                  onChange={(value) => {
                    setContractTemplateForm((current) => ({
                      ...current,
                      terminationFeePercent: value,
                    }))
                    setContractTemplateError("")
                    setContractTemplateMissing((items) =>
                      items.filter((item) => item !== "terminationFeePercent"),
                    )
                  }}
                  type="number"
                  min={0}
                  step={0.01}
                  required
                  error={contractTemplateMissing.includes(
                    "terminationFeePercent",
                  )}
                />
              </div>

              {contractTemplateError && (
                <p
                  className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-200"
                  role="alert"
                >
                  {contractTemplateError}
                </p>
              )}

              <div className="flex justify-end gap-3 border-t border-purple-500/15 pt-4">
                <button
                  type="button"
                  onClick={() => setContractTemplateRoute(null)}
                  className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={advanceContractTemplate}
                  className="rounded-xl bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-purple-500"
                >
                  Avançar
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-purple-400">
                  Revisão do modelo
                </p>
                <h4 className="mt-1 text-lg font-semibold text-white">
                  Confirme as condições do contrato
                </h4>
              </div>

              <div className="grid gap-3 rounded-xl border border-purple-500/15 bg-white/[0.03] p-4 sm:grid-cols-2">
                <div>
                  <p className="text-xs text-purple-300/45">Rota</p>
                  <p className="mt-1 text-sm font-medium text-white">
                    {contractTemplateRoute.name}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-purple-300/45">Mensalidade</p>
                  <p className="mt-1 text-sm font-medium text-white">
                    {Number(contractTemplateForm.monthlyPrice).toLocaleString(
                      "pt-BR",
                      {
                        style: "currency",
                        currency: "BRL",
                      },
                    )}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-purple-300/45">Vencimento</p>
                  <p className="mt-1 text-sm font-medium text-white">
                    Todo dia {contractTemplateForm.dueDay}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-purple-300/45">Disponibilidade</p>
                  <p className="mt-1 text-sm font-medium text-green-300">
                    Pronto para envio após salvar
                  </p>
                </div>
                <div>
                  <p className="text-xs text-purple-300/45">Prazo mínimo</p>
                  <p className="mt-1 text-sm font-medium text-white">
                    {contractTemplateForm.minimumTermMonths} meses
                  </p>
                </div>
                <div>
                  <p className="text-xs text-purple-300/45">
                    Multa de rescisão
                  </p>
                  <p className="mt-1 text-sm font-medium text-white">
                    {contractTemplateForm.terminationFeePercent}%
                  </p>
                </div>
              </div>

              {contractTemplateError && (
                <p
                  className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-200"
                  role="alert"
                >
                  {contractTemplateError}
                </p>
              )}

              <div className="flex flex-col-reverse gap-3 border-t border-purple-500/15 pt-4 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={() => setContractTemplateStep("form")}
                  disabled={contractTemplateSaving}
                  className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10 disabled:opacity-50"
                >
                  Voltar
                </button>
                <button
                  type="button"
                  onClick={saveContractTemplate}
                  disabled={contractTemplateSaving}
                  className="rounded-xl bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-purple-500 disabled:opacity-50"
                >
                  {contractTemplateSaving
                    ? "Salvando..."
                    : contractTemplateRoute.contractTemplateReady
                      ? "Atualizar Contrato"
                      : "Salvar Modelo de Contrato"}
                </button>
              </div>
            </div>
          )}
        </Modal>
      )}

      {deleteContractTemplateRoute && (
        <Modal
          title="Excluir contrato"
          onClose={() => {
            if (!deleteContractTemplateSaving) {
              setDeleteContractTemplateRoute(null)
            }
          }}
        >
          <div className="space-y-5">
            <div className="flex items-start gap-4 rounded-xl border border-red-500/20 bg-red-500/10 p-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-500/15 text-red-300">
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.5}
                  className="h-5 w-5"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 9v3.75m9.303 3.376c.866 1.5-.217 3.374-1.948 3.374H4.645c-1.73 0-2.813-1.874-1.948-3.374L10.051 3.378c.866-1.5 3.032-1.5 3.898 0l7.354 12.748ZM12 15.75h.007v.008H12v-.008Z"
                  />
                </svg>
              </div>
              <div>
                <h4 className="font-semibold text-white">
                  Confirma a exclusão deste modelo?
                </h4>
                <p className="mt-1 text-sm leading-relaxed text-purple-100/60">
                  O modelo da rota{" "}
                  <strong className="text-white">
                    {deleteContractTemplateRoute.name}
                  </strong>{" "}
                  deixará de ser oferecido aos estudantes. Se houver histórico
                  financeiro, o documento será arquivado em vez de apagado.
                </p>
              </div>
            </div>

            {deleteContractTemplateError && (
              <p
                className="rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-200"
                role="alert"
              >
                {deleteContractTemplateError}
              </p>
            )}

            <div className="flex flex-col-reverse gap-3 border-t border-purple-500/15 pt-4 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setDeleteContractTemplateRoute(null)}
                disabled={deleteContractTemplateSaving}
                className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10 disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={removeContractTemplate}
                disabled={deleteContractTemplateSaving}
                className="rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-500 disabled:opacity-50"
              >
                {deleteContractTemplateSaving
                  ? "Excluindo..."
                  : "Confirmar exclusão"}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}
