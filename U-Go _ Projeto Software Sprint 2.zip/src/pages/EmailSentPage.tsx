import { useState } from "react"
import { supabase } from "../lib/supabase"
import { getEmailRedirectUrl } from "../lib/auth"
import type { UserRole } from "../types"

interface Props {
  email: string
  onLogin: () => void
  role?: UserRole
}

export default function EmailSentPage({ email, onLogin, role }: Props) {
  const [resending, setResending] = useState(false)
  const [message, setMessage] = useState("")

  const resendConfirmation = async () => {
    if (!email || resending) return
    setResending(true)
    setMessage("")

    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
      options: { emailRedirectTo: getEmailRedirectUrl() },
    })

    setMessage(
      error
        ? "Não foi possível reenviar agora. Aguarde alguns minutos e tente novamente."
        : "E-mail de confirmação reenviado.",
    )
    setResending(false)
  }

  return (
    <div
      className="flex min-h-screen items-center justify-center px-6"
      style={{
        background:
          "linear-gradient(135deg, #0d0520 0%, #1a0840 50%, #0d0520 100%)",
      }}
    >
      <div className="max-w-md text-center">
        <div
          className="mx-auto mb-8 flex h-24 w-24 items-center justify-center rounded-full"
          style={{
            background:
              "linear-gradient(135deg, rgba(34,197,94,0.15), rgba(147,51,234,0.15))",
            border: "1px solid rgba(34,197,94,0.3)",
          }}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.5}
            className="h-12 w-12 text-green-400"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21.75 6.75v10.5A2.25 2.25 0 0 1 19.5 19.5h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0-8.69 5.515a2.25 2.25 0 0 1-2.42 0L2.25 6.75"
            />
          </svg>
        </div>

        <h1
          className="mb-4 text-3xl font-bold text-white"
          style={{ fontFamily: "Outfit, sans-serif" }}
        >
          Confirme seu e-mail
        </h1>
        <p className="mb-3 leading-relaxed text-purple-200/65">
          Enviamos um link de confirmação para
        </p>
        <p className="mb-5 break-all font-semibold text-purple-200">
          {email || "o e-mail informado no cadastro"}
        </p>
        <p className="mb-8 text-sm leading-relaxed text-purple-300/45">
          {role === "driver"
            ? "Após confirmar o e-mail, seu cadastro será analisado pela equipe U-Go. Você poderá acessar a conta depois da aprovação."
            : "Abra o link recebido para ativar a conta. Verifique também as pastas de spam e lixo eletrônico."}
        </p>

        {message && (
          <p
            className="mb-4 rounded-xl border border-purple-500/20 bg-purple-500/10 px-4 py-3 text-sm text-purple-100"
            aria-live="polite"
          >
            {message}
          </p>
        )}

        <div className="space-y-3">
          <button
            type="button"
            onClick={onLogin}
            className="w-full rounded-xl py-3 font-semibold text-white transition-all"
            style={{
              background: "linear-gradient(135deg, #9333ea, #7e22ce)",
            }}
          >
            {role === "driver"
              ? "Acompanhar análise pelo login"
              : "Já confirmei, fazer login"}
          </button>
          <button
            type="button"
            onClick={resendConfirmation}
            disabled={!email || resending}
            className="w-full rounded-xl border border-purple-500/25 py-3 text-sm font-medium text-purple-200 transition-colors hover:bg-purple-500/10 disabled:opacity-40"
          >
            {resending ? "Reenviando..." : "Reenviar e-mail"}
          </button>
        </div>
      </div>
    </div>
  )
}
