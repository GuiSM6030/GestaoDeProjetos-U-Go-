import { useEffect, useState } from "react"
import { supabase } from "../../lib/supabase"
import RouteMapModal from "../../components/RouteMapModal"
import {
  ContractAcceptanceModal,
  ContractAmendmentsPanel,
  ContractsPanel,
  contractLifecycleService,
  contractService,
  type TerminationPreview,
} from "../../features/contracts"
import { driverRouteService } from "../../services/driverRouteService"
import { PaymentsPanel } from "../../features/payments"
import { NotificationsButton } from "../../features/notifications"
import type { Contract, Route } from "../../types"
import { StudentQrCard } from "../../features/attendance"

interface Props {
  profile: any
  onLogout: () => void
}
type Tab = "routes" | "my-routes" | "qr-code" | "contracts" | "payments"

const normalizeSearchText = (value: string) =>
  value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()

export default function StudentDashboard({ profile, onLogout }: Props) {
  const [tab, setTab] = useState<Tab>("routes")
  const [routeFilters, setRouteFilters] = useState({
    university: "",
    originNeighborhood: "",
    classTime: "",
  })
  const [appliedRouteFilters, setAppliedRouteFilters] =
    useState<typeof routeFilters | null>(null)
  const [joinedRoutes, setJoinedRoutes] = useState<Set<string>>(new Set())
  const [joinConfirm, setJoinConfirm] = useState<Route | null>(null)
  const [mapRoute, setMapRoute] = useState<Route | null>(null)
  const [contracts, setContracts] = useState<Contract[]>([])
  const [availableRoutes, setAvailableRoutes] = useState<Route[]>([])
  const [routesLoading, setRoutesLoading] = useState(true)
  const [routesError, setRoutesError] = useState("")
  const [joinError, setJoinError] = useState("")
  const [terminationContract, setTerminationContract] =
    useState<Contract | null>(null)
  const [terminationPreview, setTerminationPreview] =
    useState<TerminationPreview | null>(null)
  const [terminationLoading, setTerminationLoading] = useState(false)
  const [terminationError, setTerminationError] = useState("")
  const [terminationMessage, setTerminationMessage] = useState("")

  const name =
    profile?.full_name || profile?.email?.split("@")[0] || "Universitário"
  const firstName = name.split(" ")[0]

  const handleLogout = async () => {
    await supabase.auth.signOut()
    onLogout()
  }

  useEffect(() => {
    contractService.listarContratos().then((result) => {
      if (!result.success || !result.data) return
      setContracts(result.data)
      setJoinedRoutes(
        new Set(
          result.data
            .filter((contract) =>
              ["active", "pending"].includes(contract.status),
            )
            .map((contract) => contract.routeId)
            .filter(Boolean) as string[],
        ),
      )
    })
  }, [])

  useEffect(() => {
    let active = true
    setRoutesLoading(true)
    driverRouteService
      .listAvailableRoutes()
      .then((routes) => {
        if (active) setAvailableRoutes(routes)
      })
      .catch((error) => {
        if (active)
          setRoutesError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar as rotas disponíveis.",
          )
      })
      .finally(() => {
        if (active) setRoutesLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  const filtered = availableRoutes.filter((route) => {
    if (!appliedRouteFilters) return true
    const university = normalizeSearchText(appliedRouteFilters.university)
    const neighborhood = normalizeSearchText(
      appliedRouteFilters.originNeighborhood,
    )
    const routeUniversity = normalizeSearchText(
      route.university ?? route.destination,
    )
    const routeNeighborhood = normalizeSearchText(
      route.originNeighborhood ?? route.origin,
    )
    return (
      (!university || routeUniversity.includes(university)) &&
      (!neighborhood || routeNeighborhood.includes(neighborhood)) &&
      (!appliedRouteFilters.classTime ||
        route.departureTime === appliedRouteFilters.classTime)
    )
  })

  const myRoutes = availableRoutes.filter((r) => joinedRoutes.has(r.id))

  const confirmJoin = async () => {
    if (!joinConfirm) return
    setJoinError("")
    const result = await contractService.gerarContratoAdesao({
      route: joinConfirm,
      userRole: "student",
      userName: name,
      provider: joinConfirm.driverName,
    })
    if (!result.success || !result.data) {
      setJoinError(
        result.error ?? "Não foi possível gerar o contrato de adesão.",
      )
      return
    }
    setContracts((items) => [...items, result.data!])
    setJoinedRoutes((s) => new Set([...s, joinConfirm.id]))
    setAvailableRoutes((items) =>
      items.map((route) =>
        route.id === joinConfirm.id
          ? { ...route, occupiedSeats: route.occupiedSeats + 1 }
          : route,
      ),
    )
    setJoinConfirm(null)
  }

  const openTermination = async (routeId: string) => {
    const contract = contracts.find(
      (item) =>
        item.routeId === routeId && ["active", "pending"].includes(item.status),
    )
    if (!contract) return
    setTerminationContract(contract)
    setTerminationPreview(null)
    setTerminationError("")
    setTerminationLoading(true)
    try {
      setTerminationPreview(
        await contractLifecycleService.previewTermination(contract.id),
      )
    } catch (error) {
      setTerminationError(
        error instanceof Error
          ? error.message
          : "Não foi possível consultar o encerramento.",
      )
    } finally {
      setTerminationLoading(false)
    }
  }

  const confirmTermination = async () => {
    if (
      !terminationContract ||
      !terminationPreview?.canTerminate ||
      terminationLoading
    ) {
      return
    }
    setTerminationLoading(true)
    setTerminationError("")
    try {
      const result = await contractLifecycleService.terminate(
        terminationContract.id,
      )
      setContracts((items) =>
        items.map((item) =>
          item.id === terminationContract.id
            ? { ...item, status: "cancelled" }
            : item,
        ),
      )
      if (terminationContract.routeId) {
        const routeId = terminationContract.routeId
        setJoinedRoutes((current) => {
          const next = new Set(current)
          next.delete(routeId)
          return next
        })
        setAvailableRoutes((items) =>
          items.map((route) =>
            route.id === routeId
              ? {
                  ...route,
                  occupiedSeats: Math.max(0, route.occupiedSeats - 1),
                }
              : route,
          ),
        )
      }
      setTerminationMessage(
        result.residualFee > 0
          ? `Contrato encerrado. Valor residual da multa: ${result.residualFee.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}.`
          : "Contrato encerrado e vaga liberada com sucesso.",
      )
      setTerminationContract(null)
      setTerminationPreview(null)
    } catch (error) {
      setTerminationError(
        error instanceof Error
          ? error.message
          : "Não foi possível encerrar o contrato.",
      )
    } finally {
      setTerminationLoading(false)
    }
  }

  return (
    <div
      className="min-h-screen flex"
      style={{
        background: "linear-gradient(135deg, #0d0520 0%, #1a0840 100%)",
      }}
    >
      {/* Sidebar */}
      <aside
        className="w-60 shrink-0 flex flex-col border-r border-purple-500/10 py-6 px-4"
        style={{ background: "rgba(255,255,255,0.02)" }}
      >
        <div className="flex items-center gap-3 px-3 mb-8">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
          >
            <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
              <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
            </svg>
          </div>
          <span
            className="text-lg font-bold text-white"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            U-Go
          </span>
        </div>
        <nav className="flex-1 space-y-1">
          {[
            { id: "routes" as Tab, label: "Buscar rotas", icon: "🔍" },
            { id: "my-routes" as Tab, label: "Minhas rotas", icon: "🗺️" },
            { id: "qr-code" as Tab, label: "Meu QR Code", icon: "QR" },
            { id: "contracts" as Tab, label: "Contratos", icon: "📄" },
            { id: "payments" as Tab, label: "Pagamentos", icon: "R$" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === item.id
                  ? "text-white"
                  : "text-purple-300/50 hover:text-purple-200 hover:bg-white/5"
              }`}
              style={
                tab === item.id
                  ? {
                      background: "rgba(147,51,234,0.2)",
                      borderLeft: "2px solid #9333ea",
                    }
                  : {}
              }
            >
              <span>{item.icon}</span>
              {item.label}
              {item.id === "my-routes" && joinedRoutes.size > 0 && (
                <span
                  className="ml-auto text-xs px-1.5 py-0.5 rounded-full text-white"
                  style={{ background: "#9333ea" }}
                >
                  {joinedRoutes.size}
                </span>
              )}
            </button>
          ))}
        </nav>
        <NotificationsButton />
        <div className="px-3 py-2 mb-3">
          <p className="text-xs text-purple-300/40 truncate">{name}</p>
          {profile?.university && (
            <p className="text-xs text-purple-300/25">{profile.university}</p>
          )}
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-3 py-2 text-sm text-purple-300/50 hover:text-red-400 transition-colors"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.5}
            className="w-4 h-4"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"
            />
          </svg>
          Sair
        </button>
      </aside>

      <main className="flex-1 overflow-y-auto p-8">
        {tab === "routes" && (
          <div>
            <p className="text-purple-300/50 text-sm mb-1">Bem-vindo 👋</p>
            <h1
              className="text-3xl font-bold text-white mb-6"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              Olá, {firstName}!
            </h1>

            <form
              className="mb-6 rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5"
              onSubmit={(event) => {
                event.preventDefault()
                setAppliedRouteFilters({ ...routeFilters })
              }}
            >
              <div className="mb-4">
                <h2 className="text-base font-semibold text-white">
                  Encontre sua rota
                </h2>
                <p className="mt-1 text-xs text-purple-300/45">
                  Pesquise pelas informações mais importantes para sua rotina.
                </p>
              </div>
              <div className="grid gap-3 md:grid-cols-3">
                <label>
                  <span className="mb-1 block text-xs font-medium text-purple-200/70">
                    Faculdade
                  </span>
                  <input
                    value={routeFilters.university}
                    onChange={(event) =>
                      setRouteFilters((current) => ({
                        ...current,
                        university: event.target.value,
                      }))
                    }
                    placeholder="Nome da faculdade"
                    className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                  />
                </label>
                <label>
                  <span className="mb-1 block text-xs font-medium text-purple-200/70">
                    Bairro de origem
                  </span>
                  <input
                    value={routeFilters.originNeighborhood}
                    onChange={(event) =>
                      setRouteFilters((current) => ({
                        ...current,
                        originNeighborhood: event.target.value,
                      }))
                    }
                    placeholder="Ex.: Centro"
                    className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                  />
                </label>
                <label>
                  <span className="mb-1 block text-xs font-medium text-purple-200/70">
                    Horário de aula
                  </span>
                  <input
                    type="time"
                    value={routeFilters.classTime}
                    onChange={(event) =>
                      setRouteFilters((current) => ({
                        ...current,
                        classTime: event.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white focus:border-purple-500"
                  />
                </label>
              </div>
              <div className="mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                {appliedRouteFilters && (
                  <button
                    type="button"
                    onClick={() => {
                      const empty = {
                        university: "",
                        originNeighborhood: "",
                        classTime: "",
                      }
                      setRouteFilters(empty)
                      setAppliedRouteFilters(null)
                    }}
                    className="rounded-xl border border-purple-500/25 px-4 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10"
                  >
                    Limpar filtros
                  </button>
                )}
                <button
                  type="submit"
                  className="rounded-xl bg-purple-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-purple-500"
                >
                  Buscar
                </button>
              </div>
            </form>

            <div className="space-y-4">
              {routesError && (
                <p className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                  {routesError}
                </p>
              )}
              {routesLoading && (
                <div className="py-16 text-center text-purple-300/40">
                  Carregando rotas disponíveis...
                </div>
              )}
              {!routesLoading &&
                filtered.map((r) => {
                  const full = r.occupiedSeats >= r.seats
                  const joined = joinedRoutes.has(r.id)
                  return (
                    <div
                      key={r.id}
                      className="rounded-2xl border border-purple-500/15 p-5"
                      style={{ background: "rgba(255,255,255,0.03)" }}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3
                              className="font-semibold text-white"
                              style={{ fontFamily: "Outfit, sans-serif" }}
                            >
                              {r.name}
                            </h3>
                            {joined && (
                              <span
                                className="text-xs px-2 py-0.5 rounded-full text-purple-300 font-medium"
                                style={{ background: "rgba(147,51,234,0.2)" }}
                              >
                                Inscrito
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-purple-300/50 mb-3">
                            {r.origin} → {r.destination}
                          </p>
                          <div className="flex flex-wrap gap-4 text-xs text-purple-300/60 mb-3">
                            <span>
                              Bairro: {r.originNeighborhood ?? r.origin}
                            </span>
                            <span>
                              Faculdade: {r.university ?? r.destination}
                            </span>
                            <span>
                              🕐 {r.departureTime} / {r.returnTime}
                            </span>
                            <span>
                              🚌 {r.driverName} · {r.vehicle}
                            </span>
                            <span>💰 R$ {r.price}/mês</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <div
                              className="flex-1 h-1.5 rounded-full max-w-32"
                              style={{ background: "rgba(147,51,234,0.1)" }}
                            >
                              <div
                                className="h-full rounded-full"
                                style={{
                                  width: `${Math.min((r.occupiedSeats / r.seats) * 100, 100)}%`,
                                  background: full
                                    ? "#ef4444"
                                    : "linear-gradient(to right,#9333ea,#c084fc)",
                                }}
                              />
                            </div>
                            <span className="text-xs text-purple-300/50">
                              {r.seats - r.occupiedSeats} vaga
                              {r.seats - r.occupiedSeats !== 1 ? "s" : ""} livre
                              {r.seats - r.occupiedSeats !== 1 ? "s" : ""}
                            </span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 shrink-0">
                          <button
                            onClick={() => setMapRoute(r)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border border-purple-500/30 text-purple-300 hover:bg-purple-500/10 transition-all"
                          >
                            <svg
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth={1.5}
                              className="w-3.5 h-3.5"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M9 6.75V15m6-6v8.25m.503 3.498 4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 0 0-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0Z"
                              />
                            </svg>
                            Ver itinerário
                          </button>
                          <button
                            disabled={full || joined}
                            onClick={() => {
                              setJoinError("")
                              setJoinConfirm(r)
                            }}
                            className="px-5 py-2 rounded-xl text-sm font-semibold transition-all"
                            style={
                              joined
                                ? {
                                    background: "rgba(147,51,234,0.15)",
                                    color: "#c084fc",
                                    cursor: "default",
                                  }
                                : full
                                  ? {
                                      background: "rgba(255,255,255,0.05)",
                                      color: "rgba(255,255,255,0.2)",
                                      cursor: "not-allowed",
                                    }
                                  : {
                                      background:
                                        "linear-gradient(135deg, #9333ea, #7e22ce)",
                                      color: "white",
                                    }
                            }
                          >
                            {joined
                              ? "Inscrito ✓"
                              : full
                                ? "Lotado"
                                : "Aderir rota"}
                          </button>
                        </div>
                      </div>
                    </div>
                  )
                })}
              {!routesLoading && !routesError && filtered.length === 0 && (
                <div className="text-center py-16 text-purple-300/40">
                  <p>
                    {appliedRouteFilters
                      ? "Nenhuma rota encontrada para estes filtros"
                      : "Nenhuma rota disponível no momento."}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "my-routes" && (
          <div>
            <h1
              className="text-2xl font-bold text-white mb-6"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              Minhas rotas
            </h1>
            {terminationMessage && (
              <p
                className="mb-4 rounded-xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-200"
                role="status"
              >
                {terminationMessage}
              </p>
            )}
            {myRoutes.length === 0 ? (
              <div className="text-center py-16 text-purple-300/40">
                <p className="text-lg mb-2">
                  Você ainda não aderiu a nenhuma rota
                </p>
                <button
                  onClick={() => setTab("routes")}
                  className="text-sm text-purple-400 hover:text-purple-300 underline underline-offset-2"
                >
                  Buscar rotas disponíveis
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {myRoutes.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-2xl border border-purple-500/30 p-5"
                    style={{ background: "rgba(147,51,234,0.05)" }}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3
                          className="font-semibold text-white mb-1"
                          style={{ fontFamily: "Outfit, sans-serif" }}
                        >
                          {r.name}
                        </h3>
                        <p className="text-xs text-purple-300/50 mb-3">
                          {r.origin} → {r.destination}
                        </p>
                        <div className="flex flex-wrap gap-4 text-xs text-purple-300/60">
                          <span>
                            🕐 {r.departureTime} / {r.returnTime}
                          </span>
                          <span>🚌 {r.driverName}</span>
                          <span>💰 R$ {r.price}/mês</span>
                        </div>
                      </div>
                      <button
                        onClick={() => openTermination(r.id)}
                        className="text-xs px-3 py-1.5 rounded-lg border border-red-500/30 text-red-400/70 hover:text-red-400 transition-colors"
                      >
                        Encerrar Contrato
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "qr-code" && <StudentQrCard contracts={contracts} />}

        {tab === "contracts" && (
          <>
            <ContractAmendmentsPanel
              onAccepted={() => {
                contractService.listarContratos().then((result) => {
                  if (result.success && result.data) setContracts(result.data)
                })
              }}
            />
            <ContractsPanel
              contracts={contracts}
              viewerRole="student"
              onContractChange={(updated) => {
                setContracts((items) =>
                  items.map((item) =>
                    item.id === updated.id ? updated : item,
                  ),
                )
                if (updated.status === "cancelled" && updated.routeId) {
                  setJoinedRoutes((current) => {
                    const next = new Set(current)
                    next.delete(updated.routeId!)
                    return next
                  })
                }
              }}
            />
          </>
        )}

        {tab === "payments" && (
          <PaymentsPanel
            onPaymentConfirmed={() => {
              contractService.listarContratos().then((result) => {
                if (result.success && result.data) setContracts(result.data)
              })
            }}
          />
        )}
      </main>

      {mapRoute && (
        <RouteMapModal route={mapRoute} onClose={() => setMapRoute(null)} />
      )}

      {joinConfirm && (
        <ContractAcceptanceModal
          route={joinConfirm}
          error={joinError}
          onCancel={() => {
            setJoinError("")
            setJoinConfirm(null)
          }}
          onConfirm={confirmJoin}
        />
      )}

      {terminationContract && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="termination-title"
        >
          <div className="my-auto w-full max-w-lg rounded-2xl border border-purple-500/20 bg-[#1a0840] p-6 shadow-2xl">
            <h2
              id="termination-title"
              className="text-xl font-semibold text-white"
            >
              Encerrar Contrato
            </h2>
            <p className="mt-1 text-sm text-purple-200/55">
              {terminationContract.route}
            </p>

            {terminationLoading && !terminationPreview ? (
              <p className="py-10 text-center text-sm text-purple-200/55">
                Consultando débitos e condições...
              </p>
            ) : (
              <div className="mt-5 space-y-4">
                {terminationPreview && !terminationPreview.canTerminate && (
                  <div className="rounded-xl border border-red-500/25 bg-red-500/10 p-4">
                    <p className="text-sm font-semibold text-red-200">
                      Existem mensalidades em atraso
                    </p>
                    <p className="mt-1 text-sm text-red-100/65">
                      Quite os débitos pendentes para finalizar o encerramento.
                      Total em atraso:{" "}
                      {terminationPreview.overdueAmount.toLocaleString(
                        "pt-BR",
                        { style: "currency", currency: "BRL" },
                      )}
                      .
                    </p>
                  </div>
                )}
                {terminationPreview?.canTerminate && (
                  <div className="rounded-xl border border-purple-500/15 bg-white/[0.03] p-4">
                    <p className="text-sm text-purple-100/70">
                      O contrato será cancelado e a vaga será liberada.
                    </p>
                    {terminationPreview.residualFee > 0 && (
                      <div className="mt-3 border-t border-purple-500/15 pt-3">
                        <p className="text-xs text-purple-300/45">
                          Multa por encerramento antes do prazo mínimo
                        </p>
                        <p className="mt-1 text-lg font-semibold text-amber-300">
                          {terminationPreview.residualFee.toLocaleString(
                            "pt-BR",
                            { style: "currency", currency: "BRL" },
                          )}
                        </p>
                      </div>
                    )}
                  </div>
                )}
                {terminationError && (
                  <p
                    className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200"
                    role="alert"
                  >
                    {terminationError}
                  </p>
                )}
              </div>
            )}

            <div className="mt-6 flex flex-col-reverse gap-3 border-t border-purple-500/15 pt-4 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setTerminationContract(null)}
                disabled={terminationLoading}
                className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-500/10"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmTermination}
                disabled={
                  terminationLoading || !terminationPreview?.canTerminate
                }
                className="rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-500 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {terminationLoading
                  ? "Encerrando..."
                  : "Confirmar encerramento"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
