import { useEffect, useState, useRef } from "react"
import { read, utils } from "xlsx"
import { supabase } from "../../lib/supabase"
import { validateCPF, formatCPF, formatPhone } from "../../lib/validators"
import RouteMapModal from "../../components/RouteMapModal"
import { ContractsPanel } from "../../features/contracts"
import { companyDataService } from "../../features/companies"
import type { Route, Collaborator, Contract } from "../../types"
import { CompanyPaymentsPanel } from "../../features/payments"

interface Props {
  profile: any
  onLogout: () => void
}

type Tab = "overview" | "collaborators" | "routes" | "contracts" | "payments"

function ColabSuccessCard({
  nome,
  email,
  onAddAnother,
  onClose,
}: {
  nome: string
  email: string
  onAddAnother: () => void
  onClose: () => void
}) {
  return (
    <div className="flex flex-col gap-4 py-2">
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
          style={{ background: "rgba(34,197,94,0.15)" }}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.5}
            className="w-5 h-5 text-green-400"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
            />
          </svg>
        </div>
        <div>
          <p
            className="text-white font-semibold text-sm"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            Colaborador cadastrado com sucesso!
          </p>
          <p className="text-xs text-purple-300/50">
            O convite de acesso foi enviado por e-mail.
          </p>
        </div>
      </div>
      <div
        className="rounded-xl border border-purple-500/20 p-4 space-y-3"
        style={{ background: "rgba(0,0,0,0.2)" }}
      >
        <p className="text-xs text-purple-300/50 uppercase tracking-wider font-medium">
          Credenciais de acesso
        </p>
        <div>
          <p className="text-xs text-purple-300/40 mb-0.5">Colaborador</p>
          <p className="text-sm text-white font-medium">{nome}</p>
        </div>
        <div>
          <p className="text-xs text-purple-300/40 mb-0.5">E-mail</p>
          <p className="text-sm text-white font-medium">{email}</p>
        </div>
        <p className="text-xs text-purple-300/40 pt-1 border-t border-purple-500/10">
          O colaborador deve abrir o link recebido para ativar a conta e criar
          uma senha.
        </p>
      </div>
      <div className="flex gap-3">
        <button
          onClick={onAddAnother}
          className="flex-1 py-2.5 rounded-xl text-sm border border-purple-500/30 text-purple-300 hover:bg-purple-500/10 transition-all"
        >
          Adicionar outro
        </button>
        <button
          onClick={onClose}
          className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white"
          style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
        >
          Fechar
        </button>
      </div>
    </div>
  )
}

function Sidebar({
  tab,
  setTab,
  name,
  onLogout,
}: {
  tab: Tab
  setTab: (t: Tab) => void
  name: string
  onLogout: () => void
}) {
  const items: {
    id: Tab
    label: string
    icon: string
  }[] = [
    { id: "overview", label: "Visão geral", icon: "📊" },
    { id: "collaborators", label: "Colaboradores", icon: "👥" },
    { id: "routes", label: "Rotas", icon: "🗺️" },
    { id: "contracts", label: "Contratos", icon: "📄" },
    { id: "payments", label: "Pagamentos", icon: "R$" },
  ]
  return (
    <aside
      className="w-60 shrink-0 flex flex-col border-r border-purple-500/10 py-6 px-4"
      style={{ background: "rgba(255,255,255,0.02)" }}
    >
      <div className="flex items-center gap-3 px-3 mb-8">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
        >
          <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
            <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
          </svg>
        </div>
        <span
          className="text-lg font-bold text-white"
          style={{ fontFamily: "Outfit, sans-serif" }}
        >
          U-Go
        </span>
      </div>
      <nav className="flex-1 space-y-1">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setTab(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
              tab === item.id
                ? "text-white"
                : "text-purple-300/50 hover:text-purple-200 hover:bg-white/5"
            }`}
            style={
              tab === item.id
                ? {
                    background: "rgba(147,51,234,0.2)",
                    borderLeft: "2px solid #9333ea",
                  }
                : {}
            }
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <div className="px-3 py-2 mb-3">
        <p className="text-xs text-purple-300/40 truncate">{name}</p>
        <p className="text-xs text-purple-300/25">Empresa</p>
      </div>
      <button
        onClick={onLogout}
        className="flex items-center gap-2 px-3 py-2 text-sm text-purple-300/50 hover:text-red-400 transition-colors"
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          className="w-4 h-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"
          />
        </svg>
        Sair
      </button>
    </aside>
  )
}

function Modal({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: React.ReactNode
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-purple-500/20 p-6"
        style={{ background: "#1a0840" }}
      >
        <div className="flex items-center justify-between mb-5">
          <h3
            className="text-lg font-semibold text-white"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            {title}
          </h3>
          <button
            onClick={onClose}
            className="text-purple-300/50 hover:text-white"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  type?: string
  required?: boolean
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-purple-200/70 mb-1">
        {label}
        {required && <span className="ml-1 text-red-300">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        className="w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border border-purple-500/25 focus:border-purple-500 transition-colors"
        style={{ background: "rgba(255,255,255,0.05)", outline: "none" }}
      />
    </div>
  )
}

const EMPTY_COLAB = {
  fullName: "",
  email: "",
  cpf: "",
  phone: "",
  address: "",
  department: "",
}

export default function CompanyDashboard({ profile, onLogout }: Props) {
  const [tab, setTab] = useState<Tab>("overview")
  const [routes, setRoutes] = useState<Route[]>([])
  const [collaborators, setCollaborators] = useState<Collaborator[]>([])
  const [contracts, setContracts] = useState<Contract[]>([])
  const [routeModal, setRouteModal] = useState<"add" | "edit" | null>(null)
  const [editingRoute, setEditingRoute] = useState<Route | null>(null)
  const [routeForm, setRouteForm] = useState({
    name: "",
    origin: "",
    destination: "",
    departureTime: "",
    returnTime: "",
    seats: "",
    price: "",
    freightCompany: "",
  })
  const [routeError, setRouteError] = useState("")
  const [importPreview, setImportPreview] = useState<any[]>([])
  const [importModal, setImportModal] = useState(false)
  const [colabModal, setColabModal] = useState(false)
  const [colabForm, setColabForm] = useState(EMPTY_COLAB)
  const [colabErrors, setColabErrors] = useState<Partial<typeof EMPTY_COLAB>>(
    {},
  )
  const [colabSaving, setColabSaving] = useState(false)
  const [colabSuccess, setColabSuccess] = useState("")
  const [mapRoute, setMapRoute] = useState<Route | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const name = profile?.nome_fantasia || profile?.razao_social || "Empresa"

  const handleLogout = async () => {
    await supabase.auth.signOut()
    onLogout()
  }

  useEffect(() => {
    let active = true
    companyDataService
      .listDashboardData()
      .then((data) => {
        if (!active) return
        setRoutes(data.routes)
        setContracts(data.contracts)
        setCollaborators(data.collaborators)
      })
      .catch((error) => {
        if (active)
          setRouteError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar os dados da empresa.",
          )
      })
    return () => {
      active = false
    }
  }, [])

  const cf = (f: keyof typeof EMPTY_COLAB) => (v: string) =>
    setColabForm((x) => ({ ...x, [f]: v }))

  const saveCollaborator = async () => {
    const e: Partial<typeof EMPTY_COLAB> = {}
    if (!colabForm.fullName.trim()) e.fullName = "Nome obrigatório"
    if (!colabForm.email.trim()) e.email = "E-mail obrigatório"
    const cpfDigits = colabForm.cpf.replace(/\D/g, "")
    if (!cpfDigits) e.cpf = "CPF obrigatório"
    else if (cpfDigits.length < 11) e.cpf = "CPF incompleto"
    else if (!validateCPF(colabForm.cpf)) e.cpf = "CPF inválido"
    const phoneDigits = colabForm.phone.replace(/\D/g, "")
    if (!phoneDigits) e.phone = "Telefone obrigatório"
    else if (phoneDigits.length < 10) e.phone = "Telefone incompleto"
    setColabErrors(e)
    if (Object.keys(e).length > 0) return
    setColabSaving(true)
    try {
      const result = await companyDataService.createCollaborators([
        {
          name: colabForm.fullName.trim(),
          email: colabForm.email.trim(),
          cpf: colabForm.cpf.trim(),
          phone: colabForm.phone.trim(),
          address: colabForm.address.trim(),
          department: colabForm.department.trim(),
        },
      ])
      if (result.failures.length > 0 || result.created.length === 0) {
        setColabErrors({
          email:
            result.failures[0]?.error ??
            "Não foi possível cadastrar o colaborador.",
        })
        return
      }
      setCollaborators((items) => [...result.created, ...items])
      setColabSuccess(colabForm.fullName + "||" + colabForm.email)
      setColabForm(EMPTY_COLAB)
      setColabErrors({})
    } catch (error) {
      setColabErrors({
        email:
          error instanceof Error
            ? error.message
            : "Não foi possível cadastrar o colaborador.",
      })
    } finally {
      setColabSaving(false)
    }
  }

  const openAddRoute = () => {
    setRouteForm({
      name: "",
      origin: "",
      destination: "",
      departureTime: "",
      returnTime: "",
      seats: "",
      price: "",
      freightCompany: "",
    })
    setRouteError("")
    setEditingRoute(null)
    setRouteModal("add")
  }
  const openEditRoute = (r: Route) => {
    setEditingRoute(r)
    setRouteForm({
      name: r.name,
      origin: r.origin,
      destination: r.destination,
      departureTime: r.departureTime,
      returnTime: r.returnTime,
      seats: String(r.seats),
      price: String(r.price),
      freightCompany: r.freightCompany ?? "",
    })
    setRouteError("")
    setRouteModal("edit")
  }
  const saveRoute = async () => {
    if (Object.values(routeForm).some((value) => !value.trim())) {
      setRouteError(
        "Preencha todos os campos, incluindo a empresa de fretamento.",
      )
      return
    }
    const seats = Number(routeForm.seats)
    const price = Number(routeForm.price)
    if (
      !Number.isInteger(seats) ||
      seats < 1 ||
      !Number.isFinite(price) ||
      price <= 0
    ) {
      setRouteError("Informe vagas e preço mensal válidos.")
      return
    }
    const routeData = {
      ...routeForm,
      seats,
      occupiedSeats: editingRoute?.occupiedSeats ?? 0,
      price,
      days: editingRoute?.days ?? ["Seg", "Ter", "Qua", "Qui", "Sex"],
    }
    try {
      if (routeModal === "add") {
        const created = await companyDataService.createRoute(routeData)
        setRoutes((items) => [created.route, ...items])
        setContracts((items) => [created.contract, ...items])
      } else if (editingRoute) {
        const updated = await companyDataService.updateRoute(
          editingRoute.id,
          routeData,
        )
        setRoutes((items) =>
          items.map((route) =>
            route.id === updated.route.id ? updated.route : route,
          ),
        )
        setContracts((items) =>
          items.map((contract) =>
            contract.id === updated.contract.id ? updated.contract : contract,
          ),
        )
      }
      setRouteModal(null)
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível salvar a rota.",
      )
    }
  }
  const deleteRoute = async (id: string) => {
    try {
      await companyDataService.deleteRoute(id)
      setRoutes((rs) => rs.filter((r) => r.id !== id))
      setContracts((items) =>
        items.filter((contract) => contract.routeId !== id),
      )
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível excluir a rota.",
      )
    }
  }
  const deleteCollaborator = async (id: string) => {
    try {
      await companyDataService.deleteCollaborator(id)
      setCollaborators((items) => items.filter((item) => item.id !== id))
    } catch (error) {
      setColabErrors({
        email:
          error instanceof Error
            ? error.message
            : "Não foi possível excluir o colaborador.",
      })
    }
  }

  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      const wb = read(ev.target?.result, { type: "binary" })
      const ws = wb.Sheets[wb.SheetNames[0]]
      const data = utils.sheet_to_json(ws) as any[]
      setImportPreview(data)
      setImportModal(true)
    }
    reader.readAsBinaryString(file)
    e.target.value = ""
  }

  const confirmImport = async () => {
    const newColabs = importPreview
      .map((row, i) => ({
        name: row["Nome"] || row["name"] || row["Nome completo"] || "",
        email: row["Email"] || row["email"] || row["E-mail"] || "",
        cpf: row["CPF"] || row["cpf"] || "",
        phone: row["Telefone"] || row["phone"] || "",
        address: row["Endereço"] || row["Endereco"] || row["address"] || "",
        department: row["Departamento"] || row["department"] || "",
      }))
      .filter((c) => c.name && c.email)
    try {
      const result = await companyDataService.createCollaborators(newColabs)
      setCollaborators((items) => [...result.created, ...items])
      if (result.failures.length > 0) {
        setRouteError(
          `${result.failures.length} colaborador(es) não foram importados. ${result.failures[0].error}`,
        )
      }
      setImportModal(false)
      setImportPreview([])
    } catch (error) {
      setRouteError(
        error instanceof Error
          ? error.message
          : "Não foi possível importar os colaboradores.",
      )
    }
  }

  const rf = (f: keyof typeof routeForm) => (v: string) => {
    setRouteError("")
    setRouteForm((x) => ({ ...x, [f]: v }))
  }

  return (
    <div
      className="min-h-screen flex"
      style={{
        background: "linear-gradient(135deg, #0d0520 0%, #1a0840 100%)",
      }}
    >
      <Sidebar tab={tab} setTab={setTab} name={name} onLogout={handleLogout} />

      <main className="flex-1 overflow-y-auto p-8">
        {routeError && !routeModal && (
          <p className="mb-5 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
            {routeError}
          </p>
        )}
        {/* OVERVIEW */}
        {tab === "overview" && (
          <div>
            <p className="text-purple-300/50 text-sm mb-1">
              Painel Empresarial 🏢
            </p>
            <h1
              className="text-3xl font-bold text-white mb-6"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              {name}
            </h1>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                {
                  label: "Colaboradores",
                  value: collaborators.filter((c) => c.status === "active")
                    .length,
                  icon: "👥",
                },
                { label: "Rotas ativas", value: routes.length, icon: "🗺️" },
                {
                  label: "Contratos ativos",
                  value: contracts.filter((c) => c.status === "active").length,
                  icon: "📄",
                },
                {
                  label: "Gasto mensal",
                  value: `R$ ${contracts
                    .filter((c) => c.status === "active")
                    .reduce((s, c) => s + c.value, 0)
                    .toLocaleString("pt-BR")}`,
                  icon: "💰",
                },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl border border-purple-500/15 p-5"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  <div className="text-2xl mb-3">{s.icon}</div>
                  <div
                    className="text-2xl font-bold text-white mb-1"
                    style={{ fontFamily: "Outfit, sans-serif" }}
                  >
                    {s.value}
                  </div>
                  <div className="text-xs text-purple-300/50">{s.label}</div>
                </div>
              ))}
            </div>
            <div
              className="rounded-2xl border border-purple-500/15 p-5"
              style={{ background: "rgba(255,255,255,0.03)" }}
            >
              <h2
                className="font-semibold text-white mb-3"
                style={{ fontFamily: "Outfit, sans-serif" }}
              >
                Ocupação das rotas
              </h2>
              {routes.map((r) => (
                <div key={r.id} className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-purple-200/70">{r.name}</span>
                    <span className="text-purple-300/50">
                      {r.occupiedSeats}/{r.seats}
                    </span>
                  </div>
                  <div
                    className="h-2 rounded-full"
                    style={{ background: "rgba(147,51,234,0.1)" }}
                  >
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min((r.occupiedSeats / r.seats) * 100, 100)}%`,
                        background:
                          r.occupiedSeats >= r.seats
                            ? "#ef4444"
                            : "linear-gradient(to right,#9333ea,#c084fc)",
                      }}
                    />
                  </div>
                </div>
              ))}
              {routes.length === 0 && (
                <p className="py-8 text-center text-sm text-purple-300/40">
                  Nenhuma rota cadastrada.
                </p>
              )}
            </div>
          </div>
        )}

        {/* COLLABORATORS */}
        {tab === "collaborators" && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h1
                className="text-2xl font-bold text-white"
                style={{ fontFamily: "Outfit, sans-serif" }}
              >
                Colaboradores
              </h1>
              <div className="flex gap-3">
                <input
                  ref={fileRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleExcelUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border border-purple-500/30 text-purple-300 hover:bg-purple-500/10 transition-all"
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={1.5}
                    className="w-4 h-4"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5"
                    />
                  </svg>
                  Importar Excel
                </button>
                <button
                  onClick={() => {
                    setColabForm(EMPTY_COLAB)
                    setColabErrors({})
                    setColabModal(true)
                  }}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
                  style={{
                    background: "linear-gradient(135deg, #9333ea, #7e22ce)",
                  }}
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                    className="w-4 h-4"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 4.5v15m7.5-7.5h-15"
                    />
                  </svg>
                  Novo colaborador
                </button>
              </div>
            </div>
            <div
              className="flex items-start gap-2 px-4 py-3 rounded-xl border border-purple-500/20 mb-5 text-xs text-purple-300/60"
              style={{ background: "rgba(147,51,234,0.06)" }}
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.5}
                className="w-4 h-4 shrink-0 mt-0.5 text-purple-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M11.25 11.25l.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"
                />
              </svg>
              <span>
                Colaboradores{" "}
                <strong className="text-purple-300">
                  não se cadastram pelo app
                </strong>{" "}
                — o acesso é criado pela empresa via importação de planilha ou
                cadastro manual.
                <br />
                Planilha: colunas esperadas:{" "}
                <strong className="text-purple-300/80">
                  Nome, Email, CPF, Telefone, Departamento
                </strong>
              </span>
            </div>
            <div
              className="rounded-2xl border border-purple-500/15 overflow-hidden"
              style={{ background: "rgba(255,255,255,0.03)" }}
            >
              <table className="w-full">
                <thead>
                  <tr className="border-b border-purple-500/10">
                    {[
                      "Nome",
                      "E-mail",
                      "Telefone",
                      "Departamento",
                      "Status",
                      "",
                    ].map((h) => (
                      <th
                        key={h}
                        className="px-5 py-3 text-left text-xs font-medium text-purple-300/40 uppercase tracking-wider"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-purple-500/10">
                  {collaborators.map((c) => (
                    <tr
                      key={c.id}
                      className="hover:bg-white/5 transition-colors"
                    >
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
                            style={{ background: "rgba(147,51,234,0.25)" }}
                          >
                            {c.name[0]}
                          </div>
                          <div>
                            <p className="text-sm text-white font-medium">
                              {c.name}
                            </p>
                            <p className="text-xs text-purple-300/40">
                              {c.cpf}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-sm text-purple-200/60">
                        {c.email}
                      </td>
                      <td className="px-5 py-3 text-sm text-purple-200/60">
                        {c.phone || "—"}
                      </td>
                      <td className="px-5 py-3 text-sm text-purple-200/60">
                        {c.department || "—"}
                      </td>
                      <td className="px-5 py-3">
                        <span
                          className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                            c.status === "active"
                              ? "text-green-300"
                              : "text-purple-300/40"
                          }`}
                          style={{
                            background:
                              c.status === "active"
                                ? "rgba(34,197,94,0.1)"
                                : "rgba(255,255,255,0.05)",
                          }}
                        >
                          {c.status === "active" ? "Ativo" : "Inativo"}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <button
                          onClick={() => deleteCollaborator(c.id)}
                          className="text-red-400/50 hover:text-red-400 transition-colors"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-4 h-4"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                            />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                  {collaborators.length === 0 && (
                    <tr>
                      <td
                        colSpan={6}
                        className="px-5 py-12 text-center text-sm text-purple-300/40"
                      >
                        Nenhum colaborador cadastrado.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ROUTES */}
        {tab === "routes" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h1
                className="text-2xl font-bold text-white"
                style={{ fontFamily: "Outfit, sans-serif" }}
              >
                Rotas
              </h1>
              <button
                onClick={openAddRoute}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
                style={{
                  background: "linear-gradient(135deg, #9333ea, #7e22ce)",
                }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  className="w-4 h-4"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 4.5v15m7.5-7.5h-15"
                  />
                </svg>
                Nova rota
              </button>
            </div>
            <div className="space-y-4">
              {routes.map((r) => (
                <div
                  key={r.id}
                  className="rounded-2xl border border-purple-500/15 p-5"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3
                        className="font-semibold text-white mb-1"
                        style={{ fontFamily: "Outfit, sans-serif" }}
                      >
                        {r.name}
                      </h3>
                      <p className="text-xs text-purple-300/50 mb-3">
                        {r.origin} → {r.destination}
                      </p>
                      <p className="mb-3 text-xs font-medium text-purple-300/70">
                        Fretamento: {r.freightCompany}
                      </p>
                      <div className="flex flex-wrap gap-3 text-xs text-purple-300/60">
                        <span>
                          🕐 {r.departureTime} / {r.returnTime}
                        </span>
                        <span>
                          💺 {r.occupiedSeats}/{r.seats} vagas
                        </span>
                        <span>💰 R$ {r.price}/mês</span>
                        <span>{r.days.join(", ")}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <button
                        onClick={() => setMapRoute(r)}
                        className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                        title="Ver no mapa"
                      >
                        <svg
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={1.5}
                          className="w-4 h-4"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M9 6.75V15m6-6v8.25m.503 3.498 4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 0 0-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0Z"
                          />
                        </svg>
                      </button>
                      <button
                        onClick={() => openEditRoute(r)}
                        className="p-2 rounded-lg text-purple-300/50 hover:text-purple-300 hover:bg-purple-500/10 transition-all"
                      >
                        <svg
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={1.5}
                          className="w-4 h-4"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125"
                          />
                        </svg>
                      </button>
                      <button
                        onClick={() => deleteRoute(r.id)}
                        className="p-2 rounded-lg text-red-400/50 hover:text-red-400 hover:bg-red-500/10 transition-all"
                      >
                        <svg
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={1.5}
                          className="w-4 h-4"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {routes.length === 0 && (
                <div className="py-16 text-center text-purple-300/40">
                  <p className="text-lg mb-2">Nenhuma rota cadastrada</p>
                  <p className="text-sm">Clique em "Nova rota" para começar.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* CONTRACTS */}
        {tab === "contracts" && (
          <ContractsPanel
            contracts={contracts}
            viewerRole="company"
            availableCollaborators={collaborators}
            onContractChange={(updated) =>
              setContracts((items) =>
                items.map((item) => (item.id === updated.id ? updated : item)),
              )
            }
          />
        )}

        {tab === "payments" && <CompanyPaymentsPanel contracts={contracts} />}
      </main>

      {mapRoute && (
        <RouteMapModal route={mapRoute} onClose={() => setMapRoute(null)} />
      )}

      {/* Route modal */}
      {routeModal && (
        <Modal
          title={routeModal === "add" ? "Nova rota" : "Editar rota"}
          onClose={() => setRouteModal(null)}
        >
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault()
              saveRoute()
            }}
          >
            <p className="text-xs text-purple-300/50">
              <span className="text-red-300">*</span> Todos os campos são
              obrigatórios.
            </p>
            <Field
              label="Nome da rota"
              value={routeForm.name}
              onChange={rf("name")}
              placeholder="Sede → Destino"
              required
            />
            <Field
              label="Empresa de fretamento responsável"
              value={routeForm.freightCompany}
              onChange={rf("freightCompany")}
              placeholder="Razão social ou nome fantasia"
              required
            />
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Origem"
                value={routeForm.origin}
                onChange={rf("origin")}
                placeholder="Endereço de saída"
                required
              />
              <Field
                label="Destino"
                value={routeForm.destination}
                onChange={rf("destination")}
                placeholder="Endereço de chegada"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Saída"
                value={routeForm.departureTime}
                onChange={rf("departureTime")}
                type="time"
                required
              />
              <Field
                label="Retorno"
                value={routeForm.returnTime}
                onChange={rf("returnTime")}
                type="time"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="Vagas"
                value={routeForm.seats}
                onChange={rf("seats")}
                type="number"
                placeholder="Quantidade de vagas"
                required
              />
              <Field
                label="Preço mensal (R$)"
                value={routeForm.price}
                onChange={rf("price")}
                type="number"
                placeholder="Valor mensal"
                required
              />
            </div>
            {routeError && (
              <p className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                {routeError}
              </p>
            )}
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl text-sm font-semibold text-white mt-2"
              style={{
                background: "linear-gradient(135deg, #9333ea, #7e22ce)",
              }}
            >
              {routeModal === "add" ? "Criar rota" : "Salvar alterações"}
            </button>
          </form>
        </Modal>
      )}

      {/* New collaborator modal */}
      {colabModal && (
        <Modal
          title="Cadastrar colaborador"
          onClose={() => {
            setColabModal(false)
            setColabSuccess("")
            setColabErrors({})
          }}
        >
          {colabSuccess ? (
            <ColabSuccessCard
              nome={colabSuccess.split("||")[0]}
              email={colabSuccess.split("||")[1]}
              onAddAnother={() => {
                setColabSuccess("")
                setColabForm(EMPTY_COLAB)
              }}
              onClose={() => {
                setColabModal(false)
                setColabSuccess("")
              }}
            />
          ) : (
            <div className="space-y-3">
              <div
                className="flex items-start gap-2 px-3 py-2.5 rounded-xl border border-purple-500/20 text-xs text-purple-300/60"
                style={{ background: "rgba(147,51,234,0.06)" }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.5}
                  className="w-4 h-4 shrink-0 mt-0.5 text-purple-400"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M11.25 11.25l.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"
                  />
                </svg>
                O colaborador receberá uma{" "}
                <strong className="text-purple-300">senha temporária</strong>{" "}
                que será exibida após o cadastro. No primeiro acesso, será
                solicitado que ele crie uma senha própria.
              </div>
              <div>
                <label className="block text-xs font-medium text-purple-200/70 mb-1">
                  Nome completo *
                </label>
                <input
                  value={colabForm.fullName}
                  onChange={(e) => cf("fullName")(e.target.value)}
                  placeholder="Nome do colaborador"
                  className="w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border transition-colors"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    outline: "none",
                    borderColor: colabErrors.fullName
                      ? "#f87171"
                      : "rgba(147,51,234,0.25)",
                  }}
                />
                {colabErrors.fullName && (
                  <p className="text-xs text-red-400 mt-1">
                    {colabErrors.fullName}
                  </p>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium text-purple-200/70 mb-1">
                  E-mail *
                </label>
                <input
                  value={colabForm.email}
                  onChange={(e) => cf("email")(e.target.value)}
                  placeholder="colaborador@empresa.com"
                  type="email"
                  className="w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border transition-colors"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    outline: "none",
                    borderColor: colabErrors.email
                      ? "#f87171"
                      : "rgba(147,51,234,0.25)",
                  }}
                />
                {colabErrors.email && (
                  <p className="text-xs text-red-400 mt-1">
                    {colabErrors.email}
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-purple-200/70 mb-1">
                    CPF *
                  </label>
                  <input
                    value={colabForm.cpf}
                    onChange={(e) => {
                      const formatted = formatCPF(e.target.value)
                      cf("cpf")(formatted)
                      const digits = formatted.replace(/\D/g, "")
                      if (digits.length === 11) {
                        setColabErrors((prev) => ({
                          ...prev,
                          cpf: validateCPF(formatted)
                            ? undefined
                            : "CPF inválido",
                        }))
                      } else if (colabErrors.cpf) {
                        setColabErrors((prev) => ({ ...prev, cpf: undefined }))
                      }
                    }}
                    placeholder="000.000.000-00"
                    className="w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border transition-colors"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      outline: "none",
                      borderColor: colabErrors.cpf
                        ? "#f87171"
                        : "rgba(147,51,234,0.25)",
                    }}
                  />
                  {colabErrors.cpf && (
                    <p className="text-xs text-red-400 mt-1">
                      {colabErrors.cpf}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-medium text-purple-200/70 mb-1">
                    Telefone *
                  </label>
                  <input
                    value={colabForm.phone}
                    onChange={(e) => {
                      const formatted = formatPhone(e.target.value)
                      cf("phone")(formatted)
                      const digits = formatted.replace(/\D/g, "")
                      if (digits.length >= 10 && colabErrors.phone) {
                        setColabErrors((prev) => ({
                          ...prev,
                          phone: undefined,
                        }))
                      }
                    }}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3 py-2.5 rounded-xl text-white text-sm placeholder-purple-300/30 border transition-colors"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      outline: "none",
                      borderColor: colabErrors.phone
                        ? "#f87171"
                        : "rgba(147,51,234,0.25)",
                    }}
                  />
                  {colabErrors.phone && (
                    <p className="text-xs text-red-400 mt-1">
                      {colabErrors.phone}
                    </p>
                  )}
                </div>
              </div>
              <Field
                label="Endereço"
                value={colabForm.address}
                onChange={cf("address")}
                placeholder="Rua, número, bairro, cidade"
              />
              <Field
                label="Departamento"
                value={colabForm.department}
                onChange={cf("department")}
                placeholder="Ex: Financeiro, TI, RH"
              />
              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => {
                    setColabModal(false)
                    setColabErrors({})
                  }}
                  className="flex-1 py-2.5 rounded-xl text-sm border border-purple-500/30 text-purple-300 hover:bg-purple-500/10 transition-all"
                >
                  Cancelar
                </button>
                <button
                  onClick={saveCollaborator}
                  disabled={colabSaving}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white disabled:opacity-60 transition-opacity"
                  style={{
                    background: "linear-gradient(135deg, #9333ea, #7e22ce)",
                  }}
                >
                  {colabSaving ? "Cadastrando..." : "Criar acesso"}
                </button>
              </div>
            </div>
          )}
        </Modal>
      )}

      {/* Excel import modal */}
      {importModal && (
        <Modal
          title={`Importar ${importPreview.length} colaborador${
            importPreview.length !== 1 ? "es" : ""
          }`}
          onClose={() => setImportModal(false)}
        >
          <p className="text-xs text-purple-300/50 mb-3">
            Os colaboradores abaixo receberão acesso ao U-Go com as credenciais
            da planilha.
          </p>
          <div
            className="max-h-60 overflow-y-auto mb-4 rounded-xl border border-purple-500/15"
            style={{ background: "rgba(0,0,0,0.2)" }}
          >
            {importPreview.slice(0, 15).map((row, i) => {
              const n =
                row["Nome"] || row["name"] || row["Nome completo"] || "—"
              const e = row["Email"] || row["email"] || row["E-mail"] || "—"
              const dept = row["Departamento"] || row["department"] || ""
              return (
                <div
                  key={i}
                  className="flex items-center gap-3 px-4 py-2.5 border-b border-purple-500/10 last:border-0"
                >
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                    style={{ background: "rgba(147,51,234,0.3)" }}
                  >
                    {n[0] || "?"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{n}</p>
                    <p className="text-xs text-purple-300/40 truncate">
                      {e}
                      {dept ? ` · ${dept}` : ""}
                    </p>
                  </div>
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={1.5}
                    className="w-4 h-4 text-green-400/60 shrink-0"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                    />
                  </svg>
                </div>
              )
            })}
            {importPreview.length > 15 && (
              <p className="text-xs text-purple-300/40 text-center py-2">
                +{importPreview.length - 15} mais
              </p>
            )}
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => {
                setImportModal(false)
                setImportPreview([])
              }}
              className="flex-1 py-2.5 rounded-xl text-sm border border-purple-500/30 text-purple-300"
            >
              Cancelar
            </button>
            <button
              onClick={confirmImport}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white"
              style={{
                background: "linear-gradient(135deg, #9333ea, #7e22ce)",
              }}
            >
              Criar acessos
            </button>
          </div>
        </Modal>
      )}
    </div>
  )
}
