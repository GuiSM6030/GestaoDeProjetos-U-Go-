import { useEffect, useState } from "react"
import { supabase } from "../../lib/supabase"
import RouteMapModal from "../../components/RouteMapModal"
import {
  ContractAcceptanceModal,
  ContractsPanel,
  contractService,
} from "../../features/contracts"
import type { Contract, Route } from "../../types"
import { CollaboratorQrCard } from "../../features/attendance"

interface Props {
  profile: any
  onLogout: () => void
}
type Tab = "routes" | "my-routes" | "qr-code" | "contracts"

export default function CollaboratorDashboard({ profile, onLogout }: Props) {
  const [tab, setTab] = useState<Tab>("routes")
  const [search, setSearch] = useState("")
  const [joinedRoutes, setJoinedRoutes] = useState<Set<string>>(new Set())
  const [joinConfirm, setJoinConfirm] = useState<Route | null>(null)
  const [mapRoute, setMapRoute] = useState<Route | null>(null)
  const [contracts, setContracts] = useState<Contract[]>([])
  const [availableRoutes] = useState<Route[]>([])
  const [joinError, setJoinError] = useState("")

  const name =
    profile?.full_name || profile?.email?.split("@")[0] || "Colaborador"
  const firstName = name.split(" ")[0]

  const handleLogout = async () => {
    await supabase.auth.signOut()
    onLogout()
  }

  useEffect(() => {
    contractService.listarContratos().then((result) => {
      if (!result.success || !result.data) return
      setContracts(result.data)
      setJoinedRoutes(
        new Set(
          result.data
            .filter((contract) =>
              ["active", "pending"].includes(contract.status),
            )
            .map((contract) => contract.routeId)
            .filter(Boolean) as string[],
        ),
      )
    })
  }, [])

  const filtered = availableRoutes.filter(
    (r) =>
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.origin.toLowerCase().includes(search.toLowerCase()) ||
      r.destination.toLowerCase().includes(search.toLowerCase()),
  )

  const myRoutes = availableRoutes.filter((r) => joinedRoutes.has(r.id))

  const confirmJoin = async () => {
    if (!joinConfirm) return
    setJoinError("")
    const result = await contractService.gerarContratoAdesao({
      route: joinConfirm,
      userRole: "collaborator",
      userName: name,
      provider: joinConfirm.driverName,
    })
    if (!result.success || !result.data) {
      setJoinError(
        result.error ?? "Não foi possível gerar o contrato de adesão.",
      )
      return
    }
    setContracts((items) => [...items, result.data!])
    setJoinedRoutes((s) => new Set([...s, joinConfirm.id]))
    setJoinConfirm(null)
  }

  const cancelJoin = async (routeId: string) => {
    const contract = contracts.find(
      (item) =>
        item.routeId === routeId && ["active", "pending"].includes(item.status),
    )
    if (contract) {
      const result = await contractService.atualizarStatusContrato(
        contract.id,
        "cancelled",
      )
      if (result.success && result.data) {
        setContracts((items) =>
          items.map((item) =>
            item.id === result.data!.id ? result.data! : item,
          ),
        )
      }
    }
    setJoinedRoutes((current) => {
      const next = new Set(current)
      next.delete(routeId)
      return next
    })
  }

  return (
    <div
      className="min-h-screen flex"
      style={{
        background: "linear-gradient(135deg, #0d0520 0%, #1a0840 100%)",
      }}
    >
      <aside
        className="w-60 shrink-0 flex flex-col border-r border-purple-500/10 py-6 px-4"
        style={{ background: "rgba(255,255,255,0.02)" }}
      >
        <div className="flex items-center gap-3 px-3 mb-8">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #9333ea, #7e22ce)" }}
          >
            <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
              <path d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
            </svg>
          </div>
          <span
            className="text-lg font-bold text-white"
            style={{ fontFamily: "Outfit, sans-serif" }}
          >
            U-Go
          </span>
        </div>
        <nav className="flex-1 space-y-1">
          {[
            { id: "routes" as Tab, label: "Buscar rotas", icon: "🔍" },
            { id: "my-routes" as Tab, label: "Minhas rotas", icon: "🗺️" },
            { id: "qr-code" as Tab, label: "Meu QR Code", icon: "QR" },
            { id: "contracts" as Tab, label: "Contratos", icon: "📄" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === item.id
                  ? "text-white"
                  : "text-purple-300/50 hover:text-purple-200 hover:bg-white/5"
              }`}
              style={
                tab === item.id
                  ? {
                      background: "rgba(147,51,234,0.2)",
                      borderLeft: "2px solid #9333ea",
                    }
                  : {}
              }
            >
              <span>{item.icon}</span>
              {item.label}
              {item.id === "my-routes" && joinedRoutes.size > 0 && (
                <span
                  className="ml-auto text-xs px-1.5 py-0.5 rounded-full text-white"
                  style={{ background: "#9333ea" }}
                >
                  {joinedRoutes.size}
                </span>
              )}
            </button>
          ))}
        </nav>
        <div className="px-3 py-2 mb-3">
          <p className="text-xs text-purple-300/40 truncate">{name}</p>
          {profile?.company && (
            <p className="text-xs text-purple-300/25">{profile.company}</p>
          )}
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-3 py-2 text-sm text-purple-300/50 hover:text-red-400 transition-colors"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.5}
            className="w-4 h-4"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"
            />
          </svg>
          Sair
        </button>
      </aside>

      <main className="flex-1 overflow-y-auto p-8">
        {tab === "routes" && (
          <div>
            <p className="text-purple-300/50 text-sm mb-1">Bem-vindo 👋</p>
            <h1
              className="text-3xl font-bold text-white mb-6"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              Olá, {firstName}!
            </h1>

            <div className="relative mb-6">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.5}
                className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-purple-300/40"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"
                />
              </svg>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por origem, destino ou nome da rota..."
                className="w-full pl-11 pr-4 py-3 rounded-xl text-white text-sm placeholder-purple-300/30 border border-purple-500/25 focus:border-purple-500 transition-colors"
                style={{
                  background: "rgba(255,255,255,0.05)",
                  outline: "none",
                }}
              />
            </div>

            <div className="space-y-4">
              {filtered.map((r) => {
                const full = r.occupiedSeats >= r.seats
                const joined = joinedRoutes.has(r.id)
                return (
                  <div
                    key={r.id}
                    className="rounded-2xl border border-purple-500/15 p-5"
                    style={{ background: "rgba(255,255,255,0.03)" }}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3
                            className="font-semibold text-white"
                            style={{ fontFamily: "Outfit, sans-serif" }}
                          >
                            {r.name}
                          </h3>
                          {joined && (
                            <span
                              className="text-xs px-2 py-0.5 rounded-full text-purple-300 font-medium"
                              style={{ background: "rgba(147,51,234,0.2)" }}
                            >
                              Inscrito
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-purple-300/50 mb-3">
                          {r.origin} → {r.destination}
                        </p>
                        <div className="flex flex-wrap gap-4 text-xs text-purple-300/60 mb-3">
                          <span>
                            🕐 {r.departureTime} / {r.returnTime}
                          </span>
                          <span>
                            🚌 {r.driverName} · {r.vehicle}
                          </span>
                          <span>💰 R$ {r.price}/mês</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mb-3">
                          {r.days.map((d) => (
                            <span
                              key={d}
                              className="text-xs px-2 py-0.5 rounded-full text-purple-300/50"
                              style={{ background: "rgba(147,51,234,0.08)" }}
                            >
                              {d}
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center gap-3">
                          <div
                            className="h-1.5 rounded-full w-28"
                            style={{ background: "rgba(147,51,234,0.1)" }}
                          >
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${Math.min((r.occupiedSeats / r.seats) * 100, 100)}%`,
                                background: full
                                  ? "#ef4444"
                                  : "linear-gradient(to right,#9333ea,#c084fc)",
                              }}
                            />
                          </div>
                          <span className="text-xs text-purple-300/50">
                            {r.seats - r.occupiedSeats} vaga
                            {r.seats - r.occupiedSeats !== 1 ? "s" : ""} livre
                            {r.seats - r.occupiedSeats !== 1 ? "s" : ""}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 shrink-0">
                        <button
                          onClick={() => setMapRoute(r)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border border-purple-500/30 text-purple-300 hover:bg-purple-500/10 transition-all"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={1.5}
                            className="w-3.5 h-3.5"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M9 6.75V15m6-6v8.25m.503 3.498 4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 0 0-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0Z"
                            />
                          </svg>
                          Ver no mapa
                        </button>
                        <button
                          disabled={full || joined}
                          onClick={() => {
                            setJoinError("")
                            setJoinConfirm(r)
                          }}
                          className="px-5 py-2 rounded-xl text-sm font-semibold transition-all"
                          style={
                            joined
                              ? {
                                  background: "rgba(147,51,234,0.15)",
                                  color: "#c084fc",
                                  cursor: "default",
                                }
                              : full
                                ? {
                                    background: "rgba(255,255,255,0.05)",
                                    color: "rgba(255,255,255,0.2)",
                                    cursor: "not-allowed",
                                  }
                                : {
                                    background:
                                      "linear-gradient(135deg, #9333ea, #7e22ce)",
                                    color: "white",
                                  }
                          }
                        >
                          {joined
                            ? "Inscrito ✓"
                            : full
                              ? "Lotado"
                              : "Aderir rota"}
                        </button>
                      </div>
                    </div>
                  </div>
                )
              })}
              {filtered.length === 0 && (
                <div className="text-center py-16 text-purple-300/40">
                  <p>
                    {search ? (
                      <>Nenhuma rota encontrada para &ldquo;{search}&rdquo;</>
                    ) : (
                      "Nenhuma rota disponível no momento."
                    )}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "my-routes" && (
          <div>
            <h1
              className="text-2xl font-bold text-white mb-6"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              Minhas rotas
            </h1>
            {myRoutes.length === 0 ? (
              <div className="text-center py-16 text-purple-300/40">
                <p className="text-lg mb-2">
                  Você ainda não aderiu a nenhuma rota
                </p>
                <button
                  onClick={() => setTab("routes")}
                  className="text-sm text-purple-400 hover:text-purple-300 underline underline-offset-2"
                >
                  Buscar rotas disponíveis
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {myRoutes.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-2xl border border-purple-500/30 p-5"
                    style={{ background: "rgba(147,51,234,0.05)" }}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3
                          className="font-semibold text-white mb-1"
                          style={{ fontFamily: "Outfit, sans-serif" }}
                        >
                          {r.name}
                        </h3>
                        <p className="text-xs text-purple-300/50 mb-3">
                          {r.origin} → {r.destination}
                        </p>
                        <div className="flex flex-wrap gap-4 text-xs text-purple-300/60">
                          <span>
                            🕐 {r.departureTime} / {r.returnTime}
                          </span>
                          <span>🚌 {r.driverName}</span>
                          <span>💰 R$ {r.price}/mês</span>
                        </div>
                      </div>
                      <button
                        onClick={() => cancelJoin(r.id)}
                        className="text-xs px-3 py-1.5 rounded-lg border border-red-500/30 text-red-400/70 hover:text-red-400 transition-colors"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "qr-code" && <CollaboratorQrCard />}

        {tab === "contracts" && (
          <ContractsPanel
            contracts={contracts}
            viewerRole="collaborator"
            onContractChange={(updated) => {
              setContracts((items) =>
                items.map((item) => (item.id === updated.id ? updated : item)),
              )
              if (updated.status === "cancelled" && updated.routeId) {
                setJoinedRoutes((current) => {
                  const next = new Set(current)
                  next.delete(updated.routeId!)
                  return next
                })
              }
            }}
          />
        )}
      </main>

      {mapRoute && (
        <RouteMapModal route={mapRoute} onClose={() => setMapRoute(null)} />
      )}

      {joinConfirm && (
        <ContractAcceptanceModal
          route={joinConfirm}
          error={joinError}
          onCancel={() => {
            setJoinError("")
            setJoinConfirm(null)
          }}
          onConfirm={confirmJoin}
        />
      )}
    </div>
  )
}
