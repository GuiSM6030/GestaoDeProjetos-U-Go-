import { useState } from "react"
import RouteMap from "./RouteMap"
import type { Route } from "../types"

interface Props {
  route: Route
  onClose: () => void
}

export default function RouteMapModal({ route, onClose }: Props) {
  const [selectedPickupPointId, setSelectedPickupPointId] =
    useState<string | null>(null)
  const [tab, setTab] = useState<"map" | "schedule">("map")
  const [scheduleTime, setScheduleTime] = useState("")
  const pickupPoints = route.pickupPoints ?? []
  const toMinutes = (time: string) => {
    const [hours, minutes] = time.split(":").map(Number)
    return hours * 60 + minutes
  }
  const scheduleAvailable =
    !scheduleTime ||
    (toMinutes(scheduleTime) >= toMinutes(route.departureTime) &&
      toMinutes(scheduleTime) <=
        toMinutes(route.arrivalTime ?? route.returnTime))

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)" }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div
        className="flex w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-purple-500/20"
        style={{ background: "#0d0520", height: "min(720px, 90vh)" }}
        role="dialog"
        aria-modal="true"
        aria-labelledby="route-details-title"
      >
        {/* Header */}
        <div className="flex items-start justify-between px-5 py-4 border-b border-purple-500/10">
          <div>
            <h3
              id="route-details-title"
              className="text-base font-semibold text-white"
              style={{ fontFamily: "Outfit, sans-serif" }}
            >
              {route.name}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="flex items-center gap-1 text-xs text-purple-300/50">
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.5}
                  className="w-3.5 h-3.5 text-purple-400"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"
                  />
                </svg>
                {route.origin}
              </span>
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                className="w-3 h-3 text-purple-400/40 shrink-0"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
              <span className="flex items-center gap-1 text-xs text-purple-300/50">
                <svg
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="w-3.5 h-3.5 text-fuchsia-400"
                >
                  <path
                    fillRule="evenodd"
                    d="M11.54 22.351l.07.04.028.016a.76.76 0 0 0 .723 0l.028-.015.071-.041a16.975 16.975 0 0 0 1.144-.742 19.58 19.58 0 0 0 2.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 0 0-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 0 0 2.682 2.282 16.975 16.975 0 0 0 1.145.742ZM12 13.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"
                    clipRule="evenodd"
                  />
                </svg>
                {route.destination}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar detalhes do itinerário"
            className="text-purple-300/40 hover:text-white transition-colors ml-4 mt-0.5"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* Route info strip */}
        <div
          className="flex items-center gap-6 px-5 py-2.5 border-b border-purple-500/10 text-xs text-purple-300/50"
          style={{ background: "rgba(255,255,255,0.02)" }}
        >
          <span>
            🕐 {route.departureTime} / {route.returnTime}
          </span>
          <span>
            💺 {route.occupiedSeats}/{route.seats} vagas
          </span>
          {route.price > 0 && <span>💰 R$ {route.price}/mês</span>}
          <span>{route.days.join(", ")}</span>
        </div>

        <div className="flex items-center gap-2 border-b border-purple-500/10 px-5 py-2">
          <button
            type="button"
            onClick={() => setTab("map")}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              tab === "map"
                ? "bg-purple-600 text-white"
                : "text-purple-300/55 hover:bg-purple-500/10 hover:text-purple-100"
            }`}
          >
            Mapa e pontos
          </button>
          <button
            type="button"
            onClick={() => setTab("schedule")}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              tab === "schedule"
                ? "bg-purple-600 text-white"
                : "text-purple-300/55 hover:bg-purple-500/10 hover:text-purple-100"
            }`}
          >
            Horários
          </button>
        </div>

        {tab === "map" && (
          <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
            <aside className="max-h-64 w-full shrink-0 overflow-y-auto border-b border-purple-500/10 bg-white/[0.02] p-4 lg:max-h-none lg:w-80 lg:border-b-0 lg:border-r">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <h4 className="text-sm font-semibold text-white">
                    Pontos do itinerário
                  </h4>
                  <p className="mt-1 text-xs text-purple-300/45">
                    Selecione um ponto para localizá-lo no mapa.
                  </p>
                </div>
                <span className="shrink-0 rounded-full bg-purple-500/15 px-2.5 py-1 text-xs font-medium text-purple-200">
                  {pickupPoints.length}
                </span>
              </div>

              <ol className="space-y-2">
                <li className="flex gap-3 rounded-xl border border-purple-500/15 bg-purple-500/5 p-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-purple-600 text-xs font-bold text-white">
                    O
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs font-medium uppercase tracking-wide text-purple-400">
                      Origem
                    </p>
                    <p className="mt-0.5 text-sm font-medium text-white">
                      {route.origin}
                    </p>
                  </div>
                </li>

                {pickupPoints.map((point, index) => {
                  const selected = selectedPickupPointId === point.id
                  return (
                    <li key={point.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedPickupPointId(point.id)}
                        aria-pressed={selected}
                        className={`flex w-full gap-3 rounded-xl border p-3 text-left transition-all ${
                          selected
                            ? "border-fuchsia-400/60 bg-fuchsia-500/15 shadow-lg shadow-fuchsia-950/20"
                            : "border-purple-500/15 bg-white/[0.03] hover:border-purple-400/40 hover:bg-purple-500/10"
                        }`}
                      >
                        <span
                          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white ${
                            selected ? "bg-fuchsia-600" : "bg-purple-700"
                          }`}
                        >
                          {index + 1}
                        </span>
                        <span className="min-w-0">
                          <span className="block text-xs font-medium uppercase tracking-wide text-purple-400">
                            Ponto de embarque
                          </span>
                          <span className="mt-0.5 block text-sm font-medium text-white">
                            {point.name}
                          </span>
                          <span className="mt-1 block text-xs leading-relaxed text-purple-300/45">
                            {point.address}
                          </span>
                        </span>
                      </button>
                    </li>
                  )
                })}

                {pickupPoints.length === 0 && (
                  <li
                    className="rounded-xl border border-dashed border-purple-500/20 bg-purple-500/5 px-4 py-5 text-center text-sm text-purple-200/60"
                    role="status"
                  >
                    Nenhum ponto de embarque disponível neste trecho
                  </li>
                )}

                <li className="flex gap-3 rounded-xl border border-fuchsia-500/15 bg-fuchsia-500/5 p-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-fuchsia-600 text-xs font-bold text-white">
                    D
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs font-medium uppercase tracking-wide text-fuchsia-400">
                      Desembarque
                    </p>
                    <p className="mt-0.5 text-sm font-medium text-white">
                      {route.destination}
                    </p>
                  </div>
                </li>
              </ol>
            </aside>

            <div className="min-h-72 flex-1">
              <RouteMap
                origin={route.origin}
                destination={route.destination}
                pickupPoints={pickupPoints}
                selectedPickupPointId={selectedPickupPointId}
                onPickupPointSelect={(point) =>
                  setSelectedPickupPointId(point.id)
                }
              />
            </div>
          </div>
        )}

        {tab === "schedule" && (
          <div className="min-h-0 flex-1 overflow-y-auto p-5">
            <div className="mx-auto max-w-3xl">
              <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
                <div>
                  <h4 className="text-lg font-semibold text-white">
                    Grade horária do itinerário
                  </h4>
                  <p className="mt-1 text-sm text-purple-300/50">
                    Horários previstos de chegada e partida em cada ponto.
                  </p>
                </div>
                <label className="w-full sm:w-52">
                  <span className="mb-1 block text-xs font-medium text-purple-200/70">
                    Consultar período
                  </span>
                  <input
                    type="time"
                    value={scheduleTime}
                    onChange={(event) => setScheduleTime(event.target.value)}
                    className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white focus:border-purple-500"
                  />
                </label>
              </div>

              {!scheduleAvailable ? (
                <div
                  className="rounded-2xl border border-dashed border-purple-500/20 py-14 text-center text-sm text-purple-300/55"
                  role="status"
                >
                  Nenhum horário disponível no período selecionado
                </div>
              ) : (
                <div className="overflow-hidden rounded-2xl border border-purple-500/15">
                  <div className="grid grid-cols-[1fr_90px_90px] gap-3 border-b border-purple-500/15 bg-purple-500/10 px-4 py-3 text-xs font-semibold uppercase tracking-wide text-purple-300/60">
                    <span>Local</span>
                    <span>Chegada</span>
                    <span>Partida</span>
                  </div>
                  <div className="grid grid-cols-[1fr_90px_90px] gap-3 border-b border-purple-500/10 px-4 py-4">
                    <div>
                      <p className="text-sm font-medium text-white">
                        {route.origin}
                      </p>
                      <p className="mt-0.5 text-xs text-purple-300/40">
                        Origem
                      </p>
                    </div>
                    <span className="text-sm text-purple-300/40">—</span>
                    <span className="text-sm font-semibold text-purple-200">
                      {route.departureTime}
                    </span>
                  </div>
                  {pickupPoints.map((point, index) => (
                    <button
                      type="button"
                      key={point.id}
                      onClick={() => {
                        setSelectedPickupPointId(point.id)
                        setTab("map")
                      }}
                      className="grid w-full grid-cols-[1fr_90px_90px] gap-3 border-b border-purple-500/10 px-4 py-4 text-left transition-colors hover:bg-purple-500/10"
                    >
                      <span>
                        <span className="block text-sm font-medium text-white">
                          {index + 1}. {point.name}
                        </span>
                        <span className="mt-0.5 block text-xs text-purple-300/40">
                          {point.address}
                        </span>
                      </span>
                      <span className="text-sm text-purple-100">
                        {point.arrivalTime || "A definir"}
                      </span>
                      <span className="text-sm font-semibold text-purple-200">
                        {point.departureTime || "A definir"}
                      </span>
                    </button>
                  ))}
                  <div className="grid grid-cols-[1fr_90px_90px] gap-3 px-4 py-4">
                    <div>
                      <p className="text-sm font-medium text-white">
                        {route.destination}
                      </p>
                      <p className="mt-0.5 text-xs text-fuchsia-300/50">
                        Destino
                      </p>
                    </div>
                    <span className="text-sm font-semibold text-fuchsia-200">
                      {route.arrivalTime ?? route.returnTime}
                    </span>
                    <span className="text-sm text-purple-300/40">—</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
