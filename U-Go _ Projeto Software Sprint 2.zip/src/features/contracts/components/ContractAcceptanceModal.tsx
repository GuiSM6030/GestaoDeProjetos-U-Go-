import { useState } from "react"
import type { Route } from "../../../types"

interface Props {
  route: Route
  error?: string
  onCancel: () => void
  onConfirm: () => Promise<void>
}

const formatCurrency = (value: number) =>
  value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  })

export default function ContractAcceptanceModal({
  route,
  error,
  onCancel,
  onConfirm,
}: Props) {
  const [accepted, setAccepted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const handleConfirm = async () => {
    if (!accepted || submitting) return
    setSubmitting(true)
    try {
      await onConfirm()
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto p-4"
      style={{ background: "rgba(0,0,0,0.68)", backdropFilter: "blur(6px)" }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="contract-acceptance-title"
    >
      <div
        className="my-auto w-full max-w-xl overflow-hidden rounded-2xl border border-purple-500/20 shadow-2xl"
        style={{ background: "#1a0840" }}
      >
        <div className="border-b border-purple-500/15 px-6 py-5">
          <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-purple-400">
            Contrato de adesão
          </p>
          <h3
            id="contract-acceptance-title"
            className="text-xl font-semibold text-white"
          >
            Revise e confirme sua assinatura
          </h3>
          <p className="mt-1 text-sm text-purple-200/55">
            Confira os dados da rota e os termos antes de continuar.
          </p>
        </div>

        <div className="max-h-[70vh] space-y-5 overflow-y-auto px-6 py-5">
          <section aria-labelledby="route-summary-title">
            <h4
              id="route-summary-title"
              className="mb-3 text-sm font-semibold text-white"
            >
              Resumo da rota
            </h4>
            <div
              className="grid grid-cols-1 gap-3 rounded-xl border border-purple-500/15 p-4 sm:grid-cols-2"
              style={{ background: "rgba(255,255,255,0.035)" }}
            >
              <div className="sm:col-span-2">
                <p className="text-xs text-purple-300/45">Rota</p>
                <p className="mt-0.5 font-medium text-white">{route.name}</p>
                <p className="mt-1 text-sm text-purple-200/60">
                  {route.origin} → {route.destination}
                </p>
              </div>
              <div>
                <p className="text-xs text-purple-300/45">Horários</p>
                <p className="mt-0.5 text-sm text-purple-100">
                  Ida {route.departureTime} · Volta {route.returnTime}
                </p>
              </div>
              <div>
                <p className="text-xs text-purple-300/45">Dias</p>
                <p className="mt-0.5 text-sm text-purple-100">
                  {route.days.length ? route.days.join(", ") : "A definir"}
                </p>
              </div>
              <div>
                <p className="text-xs text-purple-300/45">Prestador</p>
                <p className="mt-0.5 text-sm text-purple-100">
                  {route.driverName || "A definir"}
                </p>
              </div>
              <div>
                <p className="text-xs text-purple-300/45">Veículo</p>
                <p className="mt-0.5 text-sm text-purple-100">
                  {route.vehicle || "A definir"}
                </p>
              </div>
              <div className="sm:col-span-2">
                <p className="text-xs text-purple-300/45">Mensalidade</p>
                <p className="mt-0.5 text-lg font-semibold text-purple-300">
                  {formatCurrency(route.price)}
                  <span className="text-xs font-normal text-purple-300/50">
                    {" "}
                    / mês
                  </span>
                </p>
                <p className="mt-1 text-xs text-purple-200/55">
                  Vencimento todo dia {route.dueDay ?? "a definir"}
                </p>
                <p className="mt-1 text-xs text-purple-200/55">
                  Prazo mínimo de {route.minimumTermMonths ?? 3} meses · Multa
                  antecipada de {route.earlyTerminationFeePercent ?? 20}%
                </p>
              </div>
            </div>
          </section>

          <section aria-labelledby="contract-terms-title">
            <h4
              id="contract-terms-title"
              className="mb-3 text-sm font-semibold text-white"
            >
              Termos do contrato
            </h4>
            <div className="rounded-xl border border-purple-500/15 bg-purple-950/30 p-4 text-sm leading-relaxed text-purple-100/65">
              <ol className="list-decimal space-y-2 pl-4">
                <li>
                  A adesão garante uma vaga na rota descrita acima durante a
                  vigência do contrato, sujeita à disponibilidade informada.
                </li>
                <li>
                  A mensalidade deverá ser paga conforme as condições acordadas
                  com o prestador do transporte.
                </li>
                <li>
                  Horários, pontos de embarque e veículo podem sofrer ajustes
                  operacionais, que deverão ser comunicados previamente.
                </li>
                <li>
                  O cancelamento da adesão deve respeitar as regras e eventuais
                  prazos acordados entre o contratante e o prestador, incluindo
                  a multa de rescisão antecipada informada no resumo.
                </li>
              </ol>
            </div>
          </section>

          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-purple-500/20 bg-purple-500/5 p-4 transition-colors hover:bg-purple-500/10">
            <input
              type="checkbox"
              checked={accepted}
              onChange={(event) => setAccepted(event.target.checked)}
              className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer"
            />
            <span className="text-sm leading-relaxed text-purple-100/75">
              Li e aceito os termos do contrato, confirmo que os dados da rota
              estão corretos e concordo com a assinatura eletrônica desta
              adesão.
            </span>
          </label>

          {error && (
            <p
              role="alert"
              className="rounded-xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-sm text-red-200"
            >
              {error}
            </p>
          )}
        </div>

        <div className="flex flex-col-reverse gap-3 border-t border-purple-500/15 px-6 py-4 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={onCancel}
            disabled={submitting}
            className="rounded-xl border border-purple-500/30 px-5 py-2.5 text-sm font-medium text-purple-300 transition-colors hover:bg-purple-500/10 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={!accepted || submitting}
            className="rounded-xl px-5 py-2.5 text-sm font-semibold text-white transition-all disabled:cursor-not-allowed disabled:opacity-40"
            style={{
              background: "linear-gradient(135deg, #9333ea, #7e22ce)",
            }}
          >
            {submitting ? "Assinando..." : "Assinar e Confirmar"}
          </button>
        </div>
      </div>
    </div>
  )
}
