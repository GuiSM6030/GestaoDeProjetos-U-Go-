import { useEffect, useState } from "react"
import {
  contractLifecycleService,
  type ContractAmendment,
} from "../services/contractLifecycleService"

interface Props {
  onAccepted: () => void
}

const currency = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })

export default function ContractAmendmentsPanel({ onAccepted }: Props) {
  const [items, setItems] = useState<ContractAmendment[]>([])
  const [loadingId, setLoadingId] = useState("")
  const [error, setError] = useState("")

  useEffect(() => {
    contractLifecycleService
      .listPendingAmendments()
      .then(setItems)
      .catch((loadError) =>
        setError(
          loadError instanceof Error
            ? loadError.message
            : "Não foi possível carregar os aditivos.",
        ),
      )
  }, [])

  if (items.length === 0 && !error) return null

  const accept = async (item: ContractAmendment) => {
    setLoadingId(item.id)
    setError("")
    try {
      await contractLifecycleService.acceptAmendment(item.id)
      setItems((current) => current.filter((entry) => entry.id !== item.id))
      onAccepted()
    } catch (acceptError) {
      setError(
        acceptError instanceof Error
          ? acceptError.message
          : "Não foi possível aceitar o aditivo.",
      )
    } finally {
      setLoadingId("")
    }
  }

  return (
    <div className="mb-6 space-y-3">
      {items.map((item) => (
        <article
          key={item.id}
          className="rounded-2xl border border-amber-500/25 bg-amber-500/10 p-5"
        >
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-300">
                Novo aditivo contratual
              </p>
              <h2 className="mt-1 font-semibold text-white">
                {item.routeName}
              </h2>
              <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-purple-100/65">
                <span>
                  Mensalidade: {currency(item.oldMonthlyPrice)} →{" "}
                  {currency(item.newMonthlyPrice)}
                </span>
                <span>
                  Vencimento: dia {item.oldDueDay} → dia {item.newDueDay}
                </span>
                <span>Prazo mínimo: {item.newMinimumTermMonths} meses</span>
                <span>Multa antecipada: {item.newTerminationFeePercent}%</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => accept(item)}
              disabled={loadingId === item.id}
              className="shrink-0 rounded-xl bg-amber-500 px-4 py-2.5 text-sm font-semibold text-[#1a0840] hover:bg-amber-400 disabled:opacity-50"
            >
              {loadingId === item.id ? "Aceitando..." : "Revisar e aceitar"}
            </button>
          </div>
        </article>
      ))}
      {error && (
        <p
          className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200"
          role="alert"
        >
          {error}
        </p>
      )}
    </div>
  )
}
