import { supabase } from "../../../lib/supabase"
import { jsonApi } from "../../../lib/jsonRestApi"

export interface ContractAmendment {
  id: string
  routeId: string
  routeName: string
  oldMonthlyPrice: number
  newMonthlyPrice: number
  oldDueDay: number
  newDueDay: number
  newMinimumTermMonths: number
  newTerminationFeePercent: number
  createdAt: string
}

export interface TerminationPreview {
  overdueCount: number
  overdueAmount: number
  residualFee: number
  canTerminate: boolean
}

interface RouteNameRow {
  id: string
  name: string
}

export const contractLifecycleService = {
  async listPendingAmendments(): Promise<ContractAmendment[]> {
    const { data: userData } = await supabase.auth.getUser()
    if (!userData.user) return []
    const { data: acceptances, error: acceptanceError } = await jsonApi
      .from("contract_amendment_acceptances")
      .select("amendment_id")
      .eq("student_id", userData.user.id)
      .eq("status", "pending")
    if (acceptanceError) throw new Error(acceptanceError.message)
    const ids = (acceptances ?? []).map(
      (item: { amendment_id: string }) => item.amendment_id,
    )
    if (ids.length === 0) return []

    const { data: amendments, error } = await jsonApi
      .from("contract_amendments")
      .select("*")
      .in("id", ids)
      .eq("status", "pending")
      .order("created_at", { ascending: false })
    if (error) throw new Error(error.message)
    const routeIds = [
      ...new Set(
        (amendments ?? []).map((item: { route_id: string }) => item.route_id),
      ),
    ]
    const { data: routes } = await jsonApi
      .from("driver_routes")
      .select("id, name")
      .in("id", routeIds)
    const routeNames = new Map(
      (routes ?? []).map((route: RouteNameRow) => [route.id, route.name]),
    )
    return (amendments ?? []).map((item: any) => ({
      id: item.id,
      routeId: item.route_id,
      routeName: routeNames.get(item.route_id) ?? "Rota",
      oldMonthlyPrice: Number(item.old_monthly_price),
      newMonthlyPrice: Number(item.new_monthly_price),
      oldDueDay: item.old_due_day,
      newDueDay: item.new_due_day,
      newMinimumTermMonths: item.new_minimum_term_months,
      newTerminationFeePercent: Number(item.new_termination_fee_percent),
      createdAt: item.created_at,
    }))
  },

  async acceptAmendment(id: string) {
    const { error } = await jsonApi.rpc("accept_contract_amendment", {
      p_amendment_id: id,
    })
    if (error) throw new Error(error.message)
  },

  async previewTermination(membershipId: string): Promise<TerminationPreview> {
    const { data, error } = await jsonApi.rpc("preview_contract_termination", {
      p_membership_id: membershipId,
    })
    if (error) throw new Error(error.message)
    return {
      overdueCount: Number(data.overdueCount ?? 0),
      overdueAmount: Number(data.overdueAmount ?? 0),
      residualFee: Number(data.residualFee ?? 0),
      canTerminate: Boolean(data.canTerminate),
    }
  },

  async terminate(membershipId: string, reason?: string) {
    const { data, error } = await jsonApi.rpc("terminate_student_contract", {
      p_membership_id: membershipId,
      p_reason: reason ?? null,
    })
    if (error) throw new Error(error.message)
    return { residualFee: Number(data.residualFee ?? 0) }
  },
}
