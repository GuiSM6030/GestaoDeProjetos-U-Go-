import { useEffect, useMemo, useState } from "react"
import { CardPayment, initMercadoPago } from "@mercadopago/sdk-react"
import { paymentService, PaymentRequestError } from "../services/paymentService"
import type { PaymentCharge } from "../types"

interface Props {
  onPaymentConfirmed?: () => void
}

let initializedPublicKey = ""

const formatCurrency = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })

const formatDate = (value: string) =>
  new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" }).format(
    new Date(`${value.slice(0, 10)}T12:00:00Z`),
  )

const statusLabels: Record<PaymentCharge["status"], string> = {
  pending: "Pendente",
  paid: "Pago",
  refunded: "Estornado",
}

const MINIMUM_CARD_AMOUNT = 1

export default function PaymentsPanel({ onPaymentConfirmed }: Props) {
  const [charges, setCharges] = useState<PaymentCharge[]>([])
  const [publicKey, setPublicKey] = useState("")
  const [selected, setSelected] = useState<PaymentCharge | null>(null)
  const [method, setMethod] = useState<"pix" | "credit_card" | null>(null)
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [error, setError] = useState("")
  const [suggestion, setSuggestion] = useState("")
  const [message, setMessage] = useState("")

  const load = async () => {
    setLoading(true)
    setError("")
    try {
      const [config, items] = await Promise.all([
        paymentService.getConfig(),
        paymentService.listCharges(),
      ])
      if (initializedPublicKey !== config.publicKey) {
        initMercadoPago(config.publicKey, { locale: "pt-BR" })
        initializedPublicKey = config.publicKey
      }
      setPublicKey(config.publicKey)
      setCharges(items)
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : "Não foi possível carregar as cobranças.",
      )
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void load()
  }, [])

  useEffect(() => {
    if (!selected || method !== "pix" || selected.status !== "pending") return
    const timer = window.setInterval(() => {
      paymentService
        .sync(selected.id)
        .then((updated) => {
          setSelected(updated)
          setCharges((items) =>
            items.map((item) => (item.id === updated.id ? updated : item)),
          )
          if (updated.status === "paid") {
            setMessage("Pagamento confirmado com sucesso.")
            onPaymentConfirmed?.()
          }
        })
        .catch(() => undefined)
    }, 8000)
    return () => window.clearInterval(timer)
  }, [method, onPaymentConfirmed, selected])

  const currentCharges = useMemo(
    () => charges.filter((charge) => charge.status === "pending"),
    [charges],
  )
  const history = useMemo(
    () => charges.filter((charge) => charge.status !== "pending"),
    [charges],
  )

  const updateCharge = (updated: PaymentCharge) => {
    setSelected((current) =>
      current?.id === updated.id
        ? {
            ...current,
            ...updated,
            routeName: current.routeName,
            driverName: current.driverName,
          }
        : updated,
    )
    setCharges((items) =>
      items.map((item) =>
        item.id === updated.id
          ? {
              ...item,
              ...updated,
              routeName: item.routeName,
              driverName: item.driverName,
            }
          : item,
      ),
    )
    if (updated.status === "paid") onPaymentConfirmed?.()
  }

  const openPayment = (
    charge: PaymentCharge,
    selectedMethod: "pix" | "credit_card",
  ) => {
    setSelected(charge)
    setMethod(selectedMethod)
    setError("")
    setSuggestion("")
    setMessage("")
    if (
      selectedMethod === "credit_card" &&
      charge.amount < MINIMUM_CARD_AMOUNT
    ) {
      setError(
        "O pagamento com cartão exige o valor mínimo de R$ 1,00 no Mercado Pago.",
      )
      setSuggestion(
        "Ajuste o valor da mensalidade ou utilize Pix para esta cobrança.",
      )
      return
    }
    if (selectedMethod === "pix") {
      setProcessing(true)
      paymentService
        .payWithPix(charge.id)
        .then(updateCharge)
        .catch((paymentError) => {
          setError(
            paymentError instanceof Error
              ? paymentError.message
              : "Pagamento não confirmado.",
          )
        })
        .finally(() => setProcessing(false))
    }
  }

  const verifyPayment = async () => {
    if (!selected || processing) return
    setProcessing(true)
    setError("")
    try {
      const updated = await paymentService.sync(selected.id)
      updateCharge(updated)
      setMessage(
        updated.status === "paid"
          ? "Pagamento confirmado com sucesso."
          : "Pagamento ainda não confirmado. A cobrança permanece pendente.",
      )
    } catch (syncError) {
      setError(
        syncError instanceof Error
          ? syncError.message
          : "Pagamento não confirmado.",
      )
    } finally {
      setProcessing(false)
    }
  }

  const closePayment = () => {
    if (processing) return
    setSelected(null)
    setMethod(null)
    setError("")
    setSuggestion("")
    setMessage("")
  }

  return (
    <section>
      <div className="mb-6">
        <p className="mb-1 text-sm text-purple-300/50">
          Mensalidades e histórico financeiro
        </p>
        <h1 className="text-2xl font-bold text-white">Pagamentos</h1>
      </div>

      {error && !selected && (
        <p
          className="mb-4 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200"
          role="alert"
        >
          {error}
        </p>
      )}

      {loading ? (
        <div className="py-16 text-center text-purple-300/45">
          Carregando cobranças...
        </div>
      ) : (
        <div className="space-y-8">
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">
                Cobranças em aberto
              </h2>
              <span className="rounded-full bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-300">
                {currentCharges.length}
              </span>
            </div>
            <div className="space-y-3">
              {currentCharges.map((charge) => (
                <article
                  key={charge.id}
                  className="rounded-2xl border border-purple-500/20 bg-white/[0.03] p-5"
                >
                  <div className="flex flex-col justify-between gap-5 md:flex-row md:items-center">
                    <div>
                      <div className="mb-2 flex flex-wrap items-center gap-2">
                        <h3 className="font-semibold text-white">
                          {charge.routeName}
                        </h3>
                        <span className="rounded-full bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-300">
                          Pendente
                        </span>
                      </div>
                      <p className="text-sm text-purple-200/60">
                        {charge.driverName}
                      </p>
                      <div className="mt-3 flex flex-wrap gap-4 text-xs text-purple-300/50">
                        <span>Vencimento: {formatDate(charge.dueDate)}</span>
                        <span>
                          Referência: {charge.referenceMonth.slice(0, 7)}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                      <p className="mr-2 text-xl font-bold text-white">
                        {formatCurrency(charge.amount)}
                      </p>
                      <button
                        type="button"
                        onClick={() => openPayment(charge, "pix")}
                        className="rounded-xl border border-teal-400/30 bg-teal-500/10 px-4 py-2.5 text-sm font-semibold text-teal-200 hover:bg-teal-500/20"
                      >
                        Pagar com Pix
                      </button>
                      <button
                        type="button"
                        onClick={() => openPayment(charge, "credit_card")}
                        className="rounded-xl bg-purple-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-purple-500"
                      >
                        Pagar com cartão
                      </button>
                    </div>
                  </div>
                </article>
              ))}
              {currentCharges.length === 0 && (
                <div className="rounded-2xl border border-dashed border-purple-500/20 py-12 text-center text-sm text-purple-300/45">
                  Nenhuma mensalidade pendente.
                </div>
              )}
            </div>
          </div>

          {history.length > 0 && (
            <div>
              <h2 className="mb-3 text-sm font-semibold text-white">
                Histórico
              </h2>
              <div className="space-y-2">
                {history.map((charge) => (
                  <div
                    key={charge.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-purple-500/10 bg-white/[0.02] px-4 py-3"
                  >
                    <div>
                      <p className="text-sm font-medium text-white">
                        {charge.routeName}
                      </p>
                      <p className="mt-0.5 text-xs text-purple-300/45">
                        Vencimento {formatDate(charge.dueDate)}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-purple-100">
                        {formatCurrency(charge.amount)}
                      </span>
                      <span
                        className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                          charge.status === "paid"
                            ? "bg-green-500/10 text-green-300"
                            : "bg-red-500/10 text-red-300"
                        }`}
                      >
                        {statusLabels[charge.status]}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {selected && method && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="payment-title"
        >
          <div className="my-auto w-full max-w-xl overflow-hidden rounded-2xl border border-purple-500/20 bg-[#1a0840] shadow-2xl">
            <div className="flex items-start justify-between border-b border-purple-500/15 px-6 py-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-purple-400">
                  Mensalidade · {selected.routeName}
                </p>
                <h2
                  id="payment-title"
                  className="mt-1 text-xl font-semibold text-white"
                >
                  {method === "pix" ? "Pagamento via Pix" : "Cartão de crédito"}
                </h2>
                <p className="mt-1 text-sm text-purple-200/55">
                  {formatCurrency(selected.amount)}
                </p>
              </div>
              <button
                type="button"
                onClick={closePayment}
                disabled={processing}
                aria-label="Fechar pagamento"
                className="text-purple-300/45 hover:text-white disabled:opacity-40"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  className="h-5 w-5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18 18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>

            <div className="max-h-[75vh] overflow-y-auto p-6">
              {method === "pix" && (
                <div className="text-center">
                  {processing && !selected.pixQrCode && (
                    <p className="py-12 text-sm text-purple-200/60">
                      Gerando Pix...
                    </p>
                  )}
                  {selected.pixQrCodeBase64 && (
                    <img
                      src={
                        selected.pixQrCodeBase64.startsWith("data:")
                          ? selected.pixQrCodeBase64
                          : `data:image/png;base64,${selected.pixQrCodeBase64}`
                      }
                      alt="QR Code Pix da mensalidade"
                      className="mx-auto mb-4 h-52 w-52 rounded-xl bg-white p-3"
                    />
                  )}
                  {selected.pixQrCode && (
                    <>
                      <p className="mb-2 text-sm font-medium text-white">
                        Escaneie o QR Code ou use o Pix Copia e Cola
                      </p>
                      <div className="mb-4 rounded-xl border border-purple-500/20 bg-black/20 p-3 text-left">
                        <p className="break-all text-xs leading-relaxed text-purple-200/65">
                          {selected.pixQrCode}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          void navigator.clipboard.writeText(
                            selected.pixQrCode ?? "",
                          )
                          setMessage("Código Pix copiado.")
                        }}
                        className="mb-3 w-full rounded-xl border border-teal-400/30 bg-teal-500/10 px-4 py-2.5 text-sm font-semibold text-teal-200 hover:bg-teal-500/20"
                      >
                        Copiar código Pix
                      </button>
                      <button
                        type="button"
                        onClick={verifyPayment}
                        disabled={processing}
                        className="w-full rounded-xl bg-purple-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-purple-500 disabled:opacity-50"
                      >
                        {processing ? "Verificando..." : "Já paguei, verificar"}
                      </button>
                    </>
                  )}
                </div>
              )}

              {method === "credit_card" &&
                publicKey &&
                selected.amount >= MINIMUM_CARD_AMOUNT && (
                  <div className="overflow-hidden rounded-xl bg-white p-3">
                    <CardPayment
                      initialization={{ amount: selected.amount }}
                      customization={{
                        paymentMethods: {
                          maxInstallments: 1,
                          types: { included: ["credit_card"] },
                        },
                      }}
                      locale="pt-BR"
                      onSubmit={async (formData, additionalData) => {
                        setProcessing(true)
                        setError("")
                        setSuggestion("")
                        try {
                          const updated = await paymentService.payWithCard(
                            selected.id,
                            {
                              token: formData.token,
                              paymentMethodId: formData.payment_method_id,
                              paymentTypeId:
                                additionalData?.paymentTypeId ?? "credit_card",
                              installments: formData.installments,
                              identification: formData.payer.identification,
                            },
                          )
                          updateCharge(updated)
                          setMessage("Pagamento confirmado com sucesso.")
                        } catch (paymentError) {
                          setError(
                            paymentError instanceof Error
                              ? paymentError.message
                              : "Pagamento não confirmado.",
                          )
                          if (paymentError instanceof PaymentRequestError) {
                            setSuggestion(paymentError.suggestion ?? "")
                          }
                        } finally {
                          setProcessing(false)
                        }
                      }}
                      onError={(brickError) => {
                        console.error("Mercado Pago Card Brick", brickError)
                        setError(
                          brickError.message ||
                            "Não foi possível carregar o formulário do cartão.",
                        )
                        setSuggestion(
                          "Confira se a Public Key é de teste e tente novamente. Você também pode pagar com Pix.",
                        )
                      }}
                    />
                  </div>
                )}

              {error && (
                <div
                  className="mt-4 rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-left"
                  role="alert"
                >
                  <p className="text-sm font-semibold text-red-200">{error}</p>
                  {suggestion && (
                    <p className="mt-1 text-sm text-red-100/70">{suggestion}</p>
                  )}
                  {method === "credit_card" && (
                    <button
                      type="button"
                      onClick={() => {
                        setMethod("pix")
                        setError("")
                        setSuggestion("")
                        openPayment(selected, "pix")
                      }}
                      className="mt-3 text-sm font-semibold text-teal-300 hover:text-teal-200"
                    >
                      Pagar com Pix
                    </button>
                  )}
                </div>
              )}

              {message && (
                <p
                  className="mt-4 rounded-xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-200"
                  role="status"
                >
                  {message}
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
