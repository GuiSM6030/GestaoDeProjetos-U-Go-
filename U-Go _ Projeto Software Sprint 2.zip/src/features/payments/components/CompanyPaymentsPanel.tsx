import type { Contract } from "../../../types"

const formatCurrency = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })

export default function CompanyPaymentsPanel({
  contracts,
}: {
  contracts: Contract[]
}) {
  const current = contracts.filter((contract) =>
    ["active", "pending"].includes(contract.status),
  )
  const monthlyTotal = current.reduce(
    (total, contract) => total + contract.value,
    0,
  )

  return (
    <section>
      <p className="mb-1 text-sm text-purple-300/50">
        Gestão financeira corporativa
      </p>
      <h1 className="text-2xl font-bold text-white">Pagamentos</h1>
      <p className="mt-2 max-w-2xl text-sm text-purple-200/55">
        As mensalidades dos colaboradores são centralizadas na empresa. Os
        motoristas recebem os repasses usando os dados bancários cadastrados.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5">
          <p className="text-xs uppercase tracking-wide text-purple-300/45">
            Compromisso mensal
          </p>
          <p className="mt-2 text-2xl font-bold text-white">
            {formatCurrency(monthlyTotal)}
          </p>
        </div>
        <div className="rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5">
          <p className="text-xs uppercase tracking-wide text-purple-300/45">
            Contratos considerados
          </p>
          <p className="mt-2 text-2xl font-bold text-white">{current.length}</p>
        </div>
      </div>

      <div className="mt-8 space-y-3">
        <h2 className="text-sm font-semibold text-white">
          Mensalidades contratadas
        </h2>
        {current.map((contract) => (
          <article
            key={contract.id}
            className="flex flex-col justify-between gap-4 rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5 sm:flex-row sm:items-center"
          >
            <div>
              <p className="font-semibold text-white">{contract.route}</p>
              <p className="mt-1 text-sm text-purple-300/50">
                Prestador: {contract.provider}
              </p>
            </div>
            <div className="text-left sm:text-right">
              <p className="text-lg font-bold text-white">
                {formatCurrency(contract.value)}
              </p>
              <span
                className={`mt-1 inline-block rounded-full px-2.5 py-1 text-xs font-medium ${
                  contract.status === "pending"
                    ? "bg-amber-500/10 text-amber-300"
                    : "bg-green-500/10 text-green-300"
                }`}
              >
                {contract.status === "pending"
                  ? "Pagamento pendente"
                  : "Contrato ativo"}
              </span>
            </div>
          </article>
        ))}
        {!current.length && (
          <div className="rounded-2xl border border-dashed border-purple-500/20 py-12 text-center text-sm text-purple-300/45">
            Nenhuma mensalidade empresarial disponível.
          </div>
        )}
      </div>
    </section>
  )
}
