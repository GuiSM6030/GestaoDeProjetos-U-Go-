import { EDGE_FUNCTION_URL, supabase } from "../../../lib/supabase"
import type { CardOrderInput, PaymentCharge } from "../types"

interface ChargeRow {
  id: string
  membership_id: string
  route_name?: string
  driver_name?: string
  reference_month: string
  due_date: string
  amount: number | string
  status: PaymentCharge["status"]
  payment_method?: PaymentCharge["paymentMethod"] | null
  provider_status?: string | null
  provider_status_detail?: string | null
  pix_qr_code?: string | null
  pix_qr_code_base64?: string | null
  pix_ticket_url?: string | null
  expires_at?: string | null
  paid_at?: string | null
  refunded_at?: string | null
  last_error?: string | null
}

class PaymentRequestError extends Error {
  suggestion?: string

  constructor(message: string, suggestion?: string) {
    super(message)
    this.name = "PaymentRequestError"
    this.suggestion = suggestion
  }
}

const toCharge = (row: ChargeRow): PaymentCharge => ({
  id: row.id,
  membershipId: row.membership_id,
  routeName: row.route_name ?? "Rota",
  driverName: row.driver_name ?? "Motorista",
  referenceMonth: row.reference_month,
  dueDate: row.due_date,
  amount: Number(row.amount),
  status: row.status,
  paymentMethod: row.payment_method ?? undefined,
  providerStatus: row.provider_status ?? undefined,
  providerStatusDetail: row.provider_status_detail ?? undefined,
  pixQrCode: row.pix_qr_code ?? undefined,
  pixQrCodeBase64: row.pix_qr_code_base64 ?? undefined,
  pixTicketUrl: row.pix_ticket_url ?? undefined,
  expiresAt: row.expires_at ?? undefined,
  paidAt: row.paid_at ?? undefined,
  refundedAt: row.refunded_at ?? undefined,
  lastError: row.last_error ?? undefined,
})

async function request(path: string, init?: RequestInit) {
  const { data } = await supabase.auth.getSession()
  const token = data.session?.access_token
  if (!token) throw new PaymentRequestError("Sessão não encontrada.")
  const response = await fetch(`${EDGE_FUNCTION_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(init?.headers ?? {}),
    },
  })
  const payload = await response.json().catch(() => ({}))
  if (!response.ok) {
    throw new PaymentRequestError(
      payload.error ?? "Não foi possível processar o pagamento.",
      payload.suggestion,
    )
  }
  return payload
}

export const paymentService = {
  async getConfig(): Promise<{ publicKey: string }> {
    return request("/payments/config")
  },

  async listCharges(): Promise<PaymentCharge[]> {
    const payload = await request("/payments/charges")
    return (payload.charges as ChargeRow[]).map(toCharge)
  },

  async payWithPix(chargeId: string): Promise<PaymentCharge> {
    const payload = await request("/payments/orders", {
      method: "POST",
      body: JSON.stringify({ chargeId, method: "pix" }),
    })
    return toCharge(payload.charge)
  },

  async payWithCard(
    chargeId: string,
    card: CardOrderInput,
  ): Promise<PaymentCharge> {
    const payload = await request("/payments/orders", {
      method: "POST",
      body: JSON.stringify({ chargeId, method: "credit_card", card }),
    })
    return toCharge(payload.charge)
  },

  async sync(chargeId: string): Promise<PaymentCharge> {
    const payload = await request(`/payments/charges/${chargeId}/sync`, {
      method: "POST",
    })
    return toCharge(payload.charge)
  },
}

export { PaymentRequestError }
