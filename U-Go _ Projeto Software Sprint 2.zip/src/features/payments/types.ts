export type ChargeStatus = "pending" | "paid" | "refunded"

export interface PaymentCharge {
  id: string
  membershipId: string
  routeName: string
  driverName: string
  referenceMonth: string
  dueDate: string
  amount: number
  status: ChargeStatus
  paymentMethod?: "pix" | "credit_card"
  providerStatus?: string
  providerStatusDetail?: string
  pixQrCode?: string
  pixQrCodeBase64?: string
  pixTicketUrl?: string
  expiresAt?: string
  paidAt?: string
  refundedAt?: string
  lastError?: string
}

export interface CardOrderInput {
  token: string
  paymentMethodId: string
  paymentTypeId: string
  installments: number
  identification?: {
    type?: string
    number?: string
  }
}
