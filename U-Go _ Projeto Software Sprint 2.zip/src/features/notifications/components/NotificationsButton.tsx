import { useEffect, useState } from "react"
import { supabase } from "../../../lib/supabase"
import { jsonApi } from "../../../lib/jsonRestApi"

interface NotificationRow {
  id: string
  title: string
  message: string
  read_at: string | null
  created_at: string
}

export default function NotificationsButton() {
  const [items, setItems] = useState<NotificationRow[]>([])
  const [open, setOpen] = useState(false)

  const load = async () => {
    const { data } = await jsonApi
      .from("app_notifications")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(10)
    if (data) setItems(data as NotificationRow[])
  }

  useEffect(() => {
    void load()
    const timer = window.setInterval(() => void load(), 30000)
    return () => window.clearInterval(timer)
  }, [])

  const unread = items.filter((item) => !item.read_at).length

  const markAsRead = async () => {
    const unreadIds = items
      .filter((item) => !item.read_at)
      .map((item) => item.id)
    if (unreadIds.length === 0) return
    const readAt = new Date().toISOString()
    const { error } = await jsonApi
      .from("app_notifications")
      .update({ read_at: readAt })
      .in("id", unreadIds)
    if (!error) {
      setItems((current) =>
        current.map((item) =>
          unreadIds.includes(item.id) ? { ...item, read_at: readAt } : item,
        ),
      )
    }
  }

  return (
    <div className="relative mb-2">
      <button
        type="button"
        onClick={() => {
          const next = !open
          setOpen(next)
          if (next) void markAsRead()
        }}
        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-purple-300/55 transition-colors hover:bg-white/5 hover:text-purple-100"
        aria-expanded={open}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          className="h-4 w-4"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022 23.848 23.848 0 0 0 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0"
          />
        </svg>
        Notificações
        {unread > 0 && (
          <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-purple-600 px-1 text-[10px] font-bold text-white">
            {unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute bottom-full left-0 z-40 mb-2 w-80 overflow-hidden rounded-2xl border border-purple-500/20 bg-[#170b2d] shadow-2xl">
          <div className="border-b border-purple-500/15 px-4 py-3">
            <p className="text-sm font-semibold text-white">Notificações</p>
          </div>
          <div className="max-h-72 overflow-y-auto">
            {items.map((item) => (
              <div
                key={item.id}
                className="border-b border-purple-500/10 px-4 py-3 last:border-b-0"
              >
                <p className="text-sm font-medium text-purple-100">
                  {item.title}
                </p>
                <p className="mt-1 text-xs leading-relaxed text-purple-300/55">
                  {item.message}
                </p>
                <p className="mt-1.5 text-[10px] text-purple-300/30">
                  {new Intl.DateTimeFormat("pt-BR", {
                    dateStyle: "short",
                    timeStyle: "short",
                  }).format(new Date(item.created_at))}
                </p>
              </div>
            ))}
            {items.length === 0 && (
              <p className="px-4 py-8 text-center text-xs text-purple-300/40">
                Nenhuma notificação.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
