import { useCallback, useEffect, useRef, useState } from "react"
import { BrowserQRCodeReader } from "@zxing/browser"
import {
  attendanceService,
  parseAccessCode,
  type ValidationResult,
} from "../services/attendanceService"

export function DriverQrScanner() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const controlsRef = useRef<{ stop: () => void } | null>(null)
  const processingRef = useRef(false)
  const [manualCode, setManualCode] = useState("")
  const [cameraActive, setCameraActive] = useState(false)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ValidationResult | null>(null)
  const [error, setError] = useState("")
  const [pendingCount, setPendingCount] = useState(
    attendanceService.getQueue().length,
  )

  const validate = useCallback(async (rawCode: string) => {
    const accessCode = parseAccessCode(rawCode)
    if (!accessCode) {
      setResult(null)
      setError("QR Code inválido. Confira o código e tente novamente.")
      return
    }
    if (processingRef.current) return
    processingRef.current = true
    setLoading(true)
    setError("")
    try {
      setResult(await attendanceService.validateAccessCode(accessCode))
      setPendingCount(attendanceService.getQueue().length)
    } catch (validationError) {
      setResult(null)
      setError(
        validationError instanceof Error
          ? validationError.message
          : "Não foi possível validar o QR Code.",
      )
    } finally {
      setLoading(false)
      window.setTimeout(() => {
        processingRef.current = false
      }, 1500)
    }
  }, [])

  const stopCamera = useCallback(() => {
    controlsRef.current?.stop()
    controlsRef.current = null
    setCameraActive(false)
  }, [])

  const startCamera = useCallback(async () => {
    if (!videoRef.current) return
    setError("")
    try {
      const reader = new BrowserQRCodeReader()
      controlsRef.current = await reader.decodeFromVideoDevice(
        undefined,
        videoRef.current,
        (scanResult) => {
          if (scanResult) void validate(scanResult.getText())
        },
      )
      setCameraActive(true)
    } catch {
      setError(
        "Não foi possível acessar a câmera. Use a digitação manual abaixo.",
      )
    }
  }, [validate])

  useEffect(() => {
    const refresh = async () => {
      try {
        await attendanceService.syncOfflineAttendance()
        await attendanceService.loadDriverRoster()
        setPendingCount(attendanceService.getQueue().length)
      } catch {
        setError("A sincronização automática será tentada novamente.")
      }
    }
    if (navigator.onLine) void refresh()
    window.addEventListener("online", refresh)
    return () => {
      window.removeEventListener("online", refresh)
      controlsRef.current?.stop()
    }
  }, [])

  return (
    <section>
      <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <p className="mb-1 text-sm text-purple-300/50">
            Controle de embarque
          </p>
          <h1 className="text-3xl font-bold text-white">Validar QR Code</h1>
          <p className="mt-2 text-sm text-purple-200/55">
            Aponte a câmera para o código apresentado pelo universitário.
          </p>
        </div>
        <div className="rounded-xl border border-purple-500/15 bg-white/[0.03] px-4 py-2 text-xs text-purple-200/60">
          {pendingCount
            ? `${pendingCount} evento(s) aguardando sincronização`
            : navigator.onLine
              ? "Roster atualizado para uso offline"
              : "Modo offline"}
        </div>
      </div>

      <div className="grid max-w-4xl gap-5 lg:grid-cols-[1.3fr_1fr]">
        <div className="overflow-hidden rounded-2xl border border-purple-500/20 bg-black">
          <video
            ref={videoRef}
            muted
            playsInline
            className="aspect-video w-full object-cover"
          />
          <div className="flex justify-center border-t border-purple-500/15 bg-[#0d0520] p-3">
            <button
              type="button"
              onClick={cameraActive ? stopCamera : startCamera}
              className="rounded-xl bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-purple-500"
            >
              {cameraActive ? "Desligar câmera" : "Iniciar câmera"}
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <form
            onSubmit={(event) => {
              event.preventDefault()
              void validate(manualCode)
            }}
            className="rounded-2xl border border-purple-500/15 bg-white/[0.03] p-5"
          >
            <label>
              <span className="mb-2 block text-xs font-medium text-purple-200/70">
                Código manual
              </span>
              <input
                value={manualCode}
                onChange={(event) => setManualCode(event.target.value)}
                inputMode="numeric"
                placeholder="Digite os 10 números"
                className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-3 text-sm text-white placeholder-purple-300/25"
              />
            </label>
            <button
              type="submit"
              disabled={loading}
              className="mt-3 w-full rounded-xl border border-purple-500/30 px-4 py-2.5 text-sm font-semibold text-purple-100 hover:bg-purple-500/10 disabled:opacity-50"
            >
              {loading ? "Validando..." : "Validar código"}
            </button>
          </form>

          {result && (
            <div
              role="status"
              className={`rounded-2xl border p-5 ${
                result.authorized
                  ? "border-emerald-400/30 bg-emerald-500/10"
                  : "border-red-400/30 bg-red-500/10"
              }`}
            >
              <p
                className={`text-lg font-bold ${
                  result.authorized ? "text-emerald-300" : "text-red-300"
                }`}
              >
                {result.message}
              </p>
              {result.studentName && (
                <p className="mt-2 text-sm text-white">{result.studentName}</p>
              )}
              {result.offline && (
                <p className="mt-2 text-xs text-purple-200/55">
                  Validação offline salva para sincronização.
                </p>
              )}
            </div>
          )}
          {error && (
            <p
              role="alert"
              className="rounded-xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 text-sm text-amber-200"
            >
              {error}
            </p>
          )}
        </div>
      </div>
    </section>
  )
}
