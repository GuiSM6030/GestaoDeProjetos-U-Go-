import { useEffect, useState } from "react"
import QRCode from "qrcode"
import type { Contract } from "../../../types"
import { jsonApi } from "../../../lib/jsonRestApi"

interface BoardingTokenRow {
  membership_id: string
  boarding_token: string
}

interface ManualCodeRow {
  membership_id: string
  manual_code: string
}

export function StudentQrCard({ contracts }: { contracts: Contract[] }) {
  const [selectedId, setSelectedId] = useState("")
  const [qrUrl, setQrUrl] = useState("")
  const [tokens, setTokens] = useState<Record<string, string>>({})
  const [manualCodes, setManualCodes] = useState<Record<string, string>>({})
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(true)
  const activeContracts = contracts.filter(
    (contract) => contract.status === "active",
  )
  const selected =
    activeContracts.find((contract) => contract.id === selectedId) ??
    activeContracts[0]
  const selectedToken = selected ? tokens[selected.id] : undefined

  useEffect(() => {
    let active = true
    const loadTokens = async () => {
      try {
        const [tokenResult, manualCodeResult] = await Promise.all([
          jsonApi.rpc("get_student_boarding_tokens"),
          jsonApi.rpc("get_student_boarding_manual_codes"),
        ])
        const { data, error: tokenError } = tokenResult
        if (tokenError) throw tokenError
        if (manualCodeResult.error) throw manualCodeResult.error
        if (!active) return
        setTokens(
          Object.fromEntries(
            ((data ?? []) as BoardingTokenRow[]).map((row) => [
              row.membership_id,
              row.boarding_token,
            ]),
          ),
        )
        setManualCodes(
          Object.fromEntries(
            ((manualCodeResult.data ?? []) as ManualCodeRow[]).map((row) => [
              row.membership_id,
              row.manual_code,
            ]),
          ),
        )
      } catch (tokenError) {
        if (active) {
          const message =
            typeof tokenError === "object" &&
            tokenError &&
            "message" in tokenError
              ? String(tokenError.message)
              : ""
          setError(
            /get_student_boarding_(tokens|manual_codes)|schema cache|PGRST202/i.test(
              message,
            )
              ? "O serviço de QR Code seguro ainda não foi atualizado. Contate o suporte."
              : message || "Não foi possível gerar o QR Code seguro.",
          )
        }
      } finally {
        if (active) setLoading(false)
      }
    }
    void loadTokens()
    return () => {
      active = false
    }
  }, [])

  useEffect(() => {
    if (!selectedToken) {
      setQrUrl("")
      return
    }
    QRCode.toDataURL(`ugo:${selectedToken}`, {
      width: 320,
      margin: 2,
      color: { dark: "#1a0840", light: "#ffffff" },
    }).then(setQrUrl)
  }, [selectedToken])

  return (
    <section>
      <p className="mb-1 text-sm text-purple-300/50">
        Identificação de embarque
      </p>
      <h1 className="mb-2 text-3xl font-bold text-white">Meu QR Code</h1>
      <p className="mb-6 max-w-2xl text-sm text-purple-200/55">
        Apresente este código ao motorista. Ele representa apenas seu contrato
        de transporte atual e não contém dados pessoais.
      </p>

      {error ? (
        <p className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
          {error}
        </p>
      ) : !activeContracts.length ? (
        <div className="rounded-2xl border border-dashed border-purple-500/25 bg-white/[0.03] px-6 py-14 text-center">
          <p className="font-medium text-white">Nenhum contrato ativo</p>
          <p className="mt-2 text-sm text-purple-300/50">
            Seu QR Code ficará disponível quando um contrato estiver ativo.
          </p>
        </div>
      ) : (
        <div className="grid max-w-3xl gap-5 rounded-2xl border border-purple-500/15 bg-white/[0.03] p-6 md:grid-cols-[1fr_260px]">
          <div>
            <label>
              <span className="mb-2 block text-xs font-medium text-purple-200/70">
                Contrato de transporte
              </span>
              <select
                value={selected?.id}
                onChange={(event) => setSelectedId(event.target.value)}
                className="w-full rounded-xl border border-purple-500/25 bg-[#1a0840] px-3 py-3 text-sm text-white"
              >
                {activeContracts.map((contract) => (
                  <option key={contract.id} value={contract.id}>
                    {contract.route}
                  </option>
                ))}
              </select>
            </label>
            <div className="mt-5 rounded-xl border border-purple-500/15 bg-purple-500/5 p-4">
              <p className="text-xs uppercase tracking-wide text-purple-300/45">
                Rota vinculada
              </p>
              <p className="mt-1 font-semibold text-white">{selected?.route}</p>
              <p className="mt-1 text-sm text-purple-300/50">
                Motorista: {selected?.provider}
              </p>
            </div>
            {selected && manualCodes[selected.id] && (
              <div className="mt-4 rounded-xl border border-purple-500/20 bg-black/15 p-4">
                <p className="text-xs uppercase tracking-wide text-purple-300/45">
                  Código para digitação manual
                </p>
                <div className="mt-2 flex items-center gap-3">
                  <code className="text-xl font-bold tracking-[0.18em] text-white">
                    {manualCodes[selected.id]}
                  </code>
                  <button
                    type="button"
                    onClick={() => {
                      void navigator.clipboard.writeText(
                        manualCodes[selected.id],
                      )
                      setCopied(true)
                      window.setTimeout(() => setCopied(false), 2_000)
                    }}
                    className="rounded-lg border border-purple-500/25 px-2.5 py-1.5 text-xs font-medium text-purple-200 hover:bg-purple-500/10"
                  >
                    {copied ? "Copiado" : "Copiar"}
                  </button>
                </div>
                <p className="mt-2 text-xs text-purple-300/45">
                  Informe estes 10 números ao motorista caso a câmera não esteja
                  disponível.
                </p>
              </div>
            )}
          </div>
          <div className="flex items-center justify-center rounded-2xl bg-white p-4">
            {qrUrl ? (
              <img
                src={qrUrl}
                alt={`QR Code do contrato da rota ${selected?.route}`}
                className="w-full max-w-56"
              />
            ) : loading ? (
              <p className="py-16 text-sm text-purple-900/55">
                Gerando token seguro...
              </p>
            ) : (
              <p className="py-16 text-center text-sm text-red-700/70">
                Token seguro indisponível para este contrato.
              </p>
            )}
          </div>
        </div>
      )}
    </section>
  )
}
