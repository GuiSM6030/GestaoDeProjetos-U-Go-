import { useEffect, useState } from "react"
import QRCode from "qrcode"
import { supabase } from "../../../lib/supabase"
import { jsonApi } from "../../../lib/jsonRestApi"

interface CollaboratorAccess {
  name: string
  status: "active" | "inactive"
  access_code: string
}

export function CollaboratorQrCard() {
  const [access, setAccess] = useState<CollaboratorAccess | null>(null)
  const [qrUrl, setQrUrl] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    let active = true
    supabase.auth
      .getUser()
      .then(({ data }) => {
        if (!data.user) throw new Error("Colaborador não autenticado.")
        return jsonApi
          .from("company_collaborators")
          .select("name,status,access_code")
          .eq("auth_user_id", data.user.id)
          .single()
      })
      .then(({ data, error: queryError }) => {
        if (queryError) throw queryError
        if (active) setAccess(data as CollaboratorAccess)
      })
      .catch((loadError) => {
        if (active)
          setError(
            loadError instanceof Error
              ? loadError.message
              : "Não foi possível carregar seu QR Code.",
          )
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  useEffect(() => {
    if (!access?.access_code || access.status !== "active") {
      setQrUrl("")
      return
    }
    QRCode.toDataURL(`ugo:${access.access_code}`, {
      width: 320,
      margin: 2,
      color: { dark: "#1a0840", light: "#ffffff" },
    }).then(setQrUrl)
  }, [access])

  return (
    <section>
      <p className="mb-1 text-sm text-purple-300/50">
        Identificação de transporte corporativo
      </p>
      <h1 className="mb-2 text-3xl font-bold text-white">Meu QR Code</h1>
      <p className="mb-6 max-w-2xl text-sm text-purple-200/55">
        Apresente este código ao motorista para validar seu embarque. Os
        pagamentos do transporte são administrados exclusivamente pela sua
        empresa.
      </p>

      {loading ? (
        <div className="py-16 text-center text-purple-300/45">
          Carregando QR Code...
        </div>
      ) : error ? (
        <p className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
          {error}
        </p>
      ) : access?.status !== "active" ? (
        <div className="rounded-2xl border border-dashed border-purple-500/25 bg-white/[0.03] px-6 py-14 text-center">
          <p className="font-medium text-white">Acesso indisponível</p>
          <p className="mt-2 text-sm text-purple-300/50">
            Procure sua empresa para reativar seu cadastro.
          </p>
        </div>
      ) : (
        <div className="grid max-w-3xl gap-5 rounded-2xl border border-purple-500/15 bg-white/[0.03] p-6 md:grid-cols-[1fr_260px]">
          <div className="flex flex-col justify-center">
            <p className="text-xs uppercase tracking-wide text-purple-300/45">
              Colaborador
            </p>
            <p className="mt-1 text-xl font-semibold text-white">
              {access?.name}
            </p>
            <div className="mt-5 rounded-xl border border-purple-500/15 bg-purple-500/5 p-4 text-sm text-purple-200/60">
              Este código é pessoal e deve ser usado somente para embarque no
              transporte contratado pela empresa.
            </div>
          </div>
          <div className="flex items-center justify-center rounded-2xl bg-white p-4">
            {qrUrl && (
              <img
                src={qrUrl}
                alt="QR Code de embarque do colaborador"
                className="w-full max-w-56"
              />
            )}
          </div>
        </div>
      )}
    </section>
  )
}
