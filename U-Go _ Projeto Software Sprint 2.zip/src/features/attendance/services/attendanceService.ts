import { jsonApi } from "../../../lib/jsonRestApi"

const ROSTER_KEY = "ugo:driver-attendance-roster"
const QUEUE_KEY = "ugo:offline-attendance-queue"

export const AUTHORIZED_MESSAGE = "Embarque Autorizado"
export const DENIED_MESSAGE = "Embarque Não Autorizado: Pagamento Pendente"

export interface RosterEntry {
  accessCode: string
  membershipId: string
  routeId: string
  routeName: string
  studentId: string
  studentName: string
  membershipStatus: string
  authorized: boolean
  denialReason?: string
}

export interface AttendanceEvent {
  accessCode: string
  clientEventId: string
  scannedAt: string
}

export interface ValidationResult {
  authorized: boolean
  message: string
  membershipId?: string
  studentName?: string
  reason?: string
  offline?: boolean
}

interface RosterRow {
  access_code: string
  membership_id: string
  route_id: string
  route_name: string
  student_id: string
  student_name: string
  membership_status: string
  authorized: boolean
  denial_reason?: string | null
}

const readStored = <T>(key: string, fallback: T): T => {
  try {
    const value = localStorage.getItem(key)
    return value ? JSON.parse(value) as T : fallback
  } catch {
    return fallback
  }
}

const writeStored = (key: string, value: unknown) =>
  localStorage.setItem(key, JSON.stringify(value))

export const parseAccessCode = (value: string) => {
  const code = value.trim().replace(/^ugo:/i, "")
  const uuid =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
  const signedToken = /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/
  const manualCode = /^\d{10}$/
  return uuid.test(code) || signedToken.test(code) || manualCode.test(code)
    ? code
    : null
}

const createEventId = () =>
  crypto.randomUUID?.() ??
  "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (character) => {
    const random = (Math.random() * 16) | 0
    return (character === "x" ? random : (random & 0x3) | 0x8).toString(16)
  })

export const attendanceService = {
  getCachedRoster: () => readStored<RosterEntry[]>(ROSTER_KEY, []),

  getQueue: () => readStored<AttendanceEvent[]>(QUEUE_KEY, []),

  async loadDriverRoster() {
    const { data, error } = await jsonApi.rpc("get_driver_attendance_roster")
    if (error) throw error
    const roster = ((data ?? []) as RosterRow[]).map((row) => ({
      accessCode: row.access_code,
      membershipId: row.membership_id,
      routeId: row.route_id,
      routeName: row.route_name,
      studentId: row.student_id,
      studentName: row.student_name,
      membershipStatus: row.membership_status,
      authorized: row.authorized,
      denialReason: row.denial_reason ?? undefined,
    }))
    writeStored(ROSTER_KEY, roster)
    return roster
  },

  async validateAccessCode(accessCode: string): Promise<ValidationResult> {
    const event: AttendanceEvent = {
      accessCode,
      clientEventId: createEventId(),
      scannedAt: new Date().toISOString(),
    }

    if (!navigator.onLine) {
      const entry = this.getCachedRoster().find(
        (item) => item.accessCode.toLowerCase() === accessCode.toLowerCase(),
      )
      const queue = this.getQueue()
      writeStored(QUEUE_KEY, [...queue, event])
      if (!entry) {
        return {
          authorized: false,
          message: "QR Code não encontrado no roster armazenado",
          reason: "invalid_code",
          offline: true,
        }
      }
      return {
        authorized: entry.authorized,
        message: entry.authorized ? AUTHORIZED_MESSAGE : DENIED_MESSAGE,
        membershipId: entry.membershipId,
        studentName: entry.studentName,
        reason: entry.denialReason,
        offline: true,
      }
    }

    const { data, error } = await jsonApi.rpc("validate_route_access_code", {
      p_access_code: accessCode,
      p_client_event_id: event.clientEventId,
      p_scanned_at: event.scannedAt,
      p_recorded_offline: false,
    })
    if (error) throw error
    const result = data as ValidationResult
    if (
      result.reason !== "invalid_code" ||
      accessCode.includes(".") ||
      /^\d{10}$/.test(accessCode)
    )
      return result

    const { data: collaboratorData, error: collaboratorError } =
      await jsonApi.rpc("validate_collaborator_access_code", {
        p_access_code: accessCode,
        p_client_event_id: event.clientEventId,
        p_scanned_at: event.scannedAt,
      })
    if (collaboratorError) throw collaboratorError
    return collaboratorData as ValidationResult
  },

  async syncOfflineAttendance() {
    const events = this.getQueue()
    if (!events.length || !navigator.onLine) return []
    const { data, error } = await jsonApi.rpc("sync_offline_attendance", {
      p_events: events,
    })
    if (error) throw error
    const results = (data ?? []) as Array<ValidationResult & {
      clientEventId: string
    }>
    const confirmed = new Set(results.map((item) => item.clientEventId))
    writeStored(
      QUEUE_KEY,
      events.filter((event) => !confirmed.has(event.clientEventId)),
    )
    return results
  },
}
