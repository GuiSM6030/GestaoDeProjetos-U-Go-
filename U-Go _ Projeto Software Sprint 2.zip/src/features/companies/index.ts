export { companyDataService } from "./services/companyDataService"
export type {
  CollaboratorInput,
  CompanyRouteInput,
} from "./services/companyDataService"
