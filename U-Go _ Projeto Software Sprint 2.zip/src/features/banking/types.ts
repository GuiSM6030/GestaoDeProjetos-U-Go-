export type BankAccountType = "checking" | "savings"
export type PixKeyType = "cpf" | "email" | "phone" | "random"

export interface DriverBankAccount {
  bankName: string
  agency: string
  accountNumber: string
  accountType: BankAccountType
  pixKeyType: PixKeyType
  pixKey: string
  holderName: string
  holderCpf: string
  enabledForPayouts: boolean
  verifiedAt: string
}

export interface DriverBankAccountInput {
  bankName: string
  agency: string
  accountNumber: string
  accountType: BankAccountType
  pixKeyType: PixKeyType
  pixKey: string
  holderName: string
  holderCpf: string
}
