import { useEffect, useState } from "react"
import { bankAccountService } from "../services/bankAccountService"
import type { BankAccountType, DriverBankAccount, PixKeyType } from "../types"

interface Props {
  profile: {
    full_name?: string
    cpf?: string
  }
}

export default function BankAccountPanel({ profile }: Props) {
  const [account, setAccount] = useState<DriverBankAccount | null>(null)
  const [form, setForm] = useState({
    bankName: "",
    agency: "",
    accountNumber: "",
    accountType: "checking" as BankAccountType,
    pixKeyType: "cpf" as PixKeyType,
    pixKey: "",
    holderName: profile.full_name ?? "",
    holderCpf: profile.cpf ?? "",
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [message, setMessage] = useState("")

  useEffect(() => {
    bankAccountService
      .get()
      .then(setAccount)
      .catch((loadError) =>
        setError(
          loadError instanceof Error
            ? loadError.message
            : "Não foi possível carregar os dados bancários.",
        ),
      )
      .finally(() => setLoading(false))
  }, [])

  const field =
    (name: keyof typeof form) =>
    (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm((current) => ({ ...current, [name]: event.target.value }))
      setError("")
      setMessage("")
    }

  const save = async (event: React.FormEvent) => {
    event.preventDefault()
    setSaving(true)
    setError("")
    setMessage("")
    try {
      const result = await bankAccountService.save(form)
      setAccount(result.account)
      setMessage(result.message)
      setForm((current) => ({
        ...current,
        agency: "",
        accountNumber: "",
        pixKey: "",
      }))
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : "Não foi possível salvar os dados bancários.",
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <section className="mx-auto max-w-3xl">
      <div className="mb-6">
        <p className="mb-1 text-sm text-purple-300/50">
          Recebimento das mensalidades
        </p>
        <h1 className="text-2xl font-bold text-white">Dados bancários</h1>
      </div>

      {loading ? (
        <div className="py-16 text-center text-purple-300/45">
          Carregando dados bancários...
        </div>
      ) : (
        <div className="space-y-5">
          {account && (
            <div className="rounded-2xl border border-green-500/20 bg-green-500/10 p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-green-200">
                    Recebimento de repasses habilitado
                  </p>
                  <p className="mt-1 text-xs text-green-100/55">
                    Dados verificados em{" "}
                    {new Intl.DateTimeFormat("pt-BR", {
                      dateStyle: "short",
                      timeStyle: "short",
                    }).format(new Date(account.verifiedAt))}
                  </p>
                </div>
                <span className="rounded-full bg-green-500/15 px-2.5 py-1 text-xs font-medium text-green-200">
                  Ativo
                </span>
              </div>
              <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                <p className="text-purple-100/70">
                  Banco:{" "}
                  <strong className="text-white">{account.bankName}</strong>
                </p>
                <p className="text-purple-100/70">
                  Agência:{" "}
                  <strong className="text-white">{account.agency}</strong>
                </p>
                <p className="text-purple-100/70">
                  Conta:{" "}
                  <strong className="text-white">
                    {account.accountNumber}
                  </strong>
                </p>
                <p className="text-purple-100/70">
                  Chave Pix:{" "}
                  <strong className="text-white">{account.pixKey}</strong>
                </p>
              </div>
            </div>
          )}

          <form
            onSubmit={save}
            className="space-y-5 rounded-2xl border border-purple-500/15 bg-white/[0.03] p-6"
          >
            <div>
              <h2 className="text-lg font-semibold text-white">
                {account ? "Atualizar dados" : "Cadastrar conta para repasse"}
              </h2>
              <p className="mt-1 text-sm text-purple-200/50">
                Por segurança, os dados completos não são exibidos após o
                salvamento. Para atualizar, informe todos novamente.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className="mb-1 block text-xs font-medium text-purple-200/70">
                  Banco
                </span>
                <input
                  value={form.bankName}
                  onChange={field("bankName")}
                  placeholder="Nome ou código do banco"
                  required
                  className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                />
              </label>
              <label>
                <span className="mb-1 block text-xs font-medium text-purple-200/70">
                  Agência
                </span>
                <input
                  value={form.agency}
                  onChange={field("agency")}
                  placeholder="0001"
                  required
                  className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                />
              </label>
              <label>
                <span className="mb-1 block text-xs font-medium text-purple-200/70">
                  Conta com dígito
                </span>
                <input
                  value={form.accountNumber}
                  onChange={field("accountNumber")}
                  placeholder="12345-6"
                  required
                  className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                />
              </label>
              <label>
                <span className="mb-1 block text-xs font-medium text-purple-200/70">
                  Tipo de conta
                </span>
                <select
                  value={form.accountType}
                  onChange={field("accountType")}
                  className="w-full rounded-xl border border-purple-500/25 bg-[#170b2d] px-3 py-2.5 text-sm text-white focus:border-purple-500"
                >
                  <option value="checking">Conta corrente</option>
                  <option value="savings">Conta poupança</option>
                </select>
              </label>
              <label>
                <span className="mb-1 block text-xs font-medium text-purple-200/70">
                  Tipo de chave Pix
                </span>
                <select
                  value={form.pixKeyType}
                  onChange={field("pixKeyType")}
                  className="w-full rounded-xl border border-purple-500/25 bg-[#170b2d] px-3 py-2.5 text-sm text-white focus:border-purple-500"
                >
                  <option value="cpf">CPF</option>
                  <option value="email">E-mail</option>
                  <option value="phone">Telefone</option>
                  <option value="random">Chave aleatória</option>
                </select>
              </label>
              <label className="sm:col-span-2">
                <span className="mb-1 block text-xs font-medium text-purple-200/70">
                  Chave Pix
                </span>
                <input
                  value={form.pixKey}
                  onChange={field("pixKey")}
                  placeholder="Informe a chave correspondente ao tipo"
                  required
                  className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                />
              </label>
            </div>

            <div className="border-t border-purple-500/15 pt-5">
              <h3 className="mb-3 text-sm font-semibold text-white">
                Titular da conta
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <label>
                  <span className="mb-1 block text-xs font-medium text-purple-200/70">
                    Nome completo
                  </span>
                  <input
                    value={form.holderName}
                    onChange={field("holderName")}
                    required
                    className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white focus:border-purple-500"
                  />
                </label>
                <label>
                  <span className="mb-1 block text-xs font-medium text-purple-200/70">
                    CPF do titular
                  </span>
                  <input
                    value={form.holderCpf}
                    onChange={field("holderCpf")}
                    placeholder="000.000.000-00"
                    required
                    className="w-full rounded-xl border border-purple-500/25 bg-white/5 px-3 py-2.5 text-sm text-white placeholder-purple-300/30 focus:border-purple-500"
                  />
                </label>
              </div>
              <p className="mt-3 text-xs text-purple-300/45">
                O CPF do titular deve ser o mesmo CPF cadastrado no perfil do
                motorista.
              </p>
            </div>

            {error && (
              <p
                className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200"
                role="alert"
              >
                {error}
              </p>
            )}
            {message && (
              <p
                className="rounded-xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-200"
                role="status"
              >
                {message}
              </p>
            )}

            <button
              type="submit"
              disabled={saving}
              className="w-full rounded-xl bg-purple-600 px-5 py-3 text-sm font-semibold text-white hover:bg-purple-500 disabled:opacity-50"
            >
              {saving ? "Salvando..." : "Salvar dados bancários"}
            </button>
          </form>
        </div>
      )}
    </section>
  )
}
