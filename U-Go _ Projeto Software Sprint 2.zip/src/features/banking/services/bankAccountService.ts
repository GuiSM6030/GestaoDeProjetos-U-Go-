import { EDGE_FUNCTION_URL, supabase } from "../../../lib/supabase"
import type { DriverBankAccount, DriverBankAccountInput } from "../types"

async function request(path: string, init?: RequestInit) {
  const { data } = await supabase.auth.getSession()
  const token = data.session?.access_token
  if (!token) throw new Error("Sessão do motorista não encontrada.")
  const response = await fetch(`${EDGE_FUNCTION_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(init?.headers ?? {}),
    },
  })
  const payload = await response.json().catch(() => ({}))
  if (!response.ok) {
    throw new Error(payload.error ?? "Não foi possível salvar os dados.")
  }
  return payload
}

export const bankAccountService = {
  async get(): Promise<DriverBankAccount | null> {
    const payload = await request("/driver/bank-account")
    return payload.account
  },

  async save(input: DriverBankAccountInput): Promise<{
    account: DriverBankAccount
    message: string
  }> {
    return request("/driver/bank-account", {
      method: "PUT",
      body: JSON.stringify(input),
    })
  },
}
