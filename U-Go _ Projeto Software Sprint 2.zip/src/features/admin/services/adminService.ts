import { EDGE_FUNCTION_URL, supabase } from "../../../lib/supabase"

export type DriverApplicationStatus = "pending" | "approved" | "rejected"

export interface DriverApplication {
  userId: string
  email: string
  fullName: string
  cpf: string
  cnh: string
  plate: string
  vehicle: string
  seats: number
  status: DriverApplicationStatus
  rejectionReason?: string
  reviewedAt?: string
  createdAt: string
}

interface DriverApplicationRow {
  user_id: string
  email: string
  full_name: string
  cpf: string
  cnh: string
  plate: string
  vehicle: string
  seats: number
  status: DriverApplicationStatus
  rejection_reason: string | null
  reviewed_at: string | null
  created_at: string
}

async function authorizationHeader() {
  const { data, error } = await supabase.auth.getSession()
  if (error || !data.session) {
    throw new Error("Sessão administrativa expirada.")
  }
  return { Authorization: `Bearer ${data.session.access_token}` }
}

async function responseData(response: Response) {
  const body = await response.json().catch(() => ({}))
  if (!response.ok) {
    throw new Error(body.error ?? "Não foi possível concluir a operação.")
  }
  return body
}

const toApplication = (row: DriverApplicationRow): DriverApplication => ({
  userId: row.user_id,
  email: row.email,
  fullName: row.full_name,
  cpf: row.cpf,
  cnh: row.cnh,
  plate: row.plate,
  vehicle: row.vehicle,
  seats: row.seats,
  status: row.status,
  rejectionReason: row.rejection_reason ?? undefined,
  reviewedAt: row.reviewed_at ?? undefined,
  createdAt: row.created_at,
})

export const adminService = {
  async listDriverApplications() {
    const response = await fetch(
      `${EDGE_FUNCTION_URL}/admin/driver-applications`,
      { headers: await authorizationHeader() },
    )
    const body = await responseData(response)
    return (body.applications as DriverApplicationRow[]).map(toApplication)
  },

  async reviewDriverApplication(
    userId: string,
    status: "approved" | "rejected",
    rejectionReason = "",
  ) {
    const response = await fetch(
      `${EDGE_FUNCTION_URL}/admin/driver-applications/${userId}`,
      {
        method: "PATCH",
        headers: {
          ...(await authorizationHeader()),
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status, rejectionReason }),
      },
    )
    const body = await responseData(response)
    return toApplication(body.application as DriverApplicationRow)
  },
}
