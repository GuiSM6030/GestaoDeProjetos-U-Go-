import { Hono } from "npm:hono"
import { cors } from "npm:hono/cors"
import { logger } from "npm:hono/logger"
import { createClient } from "jsr:@supabase/supabase-js@2.49.8"
const app = new Hono()

const adminClient = () =>
  createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  )

const normalizeCpf = (value: unknown) => String(value ?? "").replace(/\D/g, "")

function isValidCpf(value: string) {
  const cpf = normalizeCpf(value)
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false
  const calculateDigit = (length: number) => {
    let sum = 0
    for (let index = 0; index < length; index += 1) {
      sum += Number(cpf[index]) * (length + 1 - index)
    }
    const remainder = (sum * 10) % 11
    return remainder === 10 ? 0 : remainder
  }
  return (
    calculateDigit(9) === Number(cpf[9]) &&
    calculateDigit(10) === Number(cpf[10])
  )
}

function isValidPixKey(type: string, value: string, holderCpf: string) {
  const trimmed = value.trim()
  if (type === "cpf") {
    return normalizeCpf(trimmed) === holderCpf && isValidCpf(trimmed)
  }
  if (type === "email") {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)
  }
  if (type === "phone") {
    return /^\d{10,13}$/.test(trimmed.replace(/\D/g, ""))
  }
  if (type === "random") {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      trimmed,
    )
  }
  return false
}

function maskBankValue(value: string, visible = 3) {
  if (value.length <= visible) return "*".repeat(value.length)
  return `${"*".repeat(Math.max(4, value.length - visible))}${value.slice(-visible)}`
}

function maskedBankAccount(account: any) {
  if (!account) return null
  const pixKey =
    account.pix_key_type === "email"
      ? account.pix_key.replace(
          /^(.{1,2}).*(@.*)$/,
          (_match: string, start: string, domain: string) =>
            `${start}***${domain}`,
        )
      : maskBankValue(String(account.pix_key), 4)
  return {
    bankName: account.bank_name,
    agency: maskBankValue(String(account.agency), 2),
    accountNumber: maskBankValue(String(account.account_number), 3),
    accountType: account.account_type,
    pixKeyType: account.pix_key_type,
    pixKey,
    holderName: account.holder_name,
    holderCpf: `***.***.***-${String(account.holder_cpf).slice(-2)}`,
    enabledForPayouts: account.enabled_for_payouts,
    verifiedAt: account.verified_at,
  }
}

async function listAllUsers(admin: ReturnType<typeof adminClient>) {
  const users = []
  const perPage = 1000
  for (let page = 1; ; page += 1) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage })
    if (error) throw error
    users.push(...data.users)
    if (data.users.length < perPage) return users
  }
}

function findRegistrationConflicts(
  users: Awaited<ReturnType<typeof listAllUsers>>,
  email: string,
  cpf: string,
) {
  return {
    emailExists: users.some(
      (user) => user.email?.trim().toLowerCase() === email,
    ),
    cpfExists:
      cpf.length === 11 &&
      users.some((user) => normalizeCpf(user.user_metadata?.cpf) === cpf),
  }
}

async function authenticatedCompany(c: any) {
  const authorization = c.req.header("Authorization") ?? ""
  const token = authorization.replace(/^Bearer\s+/i, "")
  if (!token) return null

  const admin = adminClient()
  const { data, error } = await admin.auth.getUser(token)
  if (error || !data.user || data.user.user_metadata?.role !== "company") {
    return null
  }
  return { admin, company: data.user }
}

async function authenticatedUser(c: any, expectedRole?: string) {
  const authorization = c.req.header("Authorization") ?? ""
  const token = authorization.replace(/^Bearer\s+/i, "")
  if (!token) return null

  const admin = adminClient()
  const { data, error } = await admin.auth.getUser(token)
  if (
    error ||
    !data.user ||
    (expectedRole && data.user.user_metadata?.role !== expectedRole)
  ) {
    return null
  }
  return { admin, user: data.user }
}

const mercadoPagoApi = "https://api.mercadopago.com"

async function mercadoPagoRequest(path: string, init: RequestInit = {}) {
  const accessToken = Deno.env.get("MERCADO_PAGO_ACCESS_TOKEN")
  if (!accessToken)
    throw new Error("Credencial do Mercado Pago não configurada.")

  const response = await fetch(`${mercadoPagoApi}${path}`, {
    ...init,
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      authorization: `Bearer ${accessToken}`,
      ...(init.headers ?? {}),
    },
  })
  const payload = await response.json().catch(() => ({}))
  if (!response.ok) {
    const message =
      payload?.message ??
      payload?.error ??
      payload?.cause?.[0]?.description ??
      "O Mercado Pago não conseguiu processar a solicitação."
    const error = new Error(String(message))
    ;(error as any).status = response.status
    ;(error as any).payload = payload
    throw error
  }
  return payload
}

function paymentFromOrder(order: any) {
  return order?.transactions?.payments?.[0] ?? null
}

function normalizedChargeStatus(order: any) {
  const payment = paymentFromOrder(order)
  const status = String(payment?.status ?? order?.status ?? "").toLowerCase()
  const detail = String(
    payment?.status_detail ?? order?.status_detail ?? "",
  ).toLowerCase()
  if (
    status.includes("refund") ||
    status.includes("chargeback") ||
    detail.includes("refund") ||
    detail.includes("chargeback")
  ) {
    return "refunded"
  }
  if (status === "processed" && detail === "accredited") return "paid"
  return "pending"
}

function isRejectedOrder(order: any) {
  const payment = paymentFromOrder(order)
  const status = String(payment?.status ?? order?.status ?? "").toLowerCase()
  const detail = String(
    payment?.status_detail ?? order?.status_detail ?? "",
  ).toLowerCase()
  return (
    ["failed", "rejected", "cancelled", "canceled"].includes(status) ||
    detail.includes("reject") ||
    detail.includes("not_authorized") ||
    detail.includes("unauthorized")
  )
}

interface PaymentNotificationContent {
  title: string
  message: string
}

async function addPaymentNotifications(
  admin: ReturnType<typeof adminClient>,
  charge: any,
  status: string,
) {
  const messages: Record<string, PaymentNotificationContent> = {
    paid: {
      title: "Pagamento confirmado",
      message: `A mensalidade de R$ ${Number(charge.amount).toLocaleString("pt-BR", { minimumFractionDigits: 2 })} foi confirmada.`,
    },
    refunded: {
      title: "Pagamento estornado",
      message:
        "O pagamento da mensalidade foi estornado e a cobrança voltou a ficar pendente.",
    },
  }
  const content = messages[status]
  if (!content) return
  await admin.from("app_notifications").insert([
    { user_id: charge.student_id, type: "payment", ...content },
    {
      user_id: charge.driver_id,
      type: "payment",
      title: content.title,
      message: `${content.message} Contrato ${charge.membership_id}.`,
    },
  ])
}

async function applyMercadoPagoOrder(
  admin: ReturnType<typeof adminClient>,
  order: any,
  eventType: string,
) {
  const payment = paymentFromOrder(order)
  const externalReference = String(order?.external_reference ?? "")
  let query = admin.from("monthly_charges").select("*")
  query = externalReference
    ? query.eq("id", externalReference)
    : query.eq("provider_order_id", String(order?.id ?? ""))
  const { data: charge, error: chargeError } = await query.maybeSingle()
  if (chargeError || !charge) return null

  const status = normalizedChargeStatus(order)
  const providerStatus = String(payment?.status ?? order?.status ?? "")
  const providerDetail = String(
    payment?.status_detail ?? order?.status_detail ?? "",
  )
  const eventKey = [
    order?.id,
    payment?.id,
    eventType,
    providerStatus,
    providerDetail,
  ].join(":")
  const { data: previousEvent } = await admin
    .from("payment_transactions")
    .select("id")
    .eq("event_key", eventKey)
    .maybeSingle()

  const paymentMethod = payment?.payment_method ?? {}
  const update: Record<string, unknown> = {
    status,
    payment_method:
      paymentMethod.type === "bank_transfer" ? "pix" : "credit_card",
    provider_order_id: order?.id ?? charge.provider_order_id,
    provider_payment_id: payment?.id ?? charge.provider_payment_id,
    provider_status: providerStatus,
    provider_status_detail: providerDetail,
    pix_qr_code: paymentMethod.qr_code ?? charge.pix_qr_code,
    pix_qr_code_base64:
      paymentMethod.qr_code_base64 ?? charge.pix_qr_code_base64,
    pix_ticket_url: paymentMethod.ticket_url ?? charge.pix_ticket_url,
    last_error: isRejectedOrder(order) ? "Transação não autorizada" : null,
    updated_at: new Date().toISOString(),
  }
  if (status === "paid" && !charge.paid_at) {
    update.paid_at = new Date().toISOString()
  }
  if (status === "refunded" && !charge.refunded_at) {
    update.refunded_at = new Date().toISOString()
  }

  const { data: updated, error: updateError } = await admin
    .from("monthly_charges")
    .update(update)
    .eq("id", charge.id)
    .select("*")
    .single()
  if (updateError) throw updateError

  if (!previousEvent) {
    await admin.from("payment_transactions").insert({
      charge_id: charge.id,
      event_key: eventKey,
      provider_order_id: order?.id ?? null,
      provider_payment_id: payment?.id ?? null,
      event_type: eventType,
      status: providerStatus || status,
      status_detail: providerDetail || null,
      amount: Number(charge.amount),
    })
    await addPaymentNotifications(admin, updated, status)
  }

  if (status === "paid") {
    await admin
      .from("route_memberships")
      .update({ status: "active", updated_at: new Date().toISOString() })
      .eq("id", charge.membership_id)
      .eq("status", "pending")
  } else if (status === "refunded") {
    await admin
      .from("route_memberships")
      .update({ status: "pending", updated_at: new Date().toISOString() })
      .eq("id", charge.membership_id)
      .eq("status", "active")
  }

  return updated
}

async function webhookSignatureIsValid(
  xSignature: string,
  xRequestId: string,
  dataId: string,
) {
  const secret = Deno.env.get("MERCADO_PAGO_WEBHOOK_SECRET")
  if (!secret || !xSignature || !xRequestId || !dataId) return false
  const parts = Object.fromEntries(xSignature.split(",").map((part) => {
      const [key, ...value] = part.trim().split("=")
      return [key, value.join("=")]
    }))
  if (!parts.ts || !parts.v1) return false
  const manifest = `id:${dataId.toLowerCase()};request-id:${xRequestId};ts:${parts.ts};`
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  )
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(manifest),
  )
  const expected = Array.from(new Uint8Array(signature))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("")
  if (expected.length !== parts.v1.length) return false
  let difference = 0
  for (let index = 0; index < expected.length; index += 1) {
    difference |= expected.charCodeAt(index) ^ parts.v1.charCodeAt(index)
  }
  return difference === 0
}

async function authenticatedAdmin(c: any) {
  const authorization = c.req.header("Authorization") ?? ""
  const token = authorization.replace(/^Bearer\s+/i, "")
  if (!token) return null

  const admin = adminClient()
  const { data, error } = await admin.auth.getUser(token)
  const email = data.user?.email?.trim().toLowerCase()
  if (
    error ||
    !data.user ||
    email !== "administracao.ugo@gmail.com" ||
    data.user.app_metadata?.role !== "admin"
  ) {
    return null
  }
  return { admin, user: data.user }
}

// Enable logger
app.use("*", logger(console.log))

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
)

// Health check endpoint
app.get("/make-server-0563e832/health", (c) => {
  return c.json({ status: "ok" })
})

app.post("/make-server-0563e832/contracts/:id/pdf", async (c) => {
  const context = await authenticatedUser(c)
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const membershipId = c.req.param("id")
  const { data: membership } = await context.admin
    .from("route_memberships")
    .select("*")
    .eq("id", membershipId)
    .or(`student_id.eq.${context.user.id},driver_id.eq.${context.user.id}`)
    .maybeSingle()
  if (!membership) return c.json({ error: "Contrato não encontrado." }, 404)

  const body = await c.req.json()
  const pdfBase64 = String(body.pdfBase64 ?? "")
  if (!pdfBase64 || pdfBase64.length > 15_000_000) {
    return c.json({ error: "Arquivo de contrato inválido." }, 400)
  }
  let bytes: Uint8Array
  try {
    bytes = Uint8Array.from(atob(pdfBase64), (character) =>
      character.charCodeAt(0),
    )
  } catch {
    return c.json({ error: "Conteúdo do contrato inválido." }, 400)
  }

  const pdfPath = `${membershipId}/contrato.pdf`
  const { error: uploadError } = await context.admin.storage
    .from("contract-pdfs")
    .upload(pdfPath, bytes, {
      contentType: "application/pdf",
      upsert: true,
    })
  if (uploadError) return c.json({ error: uploadError.message }, 400)

  const { data, error } = await context.admin.rpc("attach_contract_pdf", {
    p_membership_id: membershipId,
    p_pdf_path: pdfPath,
  })
  if (error) return c.json({ error: error.message }, 400)
  return c.json({ contract: data })
})

app.get("/make-server-0563e832/contracts/:id/pdf", async (c) => {
  const context = await authenticatedUser(c)
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const membershipId = c.req.param("id")
  const { data: membership } = await context.admin
    .from("route_memberships")
    .select("pdf_path")
    .eq("id", membershipId)
    .or(`student_id.eq.${context.user.id},driver_id.eq.${context.user.id}`)
    .maybeSingle()
  if (!membership?.pdf_path) {
    return c.json({ error: "PDF do contrato não encontrado." }, 404)
  }

  const { data, error } = await context.admin.storage
    .from("contract-pdfs")
    .download(membership.pdf_path)
  if (error || !data) {
    return c.json({ error: error?.message ?? "PDF não encontrado." }, 404)
  }

  const bytes = new Uint8Array(await data.arrayBuffer())
  let binary = ""
  const chunkSize = 32_768
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize))
  }
  return c.json({
    fileName: `contrato-ugo-${membershipId.slice(0, 8)}.pdf`,
    contentType: "application/pdf",
    pdfBase64: btoa(binary),
  })
})

app.get("/make-server-0563e832/contracts/:id/pdf-url", async (c) => {
  const context = await authenticatedUser(c)
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const membershipId = c.req.param("id")
  const { data: membership } = await context.admin
    .from("route_memberships")
    .select("pdf_path")
    .eq("id", membershipId)
    .or(`student_id.eq.${context.user.id},driver_id.eq.${context.user.id}`)
    .maybeSingle()
  if (!membership?.pdf_path) {
    return c.json({ error: "PDF do contrato não encontrado." }, 404)
  }
  const { data, error } = await context.admin.storage
    .from("contract-pdfs")
    .createSignedUrl(membership.pdf_path, 60)
  if (error) return c.json({ error: error.message }, 400)
  return c.json({ signedUrl: data.signedUrl })
})

app.get("/make-server-0563e832/payments/config", async (c) => {
  const context = await authenticatedUser(c, "student")
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const publicKey = Deno.env.get("MERCADO_PAGO_PUBLIC_KEY")
  if (!publicKey) {
    return c.json({ error: "Mercado Pago não configurado." }, 503)
  }
  return c.json({ publicKey })
})

app.get("/make-server-0563e832/driver/bank-account", async (c) => {
  const context = await authenticatedUser(c, "driver")
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const { data, error } = await context.admin
    .from("driver_bank_accounts")
    .select("*")
    .eq("driver_id", context.user.id)
    .maybeSingle()
  if (error) return c.json({ error: error.message }, 400)
  return c.json({ account: maskedBankAccount(data) })
})

app.put("/make-server-0563e832/driver/bank-account", async (c) => {
  const context = await authenticatedUser(c, "driver")
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const body = await c.req.json()
  const bankName = String(body.bankName ?? "").trim()
  const agency = String(body.agency ?? "").trim()
  const accountNumber = String(body.accountNumber ?? "").trim()
  const accountType = String(body.accountType ?? "")
  const pixKeyType = String(body.pixKeyType ?? "")
  const pixKey = String(body.pixKey ?? "").trim()
  const holderName = String(body.holderName ?? "").trim()
  const holderCpf = normalizeCpf(body.holderCpf)
  const profileCpf = normalizeCpf(context.user.user_metadata?.cpf)

  if (
    !bankName ||
    !agency ||
    !accountNumber ||
    !holderName ||
    !["checking", "savings"].includes(accountType) ||
    !["cpf", "email", "phone", "random"].includes(pixKeyType)
  ) {
    return c.json({ error: "Preencha todos os dados bancários." }, 400)
  }
  if (!isValidCpf(holderCpf)) {
    return c.json({ error: "Informe um CPF de titular válido." }, 400)
  }
  if (!profileCpf || holderCpf !== profileCpf) {
    return c.json(
      {
        error:
          "CPF do titular diverge do CPF cadastrado no perfil do motorista.",
      },
      403,
    )
  }
  if (!isValidPixKey(pixKeyType, pixKey, holderCpf)) {
    return c.json({ error: "Informe uma chave Pix válida." }, 400)
  }

  const { data, error } = await context.admin
    .from("driver_bank_accounts")
    .upsert({
      driver_id: context.user.id,
      bank_name: bankName,
      agency,
      account_number: accountNumber,
      account_type: accountType,
      pix_key_type: pixKeyType,
      pix_key:
        pixKeyType === "cpf"
          ? normalizeCpf(pixKey)
          : pixKeyType === "phone"
            ? pixKey.replace(/\D/g, "")
            : pixKey,
      holder_name: holderName,
      holder_cpf: holderCpf,
      enabled_for_payouts: true,
      verified_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .select("*")
    .single()
  if (error) return c.json({ error: error.message }, 400)
  return c.json({
    account: maskedBankAccount(data),
    message: "Dados bancários salvos. Recebimento de repasses habilitado.",
  })
})

app.get("/make-server-0563e832/payments/charges", async (c) => {
  const context = await authenticatedUser(c, "student")
  if (!context) return c.json({ error: "Não autorizado." }, 401)

  const { data: memberships, error: membershipError } = await context.admin
    .from("route_memberships")
    .select("*")
    .eq("student_id", context.user.id)
    .in("status", ["active", "pending"])
  if (membershipError) return c.json({ error: membershipError.message }, 400)
  const currentMembershipIds = (memberships ?? []).map(
    (membership) => membership.id,
  )
  if (currentMembershipIds.length === 0) {
    return c.json({ charges: [] })
  }

  const now = new Date()
  const referenceMonth = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}-01`
  for (const membership of memberships ?? []) {
    const dueDay = Math.min(28, Math.max(1, Number(membership.due_day ?? 10)))
    const dueDate = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}-${String(dueDay).padStart(2, "0")}`
    await context.admin.from("monthly_charges").upsert(
      {
        membership_id: membership.id,
        student_id: membership.student_id,
        driver_id: membership.driver_id,
        reference_month: referenceMonth,
        due_date: dueDate,
        amount: Number(membership.monthly_price),
      },
      { onConflict: "membership_id,reference_month", ignoreDuplicates: true },
    )
  }

  const { data: charges, error } = await context.admin
    .from("monthly_charges")
    .select("*")
    .eq("student_id", context.user.id)
    .in("membership_id", currentMembershipIds)
    .order("due_date", { ascending: false })
  if (error) return c.json({ error: error.message }, 400)
  const membershipById = new Map(
    (memberships ?? []).map((membership) => [membership.id, membership]),
  )
  return c.json({
    charges: (charges ?? []).map((charge) => ({
      ...charge,
      route_name:
        membershipById.get(charge.membership_id)?.route_name ?? "Rota",
      driver_name:
        membershipById.get(charge.membership_id)?.driver_name ?? "Motorista",
    })),
  })
})

app.post("/make-server-0563e832/payments/orders", async (c) => {
  const context = await authenticatedUser(c, "student")
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const body = await c.req.json()
  const chargeId = String(body.chargeId ?? "")
  const method = String(body.method ?? "")
  if (!["pix", "credit_card"].includes(method)) {
    return c.json({ error: "Método de pagamento inválido." }, 400)
  }

  const { data: charge, error: chargeError } = await context.admin
    .from("monthly_charges")
    .select("*")
    .eq("id", chargeId)
    .eq("student_id", context.user.id)
    .single()
  if (chargeError || !charge) {
    return c.json({ error: "Cobrança não encontrada." }, 404)
  }
  if (charge.status === "paid") {
    return c.json({ charge, message: "Esta cobrança já está paga." })
  }
  const { data: membership } = await context.admin
    .from("route_memberships")
    .select("status")
    .eq("id", charge.membership_id)
    .eq("student_id", context.user.id)
    .maybeSingle()
  if (!membership || !["active", "pending"].includes(membership.status)) {
    return c.json(
      { error: "Este contrato não está disponível para pagamento." },
      409,
    )
  }

  const amount = Number(charge.amount).toFixed(2)
  const paymentMethod =
    method === "pix"
      ? { id: "pix", type: "bank_transfer" }
      : {
          id: String(body.card?.paymentMethodId ?? ""),
          type: String(body.card?.paymentTypeId ?? "credit_card"),
          token: String(body.card?.token ?? ""),
          installments: Number(body.card?.installments ?? 1),
        }
  if (
    method === "credit_card" &&
    (!paymentMethod.id ||
      !(paymentMethod as any).token ||
      (paymentMethod as any).type !== "credit_card")
  ) {
    return c.json({ error: "Dados do cartão incompletos." }, 400)
  }

  const orderBody: any = {
    type: "online",
    processing_mode: "automatic",
    total_amount: amount,
    external_reference: charge.id,
    transactions: {
      payments: [
        {
          amount,
          payment_method: paymentMethod,
          ...(method === "pix" ? { expiration_time: "P1D" } : {}),
        },
      ],
    },
    payer: {
      email: context.user.email,
      ...(body.card?.identification
        ? { identification: body.card.identification }
        : {}),
    },
  }

  try {
    const idempotencyKey =
      method === "pix" ? `ugo-pix-${charge.id}` : crypto.randomUUID()
    const order = await mercadoPagoRequest("/v1/orders", {
      method: "POST",
      headers: { "X-Idempotency-Key": idempotencyKey },
      body: JSON.stringify(orderBody),
    })
    const updated = await applyMercadoPagoOrder(
      context.admin,
      order,
      "order.created",
    )
    if (method === "credit_card" && isRejectedOrder(order)) {
      return c.json(
        {
          error: "Transação não autorizada",
          suggestion: "Tente pagar com Pix ou utilize outro cartão.",
          charge: updated,
        },
        402,
      )
    }
    return c.json({ order, charge: updated })
  } catch (error) {
    console.error("Mercado Pago order creation failed", error)
    const message = String((error as Error).message ?? "")
    const unauthorized =
      method === "credit_card" &&
      (/authoriz|reject|declin|denied/i.test(message) ||
        Number((error as any).status) === 402)
    await context.admin
      .from("monthly_charges")
      .update({
        status: "pending",
        last_error: unauthorized
          ? "Transação não autorizada"
          : "Pagamento não confirmado",
        updated_at: new Date().toISOString(),
      })
      .eq("id", charge.id)
    return c.json(
      unauthorized
        ? {
            error: "Transação não autorizada",
            suggestion: "Tente pagar com Pix ou utilize outro cartão.",
          }
        : { error: "Pagamento não confirmado. Tente novamente." },
      unauthorized ? 402 : 400,
    )
  }
})

app.post("/make-server-0563e832/payments/charges/:id/sync", async (c) => {
  const context = await authenticatedUser(c, "student")
  if (!context) return c.json({ error: "Não autorizado." }, 401)
  const { data: charge } = await context.admin
    .from("monthly_charges")
    .select("*")
    .eq("id", c.req.param("id"))
    .eq("student_id", context.user.id)
    .single()
  if (!charge?.provider_order_id) {
    return c.json({ error: "Pagamento ainda não iniciado." }, 400)
  }
  try {
    const order = await mercadoPagoRequest(
      `/v1/orders/${encodeURIComponent(charge.provider_order_id)}`,
    )
    const updated = await applyMercadoPagoOrder(
      context.admin,
      order,
      "order.synced",
    )
    return c.json({ charge: updated })
  } catch (error) {
    console.error("Mercado Pago order sync failed", error)
    return c.json({ error: "Pagamento não confirmado." }, 400)
  }
})

app.post("/make-server-0563e832/mercadopago/webhook", async (c) => {
  const body = await c.req.json().catch(() => ({}))
  const dataId = String(
    c.req.query("data.id") ?? c.req.query("data_id") ?? body?.data?.id ?? "",
  )
  const valid = await webhookSignatureIsValid(
    c.req.header("x-signature") ?? "",
    c.req.header("x-request-id") ?? "",
    dataId,
  )
  if (!valid) return c.json({ error: "Assinatura inválida." }, 401)

  try {
    const order = await mercadoPagoRequest(
      `/v1/orders/${encodeURIComponent(dataId)}`,
    )
    await applyMercadoPagoOrder(
      adminClient(),
      order,
      String(body?.action ?? body?.type ?? "order.updated"),
    )
    return c.json({ received: true })
  } catch (error) {
    console.error("Mercado Pago webhook processing failed", error)
    // Returning 500 asks Mercado Pago to retry the notification.
    return c.json({ error: "Falha ao processar a notificação." }, 500)
  }
})

app.post("/make-server-0563e832/registration/check", async (c) => {
  const body = await c.req.json()
  const email = String(body.email ?? "")
    .trim()
    .toLowerCase()
  const cpf = normalizeCpf(body.cpf)
  if (!email) return c.json({ error: "Informe o e-mail." }, 400)

  try {
    const conflicts = findRegistrationConflicts(
      await listAllUsers(adminClient()),
      email,
      cpf,
    )
    return c.json(conflicts)
  } catch (error) {
    console.error("Registration availability check failed", error)
    return c.json({ error: "Não foi possível validar o cadastro." }, 500)
  }
})

app.post("/make-server-0563e832/collaborators", async (c) => {
  const context = await authenticatedCompany(c)
  if (!context) return c.json({ error: "Não autorizado." }, 401)

  const body = await c.req.json()
  const collaborators = Array.isArray(body.collaborators)
    ? body.collaborators
    : []
  if (collaborators.length === 0 || collaborators.length > 100) {
    return c.json({ error: "Informe entre 1 e 100 colaboradores." }, 400)
  }

  const companyName =
    context.company.user_metadata?.nome_fantasia ??
    context.company.user_metadata?.razao_social ??
    "Empresa"
  const created = []
  const failures = []
  let existingUsers
  try {
    existingUsers = await listAllUsers(context.admin)
  } catch (error) {
    console.error("Collaborator availability check failed", error)
    return c.json({ error: "Não foi possível validar os colaboradores." }, 500)
  }

  for (const item of collaborators) {
    const email = String(item.email ?? "")
      .trim()
      .toLowerCase()
    const name = String(item.name ?? "").trim()
    if (!email || !name) {
      failures.push({ email, error: "Nome e e-mail são obrigatórios." })
      continue
    }
    const cpf = normalizeCpf(item.cpf)
    const conflicts = findRegistrationConflicts(existingUsers, email, cpf)
    if (conflicts.emailExists) {
      failures.push({ email, error: "Este e-mail já está cadastrado." })
      continue
    }
    if (conflicts.cpfExists) {
      failures.push({ email, error: "Este CPF já está cadastrado." })
      continue
    }

    const { data: invited, error: inviteError } =
      await context.admin.auth.admin.inviteUserByEmail(email, {
        redirectTo: body.redirectTo,
        data: {
          role: "collaborator",
          full_name: name,
          phone: String(item.phone ?? "").trim(),
          cpf: String(item.cpf ?? "").trim(),
          address: String(item.address ?? "").trim(),
          department: String(item.department ?? "").trim(),
          company: companyName,
          company_id: context.company.id,
          needs_password: true,
        },
      })

    if (inviteError || !invited.user) {
      failures.push({
        email,
        error: inviteError?.message ?? "Não foi possível criar o usuário.",
      })
      continue
    }

    const { data: record, error: insertError } = await context.admin
      .from("company_collaborators")
      .insert({
        company_id: context.company.id,
        auth_user_id: invited.user.id,
        name,
        email,
        cpf: String(item.cpf ?? "").trim(),
        phone: String(item.phone ?? "").trim(),
        address: String(item.address ?? "").trim(),
        department: String(item.department ?? "").trim(),
        needs_password: true,
      })
      .select("*")
      .single()

    if (insertError) {
      await context.admin.auth.admin.deleteUser(invited.user.id)
      failures.push({ email, error: insertError.message })
      continue
    }
    created.push(record)
    existingUsers.push(invited.user)
  }

  return c.json({ created, failures }, failures.length > 0 ? 207 : 201)
})

app.delete("/make-server-0563e832/collaborators/:id", async (c) => {
  const context = await authenticatedCompany(c)
  if (!context) return c.json({ error: "Não autorizado." }, 401)

  const { data: collaborator, error } = await context.admin
    .from("company_collaborators")
    .select("id, auth_user_id")
    .eq("id", c.req.param("id"))
    .eq("company_id", context.company.id)
    .single()

  if (error || !collaborator) {
    return c.json({ error: "Colaborador não encontrado." }, 404)
  }

  if (collaborator.auth_user_id) {
    const { error: deleteUserError } =
      await context.admin.auth.admin.deleteUser(collaborator.auth_user_id)
    if (deleteUserError) return c.json({ error: deleteUserError.message }, 400)
  } else {
    const { error: deleteError } = await context.admin
      .from("company_collaborators")
      .delete()
      .eq("id", collaborator.id)
    if (deleteError) return c.json({ error: deleteError.message }, 400)
  }

  return c.json({ success: true })
})

app.get("/make-server-0563e832/admin/driver-applications", async (c) => {
  const context = await authenticatedAdmin(c)
  if (!context) return c.json({ error: "Não autorizado." }, 401)

  const { data, error } = await context.admin
    .from("driver_applications")
    .select("*")
    .order("created_at", { ascending: false })

  if (error) return c.json({ error: error.message }, 400)
  return c.json({ applications: data ?? [] })
})

app.patch(
  "/make-server-0563e832/admin/driver-applications/:userId",
  async (c) => {
    const context = await authenticatedAdmin(c)
    if (!context) return c.json({ error: "Não autorizado." }, 401)

    const body = await c.req.json()
    const status = String(body.status ?? "")
    const rejectionReason = String(body.rejectionReason ?? "").trim()
    if (!["approved", "rejected"].includes(status)) {
      return c.json({ error: "Status de análise inválido." }, 400)
    }
    if (status === "rejected" && !rejectionReason) {
      return c.json({ error: "Informe o motivo da reprovação." }, 400)
    }

    const { data, error } = await context.admin
      .from("driver_applications")
      .update({
        status,
        rejection_reason: status === "rejected" ? rejectionReason : null,
      })
      .eq("user_id", c.req.param("userId"))
      .eq("status", "pending")
      .select("*")
      .single()

    if (error || !data) {
      return c.json(
        {
          error:
            error?.message ?? "Solicitação não encontrada ou já analisada.",
        },
        400,
      )
    }
    return c.json({ application: data })
  },
)

Deno.serve(app.fetch)
