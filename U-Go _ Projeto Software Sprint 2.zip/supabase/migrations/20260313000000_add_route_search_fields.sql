alter table public.driver_routes
  add column if not exists university text not null default '';

alter table public.driver_routes
  add column if not exists origin_neighborhood text not null default '';

update public.driver_routes
set university = destination
where university = '';

update public.driver_routes
set origin_neighborhood = origin
where origin_neighborhood = '';

create index if not exists driver_routes_university_idx
  on public.driver_routes using gin (to_tsvector('portuguese', university));

create index if not exists driver_routes_origin_neighborhood_idx
  on public.driver_routes using gin (
    to_tsvector('portuguese', origin_neighborhood)
  );

notify pgrst, 'reload schema';
