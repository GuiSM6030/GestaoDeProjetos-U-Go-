alter table public.driver_routes
  add column if not exists arrival_time time;

update public.driver_routes
set arrival_time = return_time
where arrival_time is null;

alter table public.driver_routes
  alter column arrival_time set not null;

alter table public.route_memberships
  add column if not exists access_code uuid not null default gen_random_uuid();

create unique index if not exists route_memberships_access_code_idx
  on public.route_memberships(access_code);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  client_event_id uuid not null unique,
  membership_id uuid not null references public.route_memberships(id)
    on delete restrict,
  route_id uuid not null references public.driver_routes(id) on delete restrict,
  student_id uuid not null references auth.users(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  scanned_at timestamptz not null,
  status text not null check (status in ('authorized', 'denied')),
  denial_reason text,
  recorded_offline boolean not null default false,
  synced_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists attendance_records_route_date_idx
  on public.attendance_records(route_id, scanned_at desc);
create index if not exists attendance_records_student_idx
  on public.attendance_records(student_id, scanned_at desc);

alter table public.attendance_records enable row level security;
create policy "Attendance parties can read records"
  on public.attendance_records for select to authenticated
  using (student_id = auth.uid() or driver_id = auth.uid());
grant select on public.attendance_records to authenticated;

create or replace function public.get_driver_attendance_roster()
returns table (
  access_code uuid,
  membership_id uuid,
  route_id uuid,
  route_name text,
  student_id uuid,
  student_name text,
  membership_status text,
  authorized boolean,
  denial_reason text
)
language sql security definer set search_path = public
as $$
  select
    membership.access_code,
    membership.id,
    membership.route_id,
    membership.route_name,
    membership.student_id,
    membership.student_name,
    membership.status,
    (
      membership.status = 'active'
      and current_date between membership.start_date and membership.end_date
      and not exists (
        select 1 from public.monthly_charges charge
        where charge.membership_id = membership.id
          and charge.status = 'pending'
      )
    ),
    case
      when membership.status <> 'active'
        or current_date not between membership.start_date and membership.end_date
        then 'contract_inactive'
      when exists (
        select 1 from public.monthly_charges charge
        where charge.membership_id = membership.id
          and charge.status = 'pending'
      ) then 'payment_pending'
      else null
    end
  from public.route_memberships membership
  where membership.driver_id = auth.uid();
$$;

create or replace function public.validate_route_access_code(
  p_access_code uuid,
  p_client_event_id uuid,
  p_scanned_at timestamptz default now(),
  p_recorded_offline boolean default false
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  membership public.route_memberships;
  existing_record public.attendance_records;
  is_authorized boolean;
  reason text;
  result_message text;
begin
  if auth.uid() is null then
    raise exception 'Usuário não autenticado.';
  end if;

  select record.* into existing_record
  from public.attendance_records record
  where record.client_event_id = p_client_event_id;

  if found then
    if existing_record.driver_id <> auth.uid() then
      raise exception 'Evento de validação inválido.';
    end if;
    select * into membership from public.route_memberships
    where id = existing_record.membership_id;
    return jsonb_build_object(
      'authorized', existing_record.status = 'authorized',
      'message', case when existing_record.status = 'authorized'
        then 'Embarque Autorizado'
        else 'Embarque Não Autorizado: Pagamento Pendente' end,
      'membershipId', membership.id,
      'studentName', membership.student_name,
      'reason', existing_record.denial_reason
    );
  end if;

  select * into membership
  from public.route_memberships
  where access_code = p_access_code
    and driver_id = auth.uid()
  for update;

  if not found then
    return jsonb_build_object(
      'authorized', false,
      'message', 'QR Code inválido para suas rotas',
      'reason', 'invalid_code'
    );
  end if;

  is_authorized :=
    membership.status = 'active'
    and current_date between membership.start_date and membership.end_date
    and not exists (
      select 1 from public.monthly_charges charge
      where charge.membership_id = membership.id
        and charge.status = 'pending'
    );
  reason := case
    when is_authorized then null
    when membership.status <> 'active'
      or current_date not between membership.start_date and membership.end_date
      then 'contract_inactive'
    else 'payment_pending'
  end;
  result_message := case when is_authorized
    then 'Embarque Autorizado'
    else 'Embarque Não Autorizado: Pagamento Pendente'
  end;

  insert into public.attendance_records (
    client_event_id,
    membership_id,
    route_id,
    student_id,
    driver_id,
    scanned_at,
    status,
    denial_reason,
    recorded_offline
  ) values (
    p_client_event_id,
    membership.id,
    membership.route_id,
    membership.student_id,
    membership.driver_id,
    coalesce(p_scanned_at, now()),
    case when is_authorized then 'authorized' else 'denied' end,
    reason,
    p_recorded_offline
  );

  return jsonb_build_object(
    'authorized', is_authorized,
    'message', result_message,
    'membershipId', membership.id,
    'studentName', membership.student_name,
    'reason', reason
  );
end;
$$;

create or replace function public.sync_offline_attendance(p_events jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  event jsonb;
  result jsonb;
  results jsonb := '[]'::jsonb;
begin
  if jsonb_typeof(p_events) <> 'array' then
    raise exception 'A fila de eventos deve ser uma lista.';
  end if;

  for event in select value from jsonb_array_elements(p_events)
  loop
    result := public.validate_route_access_code(
      (event ->> 'accessCode')::uuid,
      (event ->> 'clientEventId')::uuid,
      coalesce((event ->> 'scannedAt')::timestamptz, now()),
      true
    );
    results := results || jsonb_build_array(
      result || jsonb_build_object('clientEventId', event ->> 'clientEventId')
    );
  end loop;
  return results;
end;
$$;

revoke all on function public.get_driver_attendance_roster() from public;
revoke all on function public.validate_route_access_code(
  uuid, uuid, timestamptz, boolean
) from public;
revoke all on function public.sync_offline_attendance(jsonb) from public;
grant execute on function public.get_driver_attendance_roster()
  to authenticated;
grant execute on function public.validate_route_access_code(
  uuid, uuid, timestamptz, boolean
) to authenticated;
grant execute on function public.sync_offline_attendance(jsonb)
  to authenticated;

create or replace function public.publish_driver_route_draft(p_route_id uuid)
returns public.driver_routes
language plpgsql security definer set search_path = public
as $$
declare
  selected_route public.driver_routes;
  draft public.driver_route_drafts;
begin
  select * into selected_route from public.driver_routes
  where id = p_route_id and driver_id = auth.uid() and archived_at is null
  for update;
  if not found then raise exception 'Rota não encontrada.'; end if;

  select * into draft from public.driver_route_drafts
  where route_id = p_route_id and driver_id = auth.uid() and status = 'draft';
  if not found then raise exception 'Rascunho não encontrado.'; end if;

  if (draft.payload ->> 'seats')::integer < selected_route.occupied_seats then
    raise exception 'O número de vagas não pode ser menor que o total de alunos contratados';
  end if;

  update public.driver_routes set
    name = draft.payload ->> 'name',
    origin = draft.payload ->> 'origin',
    destination = draft.payload ->> 'destination',
    university = draft.payload ->> 'university',
    origin_neighborhood = draft.payload ->> 'originNeighborhood',
    departure_time = (draft.payload ->> 'departureTime')::time,
    arrival_time = (draft.payload ->> 'arrivalTime')::time,
    return_time = (draft.payload ->> 'returnTime')::time,
    seats = (draft.payload ->> 'seats')::integer,
    days = array(select jsonb_array_elements_text(draft.payload -> 'days')),
    vehicle = coalesce(draft.payload ->> 'vehicle', ''),
    pickup_points = coalesce(draft.payload -> 'pickupPoints', '[]'::jsonb),
    updated_at = now()
  where id = p_route_id
  returning * into selected_route;

  insert into public.app_notifications (user_id, title, message, type)
  select distinct student_id, 'Rota atualizada',
    'O motorista atualizou horários ou itinerário da rota ' ||
    selected_route.name || '.', 'route'
  from public.route_memberships
  where route_id = p_route_id and status in ('active', 'pending');

  delete from public.driver_route_drafts where id = draft.id;
  return selected_route;
end;
$$;

notify pgrst, 'reload schema';
