create table if not exists public.monthly_charges (
  id uuid primary key default gen_random_uuid(),
  membership_id uuid not null references public.route_memberships(id) on delete restrict,
  student_id uuid not null references auth.users(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  reference_month date not null,
  due_date date not null,
  amount numeric(12, 2) not null check (amount > 0),
  status text not null default 'pending'
    check (status in ('pending', 'paid', 'refunded')),
  payment_method text
    check (payment_method is null or payment_method in ('pix', 'credit_card')),
  provider_order_id text unique,
  provider_payment_id text,
  provider_status text,
  provider_status_detail text,
  pix_qr_code text,
  pix_qr_code_base64 text,
  pix_ticket_url text,
  expires_at timestamptz,
  paid_at timestamptz,
  refunded_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (membership_id, reference_month)
);

create index if not exists monthly_charges_student_idx
  on public.monthly_charges(student_id, due_date desc);
create index if not exists monthly_charges_driver_idx
  on public.monthly_charges(driver_id, due_date desc);

alter table public.monthly_charges enable row level security;

drop policy if exists "Payment parties can read charges"
  on public.monthly_charges;
create policy "Payment parties can read charges"
  on public.monthly_charges
  for select
  to authenticated
  using (student_id = auth.uid() or driver_id = auth.uid());

grant select on public.monthly_charges to authenticated;

create table if not exists public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  charge_id uuid not null references public.monthly_charges(id) on delete restrict,
  event_key text not null unique,
  provider_order_id text,
  provider_payment_id text,
  event_type text not null,
  status text not null,
  status_detail text,
  amount numeric(12, 2) not null check (amount > 0),
  created_at timestamptz not null default now()
);

create index if not exists payment_transactions_charge_idx
  on public.payment_transactions(charge_id, created_at desc);

alter table public.payment_transactions enable row level security;

drop policy if exists "Payment parties can read transactions"
  on public.payment_transactions;
create policy "Payment parties can read transactions"
  on public.payment_transactions
  for select
  to authenticated
  using (
    exists (
      select 1
      from public.monthly_charges charge
      where charge.id = charge_id
        and (
          charge.student_id = auth.uid()
          or charge.driver_id = auth.uid()
        )
    )
  );

grant select on public.payment_transactions to authenticated;

create table if not exists public.app_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  message text not null,
  type text not null default 'payment',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists app_notifications_user_idx
  on public.app_notifications(user_id, created_at desc);

alter table public.app_notifications enable row level security;

drop policy if exists "Users can read own notifications"
  on public.app_notifications;
create policy "Users can read own notifications"
  on public.app_notifications
  for select
  to authenticated
  using (user_id = auth.uid());

drop policy if exists "Users can mark own notifications as read"
  on public.app_notifications;
create policy "Users can mark own notifications as read"
  on public.app_notifications
  for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

grant select, update on public.app_notifications to authenticated;

notify pgrst, 'reload schema';
