alter table public.driver_routes
  add column if not exists archived_at timestamptz,
  add column if not exists minimum_term_months integer not null default 3
    check (minimum_term_months between 0 and 60),
  add column if not exists early_termination_fee_percent numeric(5, 2)
    not null default 20
    check (
      early_termination_fee_percent >= 0
      and early_termination_fee_percent <= 100
    );

alter table public.route_memberships
  add column if not exists minimum_term_months integer not null default 3,
  add column if not exists early_termination_fee_percent numeric(5, 2)
    not null default 20;

create table if not exists public.driver_route_drafts (
  id uuid primary key default gen_random_uuid(),
  route_id uuid not null unique references public.driver_routes(id) on delete cascade,
  driver_id uuid not null references auth.users(id) on delete cascade,
  payload jsonb not null,
  status text not null default 'draft' check (status in ('draft', 'published')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.driver_route_drafts enable row level security;
create policy "Drivers can read own route drafts"
  on public.driver_route_drafts for select to authenticated
  using (driver_id = auth.uid());
grant select on public.driver_route_drafts to authenticated;

create table if not exists public.contract_amendments (
  id uuid primary key default gen_random_uuid(),
  route_id uuid not null references public.driver_routes(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  old_monthly_price numeric(12, 2) not null,
  new_monthly_price numeric(12, 2) not null,
  old_due_day integer not null,
  new_due_day integer not null,
  old_minimum_term_months integer not null,
  new_minimum_term_months integer not null,
  old_termination_fee_percent numeric(5, 2) not null,
  new_termination_fee_percent numeric(5, 2) not null,
  status text not null default 'pending'
    check (status in ('pending', 'accepted')),
  created_at timestamptz not null default now(),
  accepted_at timestamptz
);

create table if not exists public.contract_amendment_acceptances (
  amendment_id uuid not null references public.contract_amendments(id)
    on delete cascade,
  membership_id uuid not null references public.route_memberships(id)
    on delete restrict,
  student_id uuid not null references auth.users(id) on delete restrict,
  status text not null default 'pending'
    check (status in ('pending', 'accepted')),
  accepted_at timestamptz,
  primary key (amendment_id, membership_id)
);

alter table public.contract_amendments enable row level security;
alter table public.contract_amendment_acceptances enable row level security;

create policy "Contract parties can read amendments"
  on public.contract_amendments for select to authenticated
  using (
    driver_id = auth.uid()
    or exists (
      select 1 from public.contract_amendment_acceptances acceptance
      where acceptance.amendment_id = id
        and acceptance.student_id = auth.uid()
    )
  );
create policy "Students can read amendment acceptances"
  on public.contract_amendment_acceptances for select to authenticated
  using (student_id = auth.uid());
grant select on public.contract_amendments to authenticated;
grant select on public.contract_amendment_acceptances to authenticated;

create table if not exists public.contract_terminations (
  id uuid primary key default gen_random_uuid(),
  membership_id uuid not null unique references public.route_memberships(id)
    on delete restrict,
  student_id uuid not null references auth.users(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  residual_fee numeric(12, 2) not null default 0,
  reason text,
  terminated_at timestamptz not null default now()
);

alter table public.contract_terminations enable row level security;
create policy "Contract parties can read terminations"
  on public.contract_terminations for select to authenticated
  using (student_id = auth.uid() or driver_id = auth.uid());
grant select on public.contract_terminations to authenticated;

create or replace function public.delete_driver_route(p_route_id uuid)
returns text
language plpgsql security definer set search_path = public
as $$
declare
  selected_route public.driver_routes;
  has_history boolean;
begin
  select * into selected_route
  from public.driver_routes
  where id = p_route_id and driver_id = auth.uid()
  for update;
  if not found then raise exception 'Rota não encontrada.'; end if;

  if exists (
    select 1 from public.route_memberships
    where route_id = p_route_id and status in ('active', 'pending')
  ) then
    raise exception 'Não é possível excluir uma rota com passageiros ativos';
  end if;

  select exists (
    select 1 from public.route_memberships where route_id = p_route_id
  ) into has_history;

  if has_history then
    update public.driver_routes
    set archived_at = now(), contract_template_ready = false, updated_at = now()
    where id = p_route_id;
    return 'archived';
  end if;

  delete from public.driver_routes where id = p_route_id;
  return 'deleted';
end;
$$;

create or replace function public.save_driver_route_draft(
  p_route_id uuid,
  p_payload jsonb
)
returns public.driver_route_drafts
language plpgsql security definer set search_path = public
as $$
declare
  selected_route public.driver_routes;
  draft public.driver_route_drafts;
  proposed_seats integer;
begin
  select * into selected_route from public.driver_routes
  where id = p_route_id and driver_id = auth.uid() and archived_at is null
  for update;
  if not found then raise exception 'Rota não encontrada.'; end if;

  proposed_seats := (p_payload ->> 'seats')::integer;
  if proposed_seats < selected_route.occupied_seats then
    raise exception 'O número de vagas não pode ser menor que o total de alunos contratados';
  end if;

  insert into public.driver_route_drafts (route_id, driver_id, payload)
  values (p_route_id, auth.uid(), p_payload)
  on conflict (route_id) do update
  set payload = excluded.payload, status = 'draft', updated_at = now()
  returning * into draft;
  return draft;
end;
$$;

create or replace function public.publish_driver_route_draft(p_route_id uuid)
returns public.driver_routes
language plpgsql security definer set search_path = public
as $$
declare
  selected_route public.driver_routes;
  draft public.driver_route_drafts;
begin
  select * into selected_route from public.driver_routes
  where id = p_route_id and driver_id = auth.uid() and archived_at is null
  for update;
  if not found then raise exception 'Rota não encontrada.'; end if;

  select * into draft from public.driver_route_drafts
  where route_id = p_route_id and driver_id = auth.uid() and status = 'draft';
  if not found then raise exception 'Rascunho não encontrado.'; end if;

  if (draft.payload ->> 'seats')::integer < selected_route.occupied_seats then
    raise exception 'O número de vagas não pode ser menor que o total de alunos contratados';
  end if;

  update public.driver_routes set
    name = draft.payload ->> 'name',
    origin = draft.payload ->> 'origin',
    destination = draft.payload ->> 'destination',
    university = draft.payload ->> 'university',
    origin_neighborhood = draft.payload ->> 'originNeighborhood',
    departure_time = (draft.payload ->> 'departureTime')::time,
    return_time = (draft.payload ->> 'returnTime')::time,
    seats = (draft.payload ->> 'seats')::integer,
    days = array(select jsonb_array_elements_text(draft.payload -> 'days')),
    vehicle = coalesce(draft.payload ->> 'vehicle', ''),
    pickup_points = coalesce(draft.payload -> 'pickupPoints', '[]'::jsonb),
    updated_at = now()
  where id = p_route_id
  returning * into selected_route;

  insert into public.app_notifications (user_id, title, message, type)
  select distinct student_id, 'Rota atualizada',
    'O motorista atualizou horários ou itinerário da rota ' ||
    selected_route.name || '.', 'route'
  from public.route_memberships
  where route_id = p_route_id and status in ('active', 'pending');

  delete from public.driver_route_drafts where id = draft.id;
  return selected_route;
end;
$$;

create or replace function public.update_driver_contract_template(
  p_route_id uuid,
  p_monthly_price numeric,
  p_due_day integer,
  p_minimum_term_months integer,
  p_termination_fee_percent numeric
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  selected_route public.driver_routes;
  updated_route public.driver_routes;
  v_amendment_id uuid;
  affected integer := 0;
begin
  if p_monthly_price <= 0 then
    raise exception 'Informe um valor válido para a mensalidade';
  end if;
  if p_due_day not between 1 and 28 then
    raise exception 'Informe um dia de vencimento entre 1 e 28.';
  end if;
  if p_minimum_term_months not between 0 and 60
    or p_termination_fee_percent not between 0 and 100 then
    raise exception 'Informe condições contratuais válidas.';
  end if;

  select * into selected_route from public.driver_routes
  where id = p_route_id and driver_id = auth.uid() and archived_at is null
  for update;
  if not found then raise exception 'Modelo de contrato não encontrado.'; end if;

  update public.driver_routes set
    price = p_monthly_price,
    due_day = p_due_day,
    minimum_term_months = p_minimum_term_months,
    early_termination_fee_percent = p_termination_fee_percent,
    contract_template_ready = true,
    contract_template_archived_at = null,
    updated_at = now()
  where id = p_route_id
  returning * into updated_route;

  if selected_route.contract_template_ready and (
    selected_route.price <> p_monthly_price
    or selected_route.due_day <> p_due_day
    or selected_route.minimum_term_months <> p_minimum_term_months
    or selected_route.early_termination_fee_percent <> p_termination_fee_percent
  ) and exists (
    select 1 from public.route_memberships
    where route_id = p_route_id and status in ('active', 'pending')
  ) then
    insert into public.contract_amendments (
      route_id, driver_id, old_monthly_price, new_monthly_price,
      old_due_day, new_due_day, old_minimum_term_months,
      new_minimum_term_months, old_termination_fee_percent,
      new_termination_fee_percent
    ) values (
      p_route_id, auth.uid(), selected_route.price, p_monthly_price,
      selected_route.due_day, p_due_day, selected_route.minimum_term_months,
      p_minimum_term_months, selected_route.early_termination_fee_percent,
      p_termination_fee_percent
    ) returning id into v_amendment_id;

    insert into public.contract_amendment_acceptances (
      amendment_id, membership_id, student_id
    )
    select v_amendment_id, id, student_id from public.route_memberships
    where route_id = p_route_id and status in ('active', 'pending');
    get diagnostics affected = row_count;

    insert into public.app_notifications (user_id, title, message, type)
    select student_id, 'Novo aditivo contratual',
      'O motorista atualizou as condições da rota ' || selected_route.name ||
      '. Revise e aceite o aditivo.', 'contract'
    from public.route_memberships
    where route_id = p_route_id and status in ('active', 'pending');
  end if;

  return jsonb_build_object(
    'route', to_jsonb(updated_route),
    'amendmentCreated', v_amendment_id is not null,
    'affectedStudents', affected
  );
end;
$$;

create or replace function public.accept_contract_amendment(p_amendment_id uuid)
returns public.route_memberships
language plpgsql security definer set search_path = public
as $$
declare
  amendment public.contract_amendments;
  acceptance public.contract_amendment_acceptances;
  membership public.route_memberships;
begin
  select * into acceptance from public.contract_amendment_acceptances
  where amendment_id = p_amendment_id and student_id = auth.uid()
    and status = 'pending'
  for update;
  if not found then raise exception 'Aditivo pendente não encontrado.'; end if;
  select * into amendment from public.contract_amendments
  where id = p_amendment_id;

  update public.route_memberships set
    monthly_price = amendment.new_monthly_price,
    due_day = amendment.new_due_day,
    minimum_term_months = amendment.new_minimum_term_months,
    early_termination_fee_percent = amendment.new_termination_fee_percent,
    updated_at = now()
  where id = acceptance.membership_id
  returning * into membership;

  update public.contract_amendment_acceptances
  set status = 'accepted', accepted_at = now()
  where amendment_id = p_amendment_id and membership_id = membership.id;

  if not exists (
    select 1 from public.contract_amendment_acceptances
    where amendment_id = p_amendment_id and status = 'pending'
  ) then
    update public.contract_amendments
    set status = 'accepted', accepted_at = now()
    where id = p_amendment_id;
  end if;
  return membership;
end;
$$;

create or replace function public.preview_contract_termination(
  p_membership_id uuid
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  membership public.route_memberships;
  overdue_count integer;
  overdue_amount numeric(12, 2);
  residual numeric(12, 2) := 0;
begin
  select * into membership from public.route_memberships
  where id = p_membership_id and student_id = auth.uid()
    and status in ('active', 'pending');
  if not found then raise exception 'Contrato ativo não encontrado.'; end if;

  select count(*), coalesce(sum(amount), 0)
  into overdue_count, overdue_amount
  from public.monthly_charges
  where membership_id = p_membership_id
    and status = 'pending' and due_date < current_date;

  if current_date < (
    membership.start_date +
    make_interval(months => membership.minimum_term_months)
  )::date then
    residual := round(
      membership.monthly_price *
      membership.early_termination_fee_percent / 100,
      2
    );
  end if;

  return jsonb_build_object(
    'overdueCount', overdue_count,
    'overdueAmount', overdue_amount,
    'residualFee', residual,
    'canTerminate', overdue_count = 0
  );
end;
$$;

create or replace function public.terminate_student_contract(
  p_membership_id uuid,
  p_reason text default null
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  membership public.route_memberships;
  preview jsonb;
  residual numeric(12, 2);
begin
  select * into membership from public.route_memberships
  where id = p_membership_id and student_id = auth.uid()
    and status in ('active', 'pending')
  for update;
  if not found then raise exception 'Contrato ativo não encontrado.'; end if;

  preview := public.preview_contract_termination(p_membership_id);
  if (preview ->> 'canTerminate')::boolean is false then
    raise exception 'Existem mensalidades em atraso. Quite os débitos pendentes para encerrar o contrato.';
  end if;
  residual := (preview ->> 'residualFee')::numeric;

  update public.route_memberships
  set status = 'cancelled', updated_at = now()
  where id = p_membership_id
  returning * into membership;

  update public.driver_routes
  set occupied_seats = greatest(0, occupied_seats - 1), updated_at = now()
  where id = membership.route_id;

  insert into public.contract_terminations (
    membership_id, student_id, driver_id, residual_fee, reason
  ) values (
    membership.id, membership.student_id, membership.driver_id,
    residual, nullif(trim(p_reason), '')
  );

  insert into public.app_notifications (user_id, title, message, type)
  values (
    membership.driver_id, 'Contrato encerrado',
    membership.student_name || ' encerrou o contrato da rota ' ||
    membership.route_name || '.', 'contract'
  );

  return jsonb_build_object(
    'membership', to_jsonb(membership),
    'residualFee', residual
  );
end;
$$;

create or replace function public.join_driver_route(
  p_route_id uuid,
  p_start_date date default current_date,
  p_duration_months integer default 12
)
returns public.route_memberships
language plpgsql security definer set search_path = public
as $$
declare
  current_student_id uuid := auth.uid();
  selected_route public.driver_routes;
  membership public.route_memberships;
  student_name text;
begin
  if current_student_id is null then raise exception 'Usuário não autenticado.'; end if;
  if coalesce(auth.jwt() -> 'user_metadata' ->> 'role', '') <> 'student' then
    raise exception 'Somente universitários podem aderir a uma rota.';
  end if;
  if p_duration_months < 1 then
    raise exception 'A duração do contrato deve ser maior que zero.';
  end if;

  select * into selected_route from public.driver_routes
  where id = p_route_id and archived_at is null for update;
  if not found then raise exception 'Rota não encontrada.'; end if;
  if not selected_route.contract_template_ready or selected_route.due_day is null
    or selected_route.price <= 0 then
    raise exception 'O modelo de contrato desta rota ainda não está disponível.';
  end if;

  select * into membership from public.route_memberships
  where route_id = p_route_id and student_id = current_student_id
    and status in ('active', 'pending') limit 1;
  if found then return membership; end if;
  if selected_route.occupied_seats >= selected_route.seats then
    raise exception 'A rota não possui mais vagas livres.';
  end if;

  student_name := coalesce(
    auth.jwt() -> 'user_metadata' ->> 'full_name',
    auth.jwt() ->> 'email', 'Universitário'
  );
  insert into public.route_memberships (
    route_id, student_id, student_name, route_name, driver_id, driver_name,
    start_date, end_date, monthly_price, due_day, minimum_term_months,
    early_termination_fee_percent, status
  ) values (
    selected_route.id, current_student_id, student_name, selected_route.name,
    selected_route.driver_id, selected_route.driver_name, p_start_date,
    (p_start_date + make_interval(months => p_duration_months))::date,
    selected_route.price, selected_route.due_day,
    selected_route.minimum_term_months,
    selected_route.early_termination_fee_percent, 'pending'
  ) returning * into membership;

  update public.driver_routes set occupied_seats = occupied_seats + 1,
    updated_at = now() where id = selected_route.id;
  return membership;
end;
$$;

create or replace function public.leave_driver_route_membership(
  p_membership_id uuid
)
returns public.route_memberships
language plpgsql security definer set search_path = public
as $$
declare
  current_user_id uuid := auth.uid();
  membership public.route_memberships;
begin
  select * into membership from public.route_memberships
  where id = p_membership_id
    and status in ('active', 'pending')
    and (student_id = current_user_id or driver_id = current_user_id)
  for update;
  if not found then raise exception 'Contrato vigente não encontrado.'; end if;

  if membership.student_id = current_user_id then
    raise exception 'Utilize o fluxo de encerramento do contrato.';
  end if;

  update public.route_memberships
  set status = 'cancelled', updated_at = now()
  where id = membership.id returning * into membership;

  update public.driver_routes
  set occupied_seats = greatest(0, occupied_seats - 1), updated_at = now()
  where id = membership.route_id;
  return membership;
end;
$$;

drop policy if exists "Drivers can update own routes" on public.driver_routes;
drop policy if exists "Drivers can delete own routes" on public.driver_routes;
revoke update, delete on public.driver_routes from authenticated;

revoke all on function public.delete_driver_route(uuid) from public;
revoke all on function public.save_driver_route_draft(uuid, jsonb) from public;
revoke all on function public.publish_driver_route_draft(uuid) from public;
revoke all on function public.update_driver_contract_template(
  uuid, numeric, integer, integer, numeric
) from public;
revoke all on function public.accept_contract_amendment(uuid) from public;
revoke all on function public.preview_contract_termination(uuid) from public;
revoke all on function public.terminate_student_contract(uuid, text) from public;

grant execute on function public.delete_driver_route(uuid) to authenticated;
grant execute on function public.save_driver_route_draft(uuid, jsonb) to authenticated;
grant execute on function public.publish_driver_route_draft(uuid) to authenticated;
grant execute on function public.update_driver_contract_template(
  uuid, numeric, integer, integer, numeric
) to authenticated;
grant execute on function public.accept_contract_amendment(uuid) to authenticated;
grant execute on function public.preview_contract_termination(uuid) to authenticated;
grant execute on function public.terminate_student_contract(uuid, text)
  to authenticated;

notify pgrst, 'reload schema';
