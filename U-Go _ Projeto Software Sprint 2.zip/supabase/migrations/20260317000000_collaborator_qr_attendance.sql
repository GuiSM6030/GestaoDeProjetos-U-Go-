alter table public.company_collaborators
  add column if not exists access_code uuid not null default gen_random_uuid();

create unique index if not exists company_collaborators_access_code_idx
  on public.company_collaborators(access_code);

create table if not exists public.company_attendance_records (
  id uuid primary key default gen_random_uuid(),
  client_event_id uuid not null unique,
  collaborator_id uuid not null references public.company_collaborators(id)
    on delete restrict,
  company_id uuid not null references auth.users(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  scanned_at timestamptz not null default now(),
  status text not null check (status in ('authorized', 'denied')),
  denial_reason text,
  created_at timestamptz not null default now()
);

alter table public.company_attendance_records enable row level security;
create policy "Company attendance parties can read records"
  on public.company_attendance_records for select to authenticated
  using (
    company_id = auth.uid()
    or driver_id = auth.uid()
    or exists (
      select 1 from public.company_collaborators collaborator
      where collaborator.id = collaborator_id
        and collaborator.auth_user_id = auth.uid()
    )
  );
grant select on public.company_attendance_records to authenticated;

create or replace function public.validate_collaborator_access_code(
  p_access_code uuid,
  p_client_event_id uuid,
  p_scanned_at timestamptz default now()
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  collaborator public.company_collaborators;
  existing_record public.company_attendance_records;
  is_authorized boolean;
begin
  if auth.uid() is null
    or coalesce(auth.jwt() -> 'user_metadata' ->> 'role', '') <> 'driver'
  then
    raise exception 'Somente motoristas podem validar o embarque.';
  end if;

  select record.* into existing_record
  from public.company_attendance_records record
  where record.client_event_id = p_client_event_id;

  if found then
    if existing_record.driver_id <> auth.uid() then
      raise exception 'Evento de validação inválido.';
    end if;
    select * into collaborator from public.company_collaborators
    where id = existing_record.collaborator_id;
    return jsonb_build_object(
      'authorized', existing_record.status = 'authorized',
      'message', case when existing_record.status = 'authorized'
        then 'Embarque Autorizado'
        else 'Embarque Não Autorizado: Pagamento Pendente' end,
      'studentName', collaborator.name,
      'reason', existing_record.denial_reason
    );
  end if;

  select * into collaborator
  from public.company_collaborators
  where access_code = p_access_code
  for update;

  if not found then
    return jsonb_build_object(
      'authorized', false,
      'message', 'QR Code inválido para suas rotas',
      'reason', 'invalid_code'
    );
  end if;

  is_authorized :=
    collaborator.status = 'active'
    and exists (
      select 1
      from public.company_contracts contract,
        jsonb_array_elements(contract.vehicles) vehicle,
        jsonb_array_elements(coalesce(vehicle -> 'passengers', '[]'::jsonb))
          passenger
      where contract.company_id = collaborator.company_id
        and contract.status = 'active'
        and current_date between contract.start_date and contract.end_date
        and passenger ->> 'id' = collaborator.id::text
    );

  insert into public.company_attendance_records (
    client_event_id,
    collaborator_id,
    company_id,
    driver_id,
    scanned_at,
    status,
    denial_reason
  ) values (
    p_client_event_id,
    collaborator.id,
    collaborator.company_id,
    auth.uid(),
    coalesce(p_scanned_at, now()),
    case when is_authorized then 'authorized' else 'denied' end,
    case when is_authorized then null else 'company_contract_inactive' end
  );

  return jsonb_build_object(
    'authorized', is_authorized,
    'message', case when is_authorized
      then 'Embarque Autorizado'
      else 'Embarque Não Autorizado: Pagamento Pendente' end,
    'studentName', collaborator.name,
    'reason', case when is_authorized
      then null else 'company_contract_inactive' end
  );
end;
$$;

revoke all on function public.validate_collaborator_access_code(
  uuid, uuid, timestamptz
) from public;
grant execute on function public.validate_collaborator_access_code(
  uuid, uuid, timestamptz
) to authenticated;

notify pgrst, 'reload schema';
