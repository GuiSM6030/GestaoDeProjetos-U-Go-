alter table public.driver_routes
  add column if not exists due_day integer
  check (due_day between 1 and 28);

alter table public.driver_routes
  add column if not exists contract_template_ready boolean not null default false;

alter table public.route_memberships
  add column if not exists due_day integer
  check (due_day between 1 and 28);

create or replace function public.join_driver_route(
  p_route_id uuid,
  p_start_date date default current_date,
  p_duration_months integer default 12
)
returns public.route_memberships
language plpgsql
security definer
set search_path = public
as $$
declare
  current_student_id uuid := auth.uid();
  selected_route public.driver_routes;
  membership public.route_memberships;
  student_name text;
begin
  if current_student_id is null then
    raise exception 'Usuário não autenticado.';
  end if;

  if coalesce(auth.jwt() -> 'user_metadata' ->> 'role', '') <> 'student' then
    raise exception 'Somente universitários podem aderir a uma rota.';
  end if;

  if p_duration_months < 1 then
    raise exception 'A duração do contrato deve ser maior que zero.';
  end if;

  select *
  into selected_route
  from public.driver_routes
  where id = p_route_id
  for update;

  if not found then
    raise exception 'Rota não encontrada.';
  end if;

  if selected_route.driver_id = current_student_id then
    raise exception 'O motorista não pode aderir à própria rota.';
  end if;

  if not selected_route.contract_template_ready
    or selected_route.due_day is null
    or selected_route.price <= 0 then
    raise exception 'O modelo de contrato desta rota ainda não está disponível.';
  end if;

  select *
  into membership
  from public.route_memberships
  where route_id = p_route_id
    and student_id = current_student_id
    and status in ('active', 'pending')
  limit 1;

  if found then
    return membership;
  end if;

  if selected_route.occupied_seats >= selected_route.seats then
    raise exception 'A rota não possui mais vagas livres.';
  end if;

  student_name := coalesce(
    auth.jwt() -> 'user_metadata' ->> 'full_name',
    auth.jwt() ->> 'email',
    'Universitário'
  );

  insert into public.route_memberships (
    route_id,
    student_id,
    student_name,
    route_name,
    driver_id,
    driver_name,
    start_date,
    end_date,
    monthly_price,
    due_day,
    status
  )
  values (
    selected_route.id,
    current_student_id,
    student_name,
    selected_route.name,
    selected_route.driver_id,
    selected_route.driver_name,
    p_start_date,
    (p_start_date + make_interval(months => p_duration_months))::date,
    selected_route.price,
    selected_route.due_day,
    'pending'
  )
  returning * into membership;

  update public.driver_routes
  set occupied_seats = occupied_seats + 1,
      updated_at = now()
  where id = selected_route.id;

  return membership;
end;
$$;

notify pgrst, 'reload schema';
