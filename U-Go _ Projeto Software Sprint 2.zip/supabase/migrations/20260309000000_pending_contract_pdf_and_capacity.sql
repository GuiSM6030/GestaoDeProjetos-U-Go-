alter table public.route_memberships
  drop constraint if exists route_memberships_status_check;

alter table public.route_memberships
  add constraint route_memberships_status_check
  check (status in ('active', 'pending', 'cancelled', 'expired'));

alter table public.route_memberships
  alter column status set default 'pending';

alter table public.route_memberships
  add column if not exists pdf_path text;

drop index if exists public.route_memberships_active_student_route_idx;
create unique index if not exists route_memberships_current_student_route_idx
  on public.route_memberships(route_id, student_id)
  where status in ('active', 'pending');

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'contract-pdfs',
  'contract-pdfs',
  false,
  5242880,
  array['application/pdf']
)
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Contract parties can read PDFs" on storage.objects;
create policy "Contract parties can read PDFs"
  on storage.objects
  for select
  to authenticated
  using (
    bucket_id = 'contract-pdfs'
    and exists (
      select 1
      from public.route_memberships membership
      where membership.id = ((storage.foldername(name))[1])::uuid
        and (
          membership.student_id = auth.uid()
          or membership.driver_id = auth.uid()
        )
    )
  );

drop policy if exists "Students can create contract PDFs" on storage.objects;
create policy "Students can create contract PDFs"
  on storage.objects
  for insert
  to authenticated
  with check (
    bucket_id = 'contract-pdfs'
    and exists (
      select 1
      from public.route_memberships membership
      where membership.id = ((storage.foldername(name))[1])::uuid
        and membership.student_id = auth.uid()
    )
  );

drop policy if exists "Students can update contract PDFs" on storage.objects;
create policy "Students can update contract PDFs"
  on storage.objects
  for update
  to authenticated
  using (
    bucket_id = 'contract-pdfs'
    and exists (
      select 1
      from public.route_memberships membership
      where membership.id = ((storage.foldername(name))[1])::uuid
        and membership.student_id = auth.uid()
    )
  )
  with check (
    bucket_id = 'contract-pdfs'
    and exists (
      select 1
      from public.route_memberships membership
      where membership.id = ((storage.foldername(name))[1])::uuid
        and membership.student_id = auth.uid()
    )
  );

create or replace function public.join_driver_route(
  p_route_id uuid,
  p_start_date date default current_date,
  p_duration_months integer default 12
)
returns public.route_memberships
language plpgsql
security definer
set search_path = public
as $$
declare
  current_student_id uuid := auth.uid();
  selected_route public.driver_routes;
  membership public.route_memberships;
  student_name text;
begin
  if current_student_id is null then
    raise exception 'Usuário não autenticado.';
  end if;

  if coalesce(auth.jwt() -> 'user_metadata' ->> 'role', '') <> 'student' then
    raise exception 'Somente universitários podem aderir a uma rota.';
  end if;

  if p_duration_months < 1 then
    raise exception 'A duração do contrato deve ser maior que zero.';
  end if;

  select *
  into selected_route
  from public.driver_routes
  where id = p_route_id
  for update;

  if not found then
    raise exception 'Rota não encontrada.';
  end if;

  if selected_route.driver_id = current_student_id then
    raise exception 'O motorista não pode aderir à própria rota.';
  end if;

  select *
  into membership
  from public.route_memberships
  where route_id = p_route_id
    and student_id = current_student_id
    and status in ('active', 'pending')
  limit 1;

  -- Returning the same membership makes a PDF upload retry safe without
  -- reserving a second seat.
  if found then
    return membership;
  end if;

  if selected_route.occupied_seats >= selected_route.seats then
    raise exception 'A rota não possui mais vagas livres.';
  end if;

  student_name := coalesce(
    auth.jwt() -> 'user_metadata' ->> 'full_name',
    auth.jwt() ->> 'email',
    'Universitário'
  );

  insert into public.route_memberships (
    route_id,
    student_id,
    student_name,
    route_name,
    driver_id,
    driver_name,
    start_date,
    end_date,
    monthly_price,
    status
  )
  values (
    selected_route.id,
    current_student_id,
    student_name,
    selected_route.name,
    selected_route.driver_id,
    selected_route.driver_name,
    p_start_date,
    (p_start_date + make_interval(months => p_duration_months))::date,
    selected_route.price,
    'pending'
  )
  returning * into membership;

  update public.driver_routes
  set occupied_seats = occupied_seats + 1,
      updated_at = now()
  where id = selected_route.id;

  return membership;
end;
$$;

create or replace function public.attach_contract_pdf(
  p_membership_id uuid,
  p_pdf_path text
)
returns public.route_memberships
language plpgsql
security definer
set search_path = public
as $$
declare
  membership public.route_memberships;
begin
  if p_pdf_path <> (p_membership_id::text || '/contrato.pdf') then
    raise exception 'Caminho do contrato inválido.';
  end if;

  update public.route_memberships
  set pdf_path = p_pdf_path,
      updated_at = now()
  where id = p_membership_id
    and student_id = auth.uid()
    and status in ('active', 'pending')
  returning * into membership;

  if not found then
    raise exception 'Contrato não encontrado.';
  end if;

  return membership;
end;
$$;

create or replace function public.activate_driver_route_membership(
  p_membership_id uuid
)
returns public.route_memberships
language plpgsql
security definer
set search_path = public
as $$
declare
  membership public.route_memberships;
begin
  update public.route_memberships
  set status = 'active',
      updated_at = now()
  where id = p_membership_id
    and driver_id = auth.uid()
    and status = 'pending'
  returning * into membership;

  if not found then
    raise exception 'Contrato pendente não encontrado.';
  end if;

  return membership;
end;
$$;

create or replace function public.leave_driver_route_membership(
  p_membership_id uuid
)
returns public.route_memberships
language plpgsql
security definer
set search_path = public
as $$
declare
  current_user_id uuid := auth.uid();
  membership public.route_memberships;
begin
  if current_user_id is null then
    raise exception 'Usuário não autenticado.';
  end if;

  select *
  into membership
  from public.route_memberships
  where id = p_membership_id
    and status in ('active', 'pending')
    and (
      student_id = current_user_id
      or driver_id = current_user_id
    )
  for update;

  if not found then
    raise exception 'Contrato vigente não encontrado.';
  end if;

  update public.route_memberships
  set status = 'cancelled',
      updated_at = now()
  where id = membership.id
  returning * into membership;

  update public.driver_routes
  set occupied_seats = greatest(0, occupied_seats - 1),
      updated_at = now()
  where id = membership.route_id;

  return membership;
end;
$$;

revoke all on function public.attach_contract_pdf(uuid, text) from public;
revoke all on function public.activate_driver_route_membership(uuid) from public;
grant execute on function public.attach_contract_pdf(uuid, text) to authenticated;
grant execute on function public.activate_driver_route_membership(uuid) to authenticated;

notify pgrst, 'reload schema';
