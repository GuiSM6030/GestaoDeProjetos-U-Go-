create table if not exists public.driver_bank_accounts (
  driver_id uuid primary key references auth.users(id) on delete cascade,
  bank_name text not null,
  agency text not null,
  account_number text not null,
  account_type text not null
    check (account_type in ('checking', 'savings')),
  pix_key_type text not null
    check (pix_key_type in ('cpf', 'email', 'phone', 'random')),
  pix_key text not null,
  holder_name text not null,
  holder_cpf text not null check (holder_cpf ~ '^[0-9]{11}$'),
  enabled_for_payouts boolean not null default true,
  verified_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.driver_bank_accounts enable row level security;

-- Banking details are intentionally available only through the authenticated
-- Edge Function. No direct table grants are provided to app users.

notify pgrst, 'reload schema';
