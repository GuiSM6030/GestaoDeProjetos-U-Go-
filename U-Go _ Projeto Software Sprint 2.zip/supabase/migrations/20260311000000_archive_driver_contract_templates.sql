alter table public.driver_routes
  add column if not exists contract_template_archived_at timestamptz;

create or replace function public.remove_driver_contract_template(
  p_route_id uuid
)
returns public.driver_routes
language plpgsql
security definer
set search_path = public
as $$
declare
  selected_route public.driver_routes;
  has_history boolean;
begin
  select *
  into selected_route
  from public.driver_routes
  where id = p_route_id
    and driver_id = auth.uid()
  for update;

  if not found then
    raise exception 'Modelo de contrato não encontrado.';
  end if;

  if exists (
    select 1
    from public.route_memberships
    where route_id = p_route_id
      and status in ('active', 'pending')
  ) then
    raise exception 'Contrato em uso por passageiros ativos';
  end if;

  select exists (
    select 1
    from public.route_memberships
    where route_id = p_route_id
  )
  into has_history;

  if has_history then
    update public.driver_routes
    set contract_template_ready = false,
        contract_template_archived_at = now(),
        updated_at = now()
    where id = p_route_id
    returning * into selected_route;
  else
    update public.driver_routes
    set contract_template_ready = false,
        contract_template_archived_at = null,
        due_day = null,
        updated_at = now()
    where id = p_route_id
    returning * into selected_route;
  end if;

  return selected_route;
end;
$$;

revoke all on function public.remove_driver_contract_template(uuid) from public;
grant execute on function public.remove_driver_contract_template(uuid)
  to authenticated;

notify pgrst, 'reload schema';
