create extension if not exists pgcrypto;

create table if not exists public.boarding_token_secrets (
  membership_id uuid primary key references public.route_memberships(id)
    on delete cascade,
  signing_secret bytea not null default gen_random_bytes(32),
  created_at timestamptz not null default now()
);

alter table public.boarding_token_secrets enable row level security;
revoke all on public.boarding_token_secrets from public, authenticated;

insert into public.boarding_token_secrets (membership_id)
select id from public.route_memberships
on conflict (membership_id) do nothing;

create or replace function public.create_boarding_token_secret()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.boarding_token_secrets (membership_id)
  values (new.id)
  on conflict (membership_id) do nothing;
  return new;
end;
$$;

drop trigger if exists create_boarding_token_secret_after_membership
  on public.route_memberships;
create trigger create_boarding_token_secret_after_membership
after insert on public.route_memberships
for each row execute function public.create_boarding_token_secret();

create or replace function public.boarding_token_base64url(p_value bytea)
returns text
language sql immutable
as $$
  select rtrim(
    replace(replace(encode(p_value, 'base64'), '+', '-'), '/', '_'),
    '='
  );
$$;

create or replace function public.sign_student_boarding_token(
  p_membership_id uuid,
  p_signing_secret bytea
)
returns text
language plpgsql immutable
as $$
declare
  payload text;
  encoded_payload text;
  encoded_signature text;
begin
  payload := jsonb_build_object(
    'kind', 'student_contract',
    'membershipId', p_membership_id,
    'version', 1
  )::text;
  encoded_payload := public.boarding_token_base64url(convert_to(payload, 'utf8'));
  encoded_signature := public.boarding_token_base64url(
    extensions.hmac(
      convert_to(encoded_payload, 'utf8'),
      p_signing_secret,
      'sha256'::text
    )
  );
  return encoded_payload || '.' || encoded_signature;
end;
$$;

revoke all on function public.boarding_token_base64url(bytea)
  from public, authenticated;
revoke all on function public.sign_student_boarding_token(uuid, bytea)
  from public, authenticated;
revoke all on function public.create_boarding_token_secret()
  from public, authenticated;

create or replace function public.student_boarding_manual_code(
  p_signing_secret bytea
)
returns text
language sql immutable
as $$
  select lpad(
    (
      (
        get_byte(p_signing_secret, 0)::bigint * 4294967296
        + get_byte(p_signing_secret, 1)::bigint * 16777216
        + get_byte(p_signing_secret, 2)::bigint * 65536
        + get_byte(p_signing_secret, 3)::bigint * 256
        + get_byte(p_signing_secret, 4)::bigint
      ) % 10000000000
    )::text,
    10,
    '0'
  );
$$;

revoke all on function public.student_boarding_manual_code(bytea)
  from public, authenticated;

create or replace function public.get_student_boarding_tokens()
returns table (
  membership_id uuid,
  route_name text,
  membership_status text,
  boarding_token text
)
language sql security definer set search_path = public
as $$
  select
    membership.id,
    membership.route_name,
    membership.status,
    public.sign_student_boarding_token(
      membership.id,
      secret.signing_secret
    )
  from public.route_memberships membership
  join public.boarding_token_secrets secret
    on secret.membership_id = membership.id
  where membership.student_id = auth.uid();
$$;

revoke all on function public.get_student_boarding_tokens() from public;
grant execute on function public.get_student_boarding_tokens()
  to authenticated;

create or replace function public.get_student_boarding_manual_codes()
returns table (
  membership_id uuid,
  manual_code text
)
language sql security definer set search_path = public
as $$
  select
    membership.id,
    public.student_boarding_manual_code(secret.signing_secret)
  from public.route_memberships membership
  join public.boarding_token_secrets secret
    on secret.membership_id = membership.id
  where membership.student_id = auth.uid();
$$;

revoke all on function public.get_student_boarding_manual_codes()
  from public;
grant execute on function public.get_student_boarding_manual_codes()
  to authenticated;

drop function if exists public.get_driver_attendance_roster();
create function public.get_driver_attendance_roster()
returns table (
  access_code text,
  membership_id uuid,
  route_id uuid,
  route_name text,
  student_id uuid,
  student_name text,
  membership_status text,
  authorized boolean,
  denial_reason text
)
language sql security definer set search_path = public
as $$
  select
    public.sign_student_boarding_token(
      membership.id,
      secret.signing_secret
    ),
    membership.id,
    membership.route_id,
    membership.route_name,
    membership.student_id,
    membership.student_name,
    membership.status,
    (
      membership.status = 'active'
      and current_date between membership.start_date and membership.end_date
      and not exists (
        select 1 from public.monthly_charges charge
        where charge.membership_id = membership.id
          and charge.status = 'pending'
      )
    ),
    case
      when membership.status <> 'active'
        or current_date not between membership.start_date and membership.end_date
        then 'contract_inactive'
      when exists (
        select 1 from public.monthly_charges charge
        where charge.membership_id = membership.id
          and charge.status = 'pending'
      ) then 'payment_pending'
      else null
    end
  from public.route_memberships membership
  join public.boarding_token_secrets secret
    on secret.membership_id = membership.id
  where membership.driver_id = auth.uid();
$$;

revoke all on function public.get_driver_attendance_roster() from public;
grant execute on function public.get_driver_attendance_roster()
  to authenticated;

drop function if exists public.sync_offline_attendance(jsonb);
drop function if exists public.validate_route_access_code(
  uuid, uuid, timestamptz, boolean
);
create or replace function public.validate_route_access_code(
  p_access_code text,
  p_client_event_id uuid,
  p_scanned_at timestamptz default now(),
  p_recorded_offline boolean default false
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  membership public.route_memberships;
  existing_record public.attendance_records;
  is_authorized boolean;
  reason text;
  result_message text;
begin
  if auth.uid() is null
    or coalesce(auth.jwt() -> 'user_metadata' ->> 'role', '') <> 'driver'
  then
    raise exception 'Somente motoristas podem validar o embarque.';
  end if;

  select record.* into existing_record
  from public.attendance_records record
  where record.client_event_id = p_client_event_id;

  if found then
    if existing_record.driver_id <> auth.uid() then
      raise exception 'Evento de validação inválido.';
    end if;
    select * into membership from public.route_memberships
    where id = existing_record.membership_id;
    return jsonb_build_object(
      'authorized', existing_record.status = 'authorized',
      'message', case when existing_record.status = 'authorized'
        then 'Embarque Autorizado'
        else 'Embarque Não Autorizado: Pagamento Pendente' end,
      'membershipId', membership.id,
      'studentName', membership.student_name,
      'reason', existing_record.denial_reason
    );
  end if;

  select route_membership.* into membership
  from public.route_memberships route_membership
  join public.boarding_token_secrets secret
    on secret.membership_id = route_membership.id
  where route_membership.driver_id = auth.uid()
    and (
      public.sign_student_boarding_token(
        route_membership.id,
        secret.signing_secret
      ) = p_access_code
      or public.student_boarding_manual_code(
        secret.signing_secret
      ) = p_access_code
    )
  for update of route_membership;

  if not found then
    return jsonb_build_object(
      'authorized', false,
      'message', 'QR Code inválido para suas rotas',
      'reason', 'invalid_code'
    );
  end if;

  is_authorized :=
    membership.status = 'active'
    and current_date between membership.start_date and membership.end_date
    and not exists (
      select 1 from public.monthly_charges charge
      where charge.membership_id = membership.id
        and charge.status = 'pending'
    );
  reason := case
    when is_authorized then null
    when membership.status <> 'active'
      or current_date not between membership.start_date and membership.end_date
      then 'contract_inactive'
    else 'payment_pending'
  end;
  result_message := case when is_authorized
    then 'Embarque Autorizado'
    else 'Embarque Não Autorizado: Pagamento Pendente'
  end;

  insert into public.attendance_records (
    client_event_id,
    membership_id,
    route_id,
    student_id,
    driver_id,
    scanned_at,
    status,
    denial_reason,
    recorded_offline
  ) values (
    p_client_event_id,
    membership.id,
    membership.route_id,
    membership.student_id,
    membership.driver_id,
    coalesce(p_scanned_at, now()),
    case when is_authorized then 'authorized' else 'denied' end,
    reason,
    p_recorded_offline
  );

  return jsonb_build_object(
    'authorized', is_authorized,
    'message', result_message,
    'membershipId', membership.id,
    'studentName', membership.student_name,
    'reason', reason
  );
end;
$$;

revoke all on function public.validate_route_access_code(
  text, uuid, timestamptz, boolean
) from public;
grant execute on function public.validate_route_access_code(
  text, uuid, timestamptz, boolean
) to authenticated;

create or replace function public.sync_offline_attendance(p_events jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  event jsonb;
  result jsonb;
  results jsonb := '[]'::jsonb;
begin
  if jsonb_typeof(p_events) <> 'array' then
    raise exception 'A fila de eventos deve ser uma lista.';
  end if;

  for event in select value from jsonb_array_elements(p_events)
  loop
    result := public.validate_route_access_code(
      event ->> 'accessCode',
      (event ->> 'clientEventId')::uuid,
      coalesce((event ->> 'scannedAt')::timestamptz, now()),
      true
    );
    results := results || jsonb_build_array(
      result || jsonb_build_object('clientEventId', event ->> 'clientEventId')
    );
  end loop;
  return results;
end;
$$;

revoke all on function public.sync_offline_attendance(jsonb) from public;
grant execute on function public.sync_offline_attendance(jsonb)
  to authenticated;

notify pgrst, 'reload schema';
